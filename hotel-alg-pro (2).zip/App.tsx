
import React, { useState, useEffect, Suspense, lazy, useTransition } from 'react';
import { HotelProvider, useHotel } from './context/HotelContext';
import { Layout } from './components/Layout';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Building2, Shield } from 'lucide-react';

// Lazy Load Pages
const LoginPage = lazy(() => import('./pages/LoginPageNew'));
const Dashboard = lazy(() => import('./pages/Dashboard').then(module => ({ default: module.Dashboard })));
const RoomsPage = lazy(() => import('./pages/RoomsPage').then(module => ({ default: module.RoomsPage })));
const BookingsPage = lazy(() => import('./pages/BookingsPage').then(module => ({ default: module.BookingsPage })));
const InvoicesPage = lazy(() => import('./pages/InvoicesPage').then(module => ({ default: module.InvoicesPage })));
const MessagesPage = lazy(() => import('./pages/MessagesPage').then(module => ({ default: module.MessagesPage })));
const SettingsPage = lazy(() => import('./pages/SettingsPage').then(module => ({ default: module.SettingsPage })));
const NotificationsPage = lazy(() => import('./pages/NotificationsPage').then(module => ({ default: module.NotificationsPage })));
const StaffPage = lazy(() => import('./pages/StaffPage').then(module => ({ default: module.StaffPage })));
const ShortcutsPage = lazy(() => import('./pages/ShortcutsPage').then(module => ({ default: module.ShortcutsPage })));
const AccountingPage = lazy(() => import('./pages/AccountingPage').then(module => ({ default: module.AccountingPage })));
const AboutPage = lazy(() => import('./pages/AboutPage').then(module => ({ default: module.AboutPage })));
const EventsPage = lazy(() => import('./pages/EventsPage').then(module => ({ default: module.EventsPage })));
const PoolPage = lazy(() => import('./pages/PoolPage').then(module => ({ default: module.PoolPage })));
const RestaurantPage = lazy(() => import('./pages/RestaurantPage').then(module => ({ default: module.RestaurantPage })));
const QRScannerPage = lazy(() => import('./pages/QRScannerPage').then(module => ({ default: module.QRScannerPage })));
const ReportsPage = lazy(() => import('./pages/ReportsPage').then(module => ({ default: module.ReportsPage })));
const OperationsPage = lazy(() => import('./pages/OperationsPage').then(module => ({ default: module.OperationsPage })));
const ServiceManagerPage = lazy(() => import('./pages/ServiceManagerPage').then(module => ({ default: module.ServiceManagerPage })));
const GuestServicesPage = lazy(() => import('./pages/GuestServicesPage').then(module => ({ default: module.GuestServicesPage })));
const RequestsPage = lazy(() => import('./pages/RequestsPage').then(module => ({ default: module.RequestsPage })));
const GuestExperiencePreview = lazy(() => import('./pages/GuestExperiencePreview').then(module => ({ default: module.GuestExperiencePreview })));
const SecurityLinkPage = lazy(() => import('./pages/SecurityLinkPage').then(module => ({ default: module.SecurityLinkPage })));
const QRMonitoringPage = lazy(() => import('./pages/QRMonitoringPage').then(module => ({ default: module.QRMonitoringPage })));
const ManagementHub = lazy(() => import('./pages/ManagementHub').then(module => ({ default: module.ManagementHub })));
const PrintSettingsPage = lazy(() => import('./pages/PrintSettingsPage').then(module => ({ default: module.PrintSettingsPage })));
const PricingPage = lazy(() => import('./pages/PricingPage').then(module => ({ default: module.PricingPage })));
const UserProfilePage = lazy(() => import('./pages/UserProfilePage').then(module => ({ default: module.UserProfilePage })));
const WebsiteManagerPage = lazy(() => import('./pages/WebsiteManagerPage').then(module => ({ default: module.WebsiteManagerPage })));
const PublicLandingPage = lazy(() => import('./pages/PublicLandingPage').then(module => ({ default: module.PublicLandingPage })));
const GuestPortal = lazy(() => import('./components/GuestPortal').then(module => ({ default: module.GuestPortal })));
const CoordinationCenter = lazy(() => import('./pages/CoordinationCenter').then(module => ({ default: module.CoordinationCenter })));
const ExternalServicesPage = lazy(() => import('./pages/ExternalServicesPage').then(module => ({ default: module.ExternalServicesPage })));
const PermissionsPage = lazy(() => import('./pages/PermissionsPage').then(module => ({ default: module.PermissionsPage })));
const GlobalNetworkPage = lazy(() => import('./pages/GlobalNetworkPage').then(module => ({ default: module.GlobalNetworkPage })));
const ProfitabilityPage = lazy(() => import('./pages/ProfitabilityPage').then(module => ({ default: module.ProfitabilityPage })));
const DeliveryPage = lazy(() => import('./pages/DeliveryPage'));
const VenueManagementPage = lazy(() => import('./pages/VenueManagementPage'));
const GardenOasisPage = lazy(() => import('./pages/GardenOasisPage'));
const ParkingPage = lazy(() => import('./pages/ParkingPage'));
const LegalPage = lazy(() => import('./pages/LegalPage'));
const KioskManagerPage = lazy(() => import('./pages/KioskManagerPage'));
const RecruitmentPage = lazy(() => import('./pages/RecruitmentPage').then(module => ({ default: module.RecruitmentPage })));
const ReservationsPage = lazy(() => import('./pages/ReservationsPage').then(module => ({ default: module.ReservationsPage })));
const OnboardingPage = lazy(() => import('./pages/OnboardingPage'));

const LoadingScreen = () => (
    <div className="fixed inset-0 bg-blue-600 flex flex-col items-center justify-center z-50 text-white animate-fade-in">
        <div className="p-6 bg-white/10 rounded-[2rem] backdrop-blur-md mb-6 animate-bounce shadow-2xl">
            <Building2 size={64} />
        </div>
        <h1 className="text-3xl font-black tracking-tight mb-2">AUTHENTIC ZELLIJ</h1>
        <p className="text-blue-200 font-bold text-sm tracking-widest uppercase">System Loading...</p>
    </div>
);

const AppContent = () => {
  const { currentUser, users } = useHotel();
  const [activePage, setActivePage] = useState('dashboard');
  const [history, setHistory] = useState<string[]>([]); 
  const [guestToken, setGuestToken] = useState<string | null>(null);
  const [isGuestServiceMode, setIsGuestServiceMode] = useState(false);
  const [isPublicMode, setIsPublicMode] = useState(false); 
  const [isLoading, setIsLoading] = useState(true);
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 1500);

    const params = new URLSearchParams(window.location.search);
    const token = params.get('guest');
    const serviceToken = params.get('token'); 
    const mode = params.get('mode');

    if (mode === 'public') {
        setIsPublicMode(true);
    }
    if (token) {
        setGuestToken(token);
    }
    if (serviceToken && window.location.pathname.includes('guest-services')) {
        setIsGuestServiceMode(true);
    }
    return () => clearTimeout(timer);
  }, []);

  // ... (navigation handlers)
  const handleNavigate = (page: string) => {
      if (page === activePage) return;
      setHistory(prev => [...prev, activePage]);
      startTransition(() => {
          setActivePage(page);
      });
  };

  const handleGoBack = () => {
      setHistory(prev => {
          const newHistory = [...prev];
          const lastPage = newHistory.pop();
          if (lastPage) {
              startTransition(() => {
                  setActivePage(lastPage);
              });
          }
          else {
              startTransition(() => {
                  setActivePage('dashboard'); 
              });
          }
          return newHistory;
      });
  };

  useEffect(() => {
      const onNavigate = (e: CustomEvent) => handleNavigate(e.detail);
      const onBack = () => handleGoBack();
      window.addEventListener('navigate-to', onNavigate as EventListener);
      window.addEventListener('go-back', onBack);
      return () => {
          window.removeEventListener('navigate-to', onNavigate as EventListener);
          window.removeEventListener('go-back', onBack);
      };
  }, [activePage]);

  if (isLoading) return <LoadingScreen />;

  // Priority 0: Public Website Mode
  if (isPublicMode) {
      return (
          <Suspense fallback={<LoadingScreen />}>
              <PublicLandingPage />
          </Suspense>
      );
  }

  // Priority 1: Guest Service Page (Direct Link)
  if (isGuestServiceMode) {
      return (
          <Suspense fallback={<LoadingScreen />}>
              <GuestServicesPage />
          </Suspense>
      );
  }

  // Priority 2: Old Guest Portal
  if (guestToken) {
      return (
          <Suspense fallback={<LoadingScreen />}>
              <GuestPortal token={guestToken} />
          </Suspense>
      );
  }

  // Priority 3: Onboarding (No Users)
  if (!users || users.length === 0) {
      return (
          <Suspense fallback={<LoadingScreen />}>
              <OnboardingPage />
          </Suspense>
      );
  }

  // Priority 4: Login
  if (!currentUser) {
    return (
        <Suspense fallback={<LoadingScreen />}>
            <LoginPage />
        </Suspense>
    );
  }

  const renderPage = () => {
    // STRICT ACCESS CONTROL
    const role = currentUser?.role || 'guest';
    const dept = currentUser?.department || 'none';

    // Define allowed roles for sensitive pages
    const accessRules: Record<string, string[]> = {
        'admin_hub': ['manager', 'assistant_manager'],
        'invoices': ['manager', 'assistant_manager', 'accountant'],
        'staff': ['manager', 'assistant_manager', 'hr_manager'],
        'settings': ['manager', 'it_specialist'],
        'restaurant': ['manager', 'assistant_manager', 'restaurant_manager', 'head_chef', 'chef', 'waiter', 'receptionist'],
        'cafe': ['manager', 'assistant_manager', 'cafe_manager', 'barista', 'waiter', 'receptionist'],
        'coordination': ['manager', 'assistant_manager', 'reception_manager', 'receptionist', 'restaurant_manager', 'head_chef', 'housekeeping_manager', 'maintenance_manager', 'security_manager'],
        'operations': ['manager', 'assistant_manager', 'maintenance_manager', 'maintenance_staff', 'housekeeping_manager', 'housekeeping_staff', 'security_manager', 'security_guard'],
        'external_services': ['manager', 'assistant_manager', 'reception_manager', 'receptionist', 'concierge'],
        'accommodation': ['manager', 'assistant_manager', 'reception_manager', 'receptionist'],
        'delivery': ['manager', 'restaurant_manager', 'head_chef', 'waiter'],
        'recruitment': ['manager', 'hr_manager'],
    };

    // Check access
    if (accessRules[activePage] && !accessRules[activePage].includes(role)) {
        // If user is Head of Department, they might have access to coordination
        if (activePage === 'coordination' && currentUser?.isHeadOfDepartment) {
            // Allow
        } else {
            return (
                <div className="flex flex-col items-center justify-center h-full text-center p-8 animate-fade-in">
                    <div className="w-24 h-24 bg-red-100 text-red-600 rounded-full flex items-center justify-center mb-6">
                        <Shield size={48} />
                    </div>
                    <h2 className="text-2xl font-black mb-2">غير مصرح بالدخول</h2>
                    <p className="text-gray-500 max-w-md mb-8">عذراً، لا تملك الصلاحيات الكافية للوصول إلى هذا القسم. يرجى التواصل مع الإدارة إذا كنت تعتقد أن هذا خطأ.</p>
                    <button onClick={() => handleNavigate('dashboard')} className="px-8 py-3 bg-gray-900 text-white rounded-xl font-bold hover:bg-black transition">
                        العودة للرئيسية
                    </button>
                </div>
            );
        }
    }

    switch (activePage) {
      case 'dashboard': return <Dashboard navigate={handleNavigate} />;
      case 'shortcuts': return <ShortcutsPage navigate={handleNavigate} />;
      case 'accommodation': return <RoomsPage />;
      case 'events': return <EventsPage />; 
      case 'pool': return <PoolPage />; 
      case 'restaurant': return <RestaurantPage mode="restaurant" />; 
      case 'cafe': return <RestaurantPage mode="cafe" />;
      case 'invoices': return <InvoicesPage />;
      case 'messages': return <MessagesPage />;
      case 'qr_scanner': return <QRScannerPage />; 
      case 'qr_monitor': return <QRMonitoringPage />;
      case 'admin_hub': return <ManagementHub navigate={handleNavigate} />; 
      case 'reports': return <ReportsPage />;
      case 'operations': return <OperationsPage />; 
      case 'services': return <ServiceManagerPage />; 
      case 'requests': return <RequestsPage />;
      case 'guest_preview': return <GuestExperiencePreview />; 
      case 'security': return <SecurityLinkPage />; 
      case 'settings': return <SettingsPage />;
      case 'print_settings': return <PrintSettingsPage />;
      case 'website_manager': return <WebsiteManagerPage />; 
      case 'pricing': return <PricingPage />; 
      case 'notifications': return <NotificationsPage />;
      case 'staff': return <StaffPage />;
      case 'coordination': return <CoordinationCenter />; 
      case 'external_services': return <ExternalServicesPage />;
      case 'user_profile': return <UserProfilePage />;
      case 'accounting': return <AccountingPage />;
      case 'about': return <AboutPage />;
      case 'delivery': return <DeliveryPage />;
      case 'venues': return <VenueManagementPage />;
      case 'garden_oasis': return <GardenOasisPage />;
      case 'parking': return <ParkingPage />;
      case 'legal': return <LegalPage />;
      case 'kiosk_manager': return <KioskManagerPage />;
      case 'recruitment': return <RecruitmentPage />;
      case 'global_network': return <GlobalNetworkPage />;
      case 'profitability': return <ProfitabilityPage />;
      case 'reservations': return <ReservationsPage />;
      default: return <Dashboard navigate={handleNavigate} />;
    }
  };

  return (
    <Layout activePage={activePage} setActivePage={handleNavigate}>
      {isPending && (
          <div className="fixed top-0 left-0 w-full h-1 z-[100] bg-blue-100">
              <div className="h-full bg-blue-600 animate-progress"></div>
          </div>
      )}
      <Suspense fallback={<div className="flex items-center justify-center min-h-[50vh]"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div></div>}>
        {renderPage()}
      </Suspense>
    </Layout>
  );
};

function App() {
  return (
    <ErrorBoundary>
      <HotelProvider>
        <AppContent />
      </HotelProvider>
    </ErrorBoundary>
  );
}

export default App;
