
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { AppSettings, AppState, Booking, Invoice, Message as ChatMessage, Notification, Room, RoomStatus, User, RoomType, GuestInfo, ChatSession, Transaction, Role, HallBooking, PoolPass, RestaurantOrder, QRRecord, MaintenanceTicket, Department, MenuItem, ServiceItem, ServiceRequest, ServiceLocationType, SecurityLog, QRScanLog, QRUsageType, GuestLocationStatus, StandardRates, PriceOption, LeaveRequest, LeaveStatus, StaffRequest, AttendanceRecord, AttendanceStatus, Table, IncidentReport, IncidentSeverity, IncidentType, ExternalOrder, CoordinationNote, PrintTemplateStyle, RegistrationTemplateStyle, InventoryItem, DeliveryDriver, Partner, ServicePoint, ParkingSpot, LegalRule, JobOpening, JobApplication, Reservation } from '../types';
import { INITIAL_SETTINGS, MOCK_USERS, generateRooms, DEFAULT_MENU, INITIAL_SERVICES, STAFF_PERMISSIONS, INITIAL_INVENTORY, INITIAL_TABLES, INITIAL_PARKING_SPOTS, INITIAL_LEGAL_RULES } from '../constants';
import { generateSecureToken, parseSecureToken, QRPayload, QRTokenType } from '../utils/qrCrypto';
import { initDB, saveEntity, loadAll, saveSettings, loadSettings, saveAll } from '../utils/db';
import { 
    generateMockUsers, generateMockRooms, generateMockGuests, 
    generateMockBookings, generateMockTransactions, generateMockMaintenanceTickets, 
    generateMockNotifications, generateMockHallBookings, generateMockRestaurantOrders, 
    generateMockAttendance, generateMockPoolPasses, generateMockChatSessions, 
    generateMockMessages, generateMockServiceRequests, generateMockExternalOrders, 
    generateMockCoordinationNotes, generateMockIncidentReports
} from '../utils/populateData';

interface NotificationTargets {
    roles?: Role[];
    departments?: Department[];
    users?: string[];
}

interface HotelContextType extends AppState {
  login: (userId: string) => void;
  logout: () => void;
  forgetUser: (userId: string) => void; 
  recentUsers: string[]; 
  updateUser: (userId: string, data: Partial<User>, notificationNote?: string) => void;
  addStaff: (name: string, role: Role, department: Department, isHead: boolean, salary: number, accessCode: string) => void;
  removeStaff: (userId: string) => void;
  
  // Recruitment
  jobOpenings: JobOpening[];
  jobApplications: JobApplication[];
  addJobOpening: (job: Omit<JobOpening, 'id' | 'postedDate' | 'status'>) => void;
  updateJobOpening: (id: string, updates: Partial<JobOpening>) => void;
  addJobApplication: (app: Omit<JobApplication, 'id' | 'appliedDate' | 'status'>) => void;
  updateJobApplicationStatus: (id: string, status: JobApplication['status']) => void;

  updateSettings: (newSettings: Partial<AppSettings>) => void;
  updatePageTitle: (key: string, title: string) => void; 
  updateRoomStatus: (roomId: number, status: RoomStatus) => void;
  updateRoomType: (roomId: number, type: RoomType) => void;
  addBooking: (booking: Omit<Booking, 'guestToken' | 'id'>, roomIds: number[]) => Booking;
  extendBooking: (bookingId: string, days: number) => void; 
  moveBooking: (bookingId: string, newRoomId: number, reason?: string) => void;
  splitBooking: (originalBookingId: string, guestIndicesToMove: number[], newRoomId: number, newPrice: number) => void;
  addGuestToRoom: (roomId: number, guest: GuestInfo) => void;
  checkIn: (bookingId: string, roomId?: number) => void;
  checkOut: (bookingId: string) => void;
  addInvoice: (invoice: Invoice) => void;
  updateInvoice: (id: string, updates: Partial<Invoice>) => void;
  addTransaction: (transaction: Omit<Transaction, 'id' | 'date' | 'userId' | 'userName'> & { userId?: string; userName?: string }) => void; 
  clearUserBalance: (targetUserId: string, amount: number) => void; 
  sendMessage: (content: string, receiverId?: string) => void;
  sendGuestMessage: (token: string, content: string) => void;
  replyToGuest: (guestToken: string, content: string) => void;
  toggleChatMute: (sessionId: string) => void;
  toggleShortcut: (actionId: string) => void;
  toggleDarkMode: () => void;
  setTheme: (theme: AppSettings['theme']) => void;
  searchGuest: (idNumber: string) => GuestInfo | undefined;
  
  // Pricing Updates
  updateRoomPrices: (type: RoomType, prices: PriceOption[]) => void;
  updateStandardRate: (key: keyof StandardRates, value: number) => void;

  // Notifications
  addNotification: (msg: string, type?: Notification['type'], details?: string, targets?: NotificationTargets, action?: { link: string, label: string }, category?: Notification['category']) => void;
  activeToast: Notification | null;
  hideToast: () => void;
  markAsRead: (id: string) => void; // New
  moveToTrash: (id: string) => void; 
  deleteNotificationPermanently: (id: string) => void; 
  restoreNotification: (id: string) => void; 
  emptyTrash: () => void; 
  
  addHallBooking: (booking: HallBooking) => void;
  cancelHallBooking: (id: string) => void;
  createPoolPass: (pass: PoolPass) => PoolPass; 
  invalidatePoolPass: (id: string) => void;
  
  // Restaurant Extended
  menuItems: MenuItem[];
  addMenuItem: (item: Omit<MenuItem, 'id'>) => void;
  updateMenuItem: (id: string, item: Partial<MenuItem>) => void;
  deleteMenuItem: (id: string) => void;
  addRestaurantOrder: (order: RestaurantOrder) => void;
  updateRestaurantOrder: (id: string, status: 'pending' | 'preparing' | 'completed' | 'cancelled') => void;
  updateRestaurantOrderItems: (orderId: string, newItems: { item: MenuItem; quantity: number }[]) => void;
  inventory: InventoryItem[];
  updateInventory: (itemId: string, quantityChange: number) => void;
  updateTableStatus: (tableId: string, status: Table['status'], orderId?: string) => void;
  chargeOrderToRoom: (orderId: string, roomId: number) => void;
  
  // Table Management (New)
  addTable: (table: Table) => void;
  removeTable: (tableId: string) => void;
  updateTableDetails: (tableId: string, updates: Partial<Table>) => void;
  
  // QR System (Secure)
  addQRRecord: (record: Omit<QRRecord, 'id' | 'createdAt' | 'scannedCount' | 'currentState' | 'usageType'>, usageType?: QRUsageType) => void;
  scanQRRecord: (id: string) => void;
  resetQRState: (qrId: string) => void;
  regenerateBookingQR: (booking: Booking) => string;
  generateSystemQR: (type: QRTokenType, id: string, name?: string, expiryDays?: number, meta?: any) => string;
  parseSystemQR: (token: string) => QRPayload | null;
  toggleGuestPresence: (bookingId: string, status: GuestLocationStatus) => void;

  // External Services
  addExternalOrder: (order: Omit<ExternalOrder, 'id' | 'createdAt' | 'status'>) => void;
  updateExternalOrderStatus: (id: string, status: ExternalOrder['status']) => void;
  
  // Coordination
  addCoordinationNote: (note: Omit<CoordinationNote, 'id' | 'createdAt' | 'createdBy' | 'isResolved'>) => void;
  resolveCoordinationNote: (id: string) => void;

  // Maintenance System
  addMaintenanceTicket: (ticket: Omit<MaintenanceTicket, 'id' | 'reportedAt' | 'status' | 'reportedBy'>) => void;
  resolveMaintenanceTicket: (id: string, cost?: number) => void;

  userShortcuts: string[];

  // Guest Services
  toggleServiceStatus: (serviceId: string) => void;
  addNewService: (service: Omit<ServiceItem, 'id'>) => void;
  removeService: (serviceId: string) => void;
  requestService: (serviceId: string, locationType: ServiceLocationType, locationId: string, notes?: string) => void;
  updateServiceRequestStatus: (requestId: string, status: ServiceRequest['status']) => void;
  updateServiceItem: (id: string, data: Partial<ServiceItem>) => void; 

  // Global Profile Modal
  activeProfile: User | null;
  setActiveProfile: (user: User | null) => void;

  // Security
  addSecurityLog: (log: Omit<SecurityLog, 'id' | 'timestamp' | 'reportedBy'>) => void;

  // Leave Management
  addLeaveRequest: (req: Omit<LeaveRequest, 'id' | 'status' | 'createdAt'>) => void;
  updateLeaveStatus: (id: string, status: LeaveStatus, reason?: string) => void;

  // Staff Requests
  submitStaffRequest: (req: Omit<StaffRequest, 'id' | 'status' | 'createdAt'>) => void;

  // Attendance Management
  recordAttendance: (userId: string, type: 'in' | 'out', timestamp?: string) => void;
  updateAttendanceRecord: (id: string, updates: Partial<AttendanceRecord>) => void;
  attendanceRecords: AttendanceRecord[];
  restaurantTables: Table[];

  // Incidents & Violations
  incidentReports: IncidentReport[];
  reportIncident: (incident: Omit<IncidentReport, 'id' | 'reportedAt' | 'status' | 'isFineApplied'>) => void;
  resolveIncident: (id: string, action: 'resolve' | 'dismiss' | 'apply_fine', resolutionNotes?: string) => void;

  // Delivery & Services
  deliveryDrivers: DeliveryDriver[];
  servicePoints: ServicePoint[];
  parkingSpots: ParkingSpot[];
  legalRules: LegalRule[];
  addDeliveryDriver: (driver: DeliveryDriver) => void;
  updateDriverStatus: (driverId: string, status: DeliveryDriver['status']) => void;
  assignDriverToOrder: (orderId: string, driverId: string) => void;
  rateDeliveryOrder: (orderId: string, deliveryRating: number, restaurantRating: number, feedback?: string) => void;
  addServicePoint: (point: ServicePoint) => void;
  updateServicePoint: (id: string, updates: Partial<ServicePoint>) => void;
  
  // Parking
  addParkingSpot: (spot: ParkingSpot) => void;
  updateParkingSpot: (id: string, updates: Partial<ParkingSpot>) => void;
  
  // Legal
  addLegalRule: (rule: LegalRule) => void;
  updateLegalRule: (id: string, updates: Partial<LegalRule>) => void;

  // Partnership Management
  addPartner: (partner: Partner) => void;
  updatePartner: (id: string, updates: Partial<Partner>) => void;
  removePartner: (id: string) => void;

  // Reservations
  reservations: Reservation[];
  addReservation: (reservation: Omit<Reservation, 'id' | 'createdAt' | 'status' | 'qrCodeData'>) => void;
  updateReservation: (id: string, updates: Partial<Reservation>) => void;

  // System
  populateDemoData: () => Promise<void>;
}

const HotelContext = createContext<HotelContextType | undefined>(undefined);

export const useHotel = () => {
  const context = useContext(HotelContext);
  if (!context) {
    throw new Error('useHotel must be used within a HotelProvider');
  }
  return context;
};

export const HotelProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // ... (State initialization remains same)
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [settings, setSettings] = useState<AppSettings>(INITIAL_SETTINGS);
  const [rooms, setRooms] = useState<Room[]>([]);
  
  const [recentUsers, setRecentUsers] = useState<string[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [activeToast, setActiveToast] = useState<Notification | null>(null);
  const [activeProfile, setActiveProfile] = useState<User | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [chatSessions, setChatSessions] = useState<ChatSession[]>([]);
  const [hallBookings, setHallBookings] = useState<HallBooking[]>([]);
  const [poolPasses, setPoolPasses] = useState<PoolPass[]>([]);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [restaurantOrders, setRestaurantOrders] = useState<RestaurantOrder[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [restaurantTables, setRestaurantTables] = useState<Table[]>([]);
  const [qrRecords, setQrRecords] = useState<QRRecord[]>([]);
  const [qrLogs, setQrLogs] = useState<QRScanLog[]>([]);
  const [maintenanceTickets, setMaintenanceTickets] = useState<MaintenanceTicket[]>([]);
  const [guestHistory, setGuestHistory] = useState<GuestInfo[]>([]);
  const [userShortcuts, setUserShortcuts] = useState<string[]>([]);
  const [guestServices, setGuestServices] = useState<ServiceItem[]>([]);
  const [serviceRequests, setServiceRequests] = useState<ServiceRequest[]>([]);
  const [securityLogs, setSecurityLogs] = useState<SecurityLog[]>([]);
  const [leaveRequests, setLeaveRequests] = useState<LeaveRequest[]>([]);
  const [staffRequests, setStaffRequests] = useState<StaffRequest[]>([]);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [incidentReports, setIncidentReports] = useState<IncidentReport[]>([]);
  const [externalOrders, setExternalOrders] = useState<ExternalOrder[]>([]);
  const [coordinationNotes, setCoordinationNotes] = useState<CoordinationNote[]>([]);
  const [deliveryDrivers, setDeliveryDrivers] = useState<DeliveryDriver[]>([]);
  const [servicePoints, setServicePoints] = useState<ServicePoint[]>([]); // New State
  const [partners, setPartners] = useState<Partner[]>([]); // New State
  const [parkingSpots, setParkingSpots] = useState<ParkingSpot[]>([]); // New State
  const [legalRules, setLegalRules] = useState<LegalRule[]>([]); // New State
  const [jobOpenings, setJobOpenings] = useState<JobOpening[]>([]); // New State
  const [jobApplications, setJobApplications] = useState<JobApplication[]>([]); // New State
  const [reservations, setReservations] = useState<Reservation[]>([]); // New State

  // --- DB LOADING ---
  useEffect(() => {
      const loadData = async () => {
          try {
              const [
                  savedSettings, savedUsers, savedRooms, savedBookings, savedInvoices, 
                  savedTransactions, savedNotifications, savedMenuItems, savedOrders, savedQrRecords,
                  savedInventory, savedHallBookings, savedPoolPasses, savedMaintenanceTickets,
                  savedIncidentReports, savedChatSessions, savedMessages, savedGuestHistory,
                  savedServiceRequests, savedExternalOrders, savedCoordinationNotes, savedAttendanceRecords,
                  savedDrivers, savedPartners, savedServicePoints, savedParkingSpots, savedLegalRules,
                  savedJobOpenings, savedJobApplications, savedReservations
              ] = await Promise.all([
                  loadSettings(),
                  loadAll<User>('users'),
                  loadAll<Room>('rooms'),
                  loadAll<Booking>('bookings'),
                  loadAll<Invoice>('invoices'),
                  loadAll<Transaction>('transactions'),
                  loadAll<Notification>('notifications'),
                  loadAll<MenuItem>('menuItems'),
                  loadAll<RestaurantOrder>('orders'),
                  loadAll<QRRecord>('qrRecords'),
                  loadAll<InventoryItem>('inventory'),
                  loadAll<HallBooking>('hallBookings'),
                  loadAll<PoolPass>('poolPasses'),
                  loadAll<MaintenanceTicket>('maintenanceTickets'),
                  loadAll<IncidentReport>('incidentReports'),
                  loadAll<ChatSession>('chatSessions'),
                  loadAll<ChatMessage>('messages'),
                  loadAll<GuestInfo>('guestHistory'),
                  loadAll<ServiceRequest>('serviceRequests'),
                  loadAll<ExternalOrder>('externalOrders'),
                  loadAll<CoordinationNote>('coordinationNotes'),
                  loadAll<AttendanceRecord>('attendanceRecords'),
                  loadAll<DeliveryDriver>('deliveryDrivers'),
                  loadAll<Partner>('partners'), // New Load
                  loadAll<ServicePoint>('servicePoints'), // New Load
                  loadAll<ParkingSpot>('parkingSpots'), // New Load
                  loadAll<LegalRule>('legalRules'), // New Load
                  loadAll<JobOpening>('jobOpenings'), // New Load
                  loadAll<JobApplication>('jobApplications'), // New Load
                  loadAll<Reservation>('reservations') // New Load
              ]);

              if (savedSettings) {
                  setSettings({ ...INITIAL_SETTINGS, ...savedSettings });
              }
              
              // POPULATE IF EMPTY - DISABLED FOR PRODUCTION
              // if (!savedUsers || savedUsers.length === 0) {
              //     console.log("DB Empty: Starting fresh...");
              //     // Do nothing, let the user set up via Onboarding
              // } else {
                  if (savedUsers) setUsers(savedUsers);
                  // Initialize rooms if saved, otherwise empty (will be created by settings or onboarding)
                  if (savedRooms.length > 0) {
                      setRooms(savedRooms);
                  } else if (savedSettings?.totalRooms) {
                      // Only generate if settings exist but rooms don't (migration case)
                      // For new installs, let the onboarding handle it
                      // setRooms(generateMockRooms(savedSettings.totalRooms)); 
                  }
                  
                  if (savedBookings.length > 0) setBookings(savedBookings);
                  if (savedInvoices.length > 0) setInvoices(savedInvoices);
                  if (savedTransactions.length > 0) setTransactions(savedTransactions);
                  if (savedNotifications.length > 0) setNotifications(savedNotifications);
                  if (savedMenuItems.length > 0) setMenuItems(savedMenuItems);
                  if (savedOrders.length > 0) setRestaurantOrders(savedOrders);
                  if (savedQrRecords.length > 0) setQrRecords(savedQrRecords);
                  
                  if (savedInventory.length > 0) setInventory(savedInventory);
                  if (savedHallBookings.length > 0) setHallBookings(savedHallBookings);
                  if (savedPoolPasses.length > 0) setPoolPasses(savedPoolPasses);
                  if (savedMaintenanceTickets.length > 0) setMaintenanceTickets(savedMaintenanceTickets);
                  if (savedIncidentReports.length > 0) setIncidentReports(savedIncidentReports);
                  if (savedChatSessions.length > 0) setChatSessions(savedChatSessions);
                  if (savedMessages.length > 0) setMessages(savedMessages);
                  if (savedGuestHistory.length > 0) setGuestHistory(savedGuestHistory);
                  if (savedServiceRequests.length > 0) setServiceRequests(savedServiceRequests);
                  if (savedExternalOrders.length > 0) setExternalOrders(savedExternalOrders);
                  if (savedCoordinationNotes.length > 0) setCoordinationNotes(savedCoordinationNotes);
                  if (savedAttendanceRecords.length > 0) setAttendanceRecords(savedAttendanceRecords);
                  if (savedDrivers && savedDrivers.length > 0) setDeliveryDrivers(savedDrivers);
                  if (savedPartners && savedPartners.length > 0) setPartners(savedPartners);
                  if (savedServicePoints && savedServicePoints.length > 0) setServicePoints(savedServicePoints);
                  if (savedParkingSpots && savedParkingSpots.length > 0) setParkingSpots(savedParkingSpots);
                  if (savedLegalRules && savedLegalRules.length > 0) setLegalRules(savedLegalRules);
                  if (savedJobOpenings && savedJobOpenings.length > 0) setJobOpenings(savedJobOpenings);
                  if (savedJobApplications && savedJobApplications.length > 0) setJobApplications(savedJobApplications);
                  if (savedReservations && savedReservations.length > 0) setReservations(savedReservations);
              // }
              
          } catch (error) {
              console.error("Failed to load data from DB:", error);
          }
      };
      loadData();
  }, []);

  // --- DB SAVING (Debounced) ---
  useEffect(() => { 
      const t = setTimeout(() => {
          saveSettings(settings);
      }, 1000); 
      return () => clearTimeout(t); 
  }, [settings]);

  // Separate effect for syncing room count to avoid complex dependencies in saving logic
  useEffect(() => {
      if (settings.totalRooms && settings.totalRooms !== rooms.length) {
          const t = setTimeout(() => {
              setRooms(currentRooms => {
                  const newTotal = settings.totalRooms;
                  if (newTotal === currentRooms.length) return currentRooms;

                  if (newTotal > currentRooms.length) {
                      // Add more rooms
                      const lastRoom = currentRooms.length > 0 ? currentRooms[currentRooms.length - 1] : null;
                      // Try to parse the last number, default to 100 if failed
                      const lastNumStr = lastRoom ? lastRoom.number.replace(/\D/g, '') : '100';
                      const startNum = parseInt(lastNumStr) + 1;
                      
                      const additionalRooms: Room[] = Array.from({ length: newTotal - currentRooms.length }, (_, i) => ({
                          // Calculate ID based on max existing ID to avoid conflicts
                          id: currentRooms.length > 0 ? Math.max(...currentRooms.map(r => r.id)) + i + 1 : i + 1,
                          number: (startNum + i).toString(),
                          type: 'double',
                          status: 'available',
                          price: 8000,
                          floor: 1,
                          features: ['wifi', 'tv', 'ac'],
                          lastCleaned: new Date().toISOString()
                      }));
                      const updated = [...currentRooms, ...additionalRooms];
                      saveAll('rooms', updated);
                      return updated;
                  } else {
                      // Remove rooms
                      const updated = currentRooms.slice(0, newTotal);
                      saveAll('rooms', updated);
                      return updated;
                  }
              });
          }, 500); // Debounce room generation
          return () => clearTimeout(t);
      }
  }, [settings.totalRooms]); // Only run when totalRooms setting changes
  useEffect(() => { const t = setTimeout(() => { if(users.length > 0) saveAll('users', users); }, 2000); return () => clearTimeout(t); }, [users]);
  useEffect(() => { const t = setTimeout(() => { if(rooms.length > 0) saveAll('rooms', rooms); }, 2000); return () => clearTimeout(t); }, [rooms]);
  useEffect(() => { const t = setTimeout(() => { if(bookings.length > 0) saveAll('bookings', bookings); }, 1000); return () => clearTimeout(t); }, [bookings]);
  useEffect(() => { const t = setTimeout(() => { if(invoices.length > 0) saveAll('invoices', invoices); }, 2000); return () => clearTimeout(t); }, [invoices]);
  useEffect(() => { const t = setTimeout(() => { if(transactions.length > 0) saveAll('transactions', transactions); }, 2000); return () => clearTimeout(t); }, [transactions]);
  useEffect(() => { const t = setTimeout(() => { if(notifications.length > 0) saveAll('notifications', notifications); }, 5000); return () => clearTimeout(t); }, [notifications]);
  useEffect(() => { const t = setTimeout(() => { if(menuItems.length > 0) saveAll('menuItems', menuItems); }, 5000); return () => clearTimeout(t); }, [menuItems]);
  useEffect(() => { const t = setTimeout(() => { if(restaurantOrders.length > 0) saveAll('orders', restaurantOrders); }, 2000); return () => clearTimeout(t); }, [restaurantOrders]);
  useEffect(() => { const t = setTimeout(() => { if(qrRecords.length > 0) saveAll('qrRecords', qrRecords); }, 2000); return () => clearTimeout(t); }, [qrRecords]);
  
  // NEW STORES SAVING
  useEffect(() => { const t = setTimeout(() => { if(inventory.length > 0) saveAll('inventory', inventory); }, 2000); return () => clearTimeout(t); }, [inventory]);
  useEffect(() => { const t = setTimeout(() => { if(hallBookings.length > 0) saveAll('hallBookings', hallBookings); }, 2000); return () => clearTimeout(t); }, [hallBookings]);
  useEffect(() => { const t = setTimeout(() => { if(poolPasses.length > 0) saveAll('poolPasses', poolPasses); }, 2000); return () => clearTimeout(t); }, [poolPasses]);
  useEffect(() => { const t = setTimeout(() => { if(maintenanceTickets.length > 0) saveAll('maintenanceTickets', maintenanceTickets); }, 2000); return () => clearTimeout(t); }, [maintenanceTickets]);
  useEffect(() => { const t = setTimeout(() => { if(incidentReports.length > 0) saveAll('incidentReports', incidentReports); }, 2000); return () => clearTimeout(t); }, [incidentReports]);
  useEffect(() => { const t = setTimeout(() => { if(chatSessions.length > 0) saveAll('chatSessions', chatSessions); }, 2000); return () => clearTimeout(t); }, [chatSessions]);
  useEffect(() => { const t = setTimeout(() => { if(messages.length > 0) saveAll('messages', messages); }, 2000); return () => clearTimeout(t); }, [messages]);
  useEffect(() => { const t = setTimeout(() => { if(guestHistory.length > 0) saveAll('guestHistory', guestHistory); }, 2000); return () => clearTimeout(t); }, [guestHistory]);
  useEffect(() => { const t = setTimeout(() => { if(serviceRequests.length > 0) saveAll('serviceRequests', serviceRequests); }, 2000); return () => clearTimeout(t); }, [serviceRequests]);
  useEffect(() => { const t = setTimeout(() => { if(externalOrders.length > 0) saveAll('externalOrders', externalOrders); }, 2000); return () => clearTimeout(t); }, [externalOrders]);
  useEffect(() => { const t = setTimeout(() => { if(coordinationNotes.length > 0) saveAll('coordinationNotes', coordinationNotes); }, 2000); return () => clearTimeout(t); }, [coordinationNotes]);
  useEffect(() => { const t = setTimeout(() => { if(attendanceRecords.length > 0) saveAll('attendanceRecords', attendanceRecords); }, 2000); return () => clearTimeout(t); }, [attendanceRecords]);
  useEffect(() => { const t = setTimeout(() => { if(deliveryDrivers.length > 0) saveAll('deliveryDrivers', deliveryDrivers); }, 2000); return () => clearTimeout(t); }, [deliveryDrivers]);
  useEffect(() => { const t = setTimeout(() => { if(partners.length > 0) saveAll('partners', partners); }, 2000); return () => clearTimeout(t); }, [partners]);
  useEffect(() => { const t = setTimeout(() => { if(servicePoints.length > 0) saveAll('servicePoints', servicePoints); }, 2000); return () => clearTimeout(t); }, [servicePoints]);
  useEffect(() => { const t = setTimeout(() => { if(parkingSpots.length > 0) saveAll('parkingSpots', parkingSpots); }, 2000); return () => clearTimeout(t); }, [parkingSpots]);
  useEffect(() => { const t = setTimeout(() => { if(legalRules.length > 0) saveAll('legalRules', legalRules); }, 2000); return () => clearTimeout(t); }, [legalRules]);
  useEffect(() => { const t = setTimeout(() => { if(jobOpenings.length > 0) saveAll('jobOpenings', jobOpenings); }, 2000); return () => clearTimeout(t); }, [jobOpenings]);
  useEffect(() => { const t = setTimeout(() => { if(jobApplications.length > 0) saveAll('jobApplications', jobApplications); }, 2000); return () => clearTimeout(t); }, [jobApplications]);
  useEffect(() => { const t = setTimeout(() => { if(reservations.length > 0) saveAll('reservations', reservations); }, 2000); return () => clearTimeout(t); }, [reservations]);

  // --- GUEST PORTAL EVENTS ---
  useEffect(() => {
      const handleGuestOrder = (e: CustomEvent) => {
          const order = e.detail;
          setRestaurantOrders(prev => {
              const updated = [order, ...prev];
              saveAll('orders', updated);
              return updated;
          });
          
          if(order.tableId) {
             setRestaurantTables(prev => prev.map(t => t.id === order.tableId ? { ...t, status: 'occupied', currentOrderId: order.id } : t));
          }

          // Add notification
          const userId = currentUser ? currentUser.name : 'System';
          const newNotif: Notification = {
            id: Date.now().toString(),
            message: `طلب جديد من ${order.customerName}`,
            details: `${order.type} - ${order.totalAmount} د.ج`,
            userId: userId,
            timestamp: new Date().toISOString(),
            type: 'success',
            hiddenFor: [],
            isTrashed: false
          };
          setNotifications(prev => [newNotif, ...prev]);
          setActiveToast(newNotif);
      };

      window.addEventListener('guest-order-placed', handleGuestOrder as EventListener);
      return () => window.removeEventListener('guest-order-placed', handleGuestOrder as EventListener);
  }, [currentUser]); // Added dependency on currentUser to ensure notification has correct user context if needed, though 'System' fallback is used.

  // ... (Keep existing notification and user helpers)
  const addNotification = (msg: string, type: Notification['type'] = 'info', details?: string, targets?: NotificationTargets, action?: { link: string, label: string }, category?: Notification['category']) => {
    const userId = currentUser ? currentUser.name : 'System';
    const newNotif: Notification = {
      id: Date.now().toString(),
      message: msg,
      details: details,
      userId: userId,
      timestamp: new Date().toISOString(),
      type,
      category: category || 'system',
      hiddenFor: [],
      readBy: [],
      isTrashed: false,
      targetRoles: targets?.roles,
      targetDepartments: targets?.departments,
      targetUsers: targets?.users,
      actionLink: action?.link,
      actionLabel: action?.label
    };
    setNotifications(prev => [newNotif, ...prev]);
    if (currentUser && (!targets || (targets.users?.includes(currentUser.id) || targets.roles?.includes(currentUser.role)))) {
        setActiveToast(newNotif);
    }
  };

  const markAsRead = (id: string) => {
      if (!currentUser) return;
      setNotifications(prev => prev.map(n => {
          if (n.id === id) {
              const readers = n.readBy || [];
              if (!readers.includes(currentUser.id)) {
                  return { ...n, readBy: [...readers, currentUser.id] };
              }
          }
          return n;
      }));
  };

  const login = (userId: string) => { const user = users.find(u => u.id === userId); if (user) { setCurrentUser(user); setRecentUsers(prev => [userId, ...prev.filter(id => id !== userId)].slice(0, 5)); } };
  const logout = () => setCurrentUser(null);
  const forgetUser = (userId: string) => setRecentUsers(prev => prev.filter(id => id !== userId));
  const updateUser = (userId: string, data: Partial<User>, notificationNote?: string) => { setUsers(prev => prev.map(u => u.id === userId ? { ...u, ...data } : u)); if (notificationNote) addNotification(`تم تحديث بيانات الموظف`, 'info', notificationNote); };
  const addStaff = (name: string, role: Role, department: Department, isHead: boolean, salary: number, accessCode: string) => { const newUser: User = { id: `u${Date.now()}`, name, role, department, isHeadOfDepartment: isHead, salary, accessCode, joinDate: new Date().toISOString(), avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=random`, isBlocked: false, permissions: STAFF_PERMISSIONS, leaveBalance: 30, status: 'active' }; setUsers(prev => [...prev, newUser]); };
  const removeStaff = (userId: string) => setUsers(prev => prev.filter(u => u.id !== userId));
  const updateSettings = (newSettings: Partial<AppSettings>) => setSettings(prev => ({ ...prev, ...newSettings }));
  const updatePageTitle = (key: string, title: string) => setSettings(prev => ({ ...prev, pageTitles: { ...prev.pageTitles, [key]: title } }));
  const updateRoomPrices = (type: RoomType, prices: PriceOption[]) => setSettings(prev => ({ ...prev, roomPrices: { ...prev.roomPrices, [type]: prices } }));
  const updateStandardRate = (key: keyof StandardRates, value: number) => setSettings(prev => ({ ...prev, standardRates: { ...prev.standardRates, [key]: value } }));
  const updateRoomStatus = (roomId: number, status: RoomStatus) => setRooms(prev => prev.map(r => r.id === roomId ? { ...r, status } : r));
  const updateRoomType = (roomId: number, type: RoomType) => setRooms(prev => prev.map(r => r.id === roomId ? { ...r, type } : r));
  
  // ... (Keep booking logic)
  const addBooking = (bookingData: Omit<Booking, 'guestToken' | 'id'>, roomIds: number[]) => { 
      const newBooking: Booking = { 
          ...bookingData, 
          id: `bkg-${Date.now()}`, 
          guestToken: Math.random().toString(36).substring(7), 
          guestLocation: 'in_hotel' 
      }; 
      setBookings(prev => {
          const updated = [...prev, newBooking];
          saveAll('bookings', updated); // Immediate Save
          return updated;
      }); 
      if (newBooking.status === 'active') {
          roomIds.forEach(id => updateRoomStatus(id, 'occupied'));
      } else if (newBooking.status === 'pending') {
          roomIds.forEach(id => updateRoomStatus(id, 'booked'));
      }
      return newBooking; 
  };

  const extendBooking = (bookingId: string, days: number) => {
      setBookings(prev => {
          const updated = prev.map(b => {
              if (b.id === bookingId) {
                  const newDate = new Date(b.checkOutDate);
                  newDate.setDate(newDate.getDate() + days);
                  return { ...b, checkOutDate: newDate.toISOString().split('T')[0] };
              }
              return b;
          });
          saveAll('bookings', updated); // Immediate Save
          return updated;
      });
      addNotification('تم تمديد الحجز بنجاح', 'success');
  };

  const moveBooking = (bookingId: string, newRoomId: number, reason?: string) => {
      const booking = bookings.find(b => b.id === bookingId);
      if (!booking) return;
      const oldRoomId = booking.roomId;
      
      setBookings(prev => {
          const updated = prev.map(b => b.id === bookingId ? { 
              ...b, 
              roomId: newRoomId, 
              notes: (b.notes || '') + (reason ? `\n[System]: Moved from Room ${oldRoomId} to ${newRoomId}. Reason: ${reason}` : '') 
          } : b);
          saveAll('bookings', updated); // Immediate Save
          return updated;
      });
      
      if (oldRoomId) updateRoomStatus(oldRoomId, 'dirty');
      updateRoomStatus(newRoomId, 'occupied');
      
      addNotification(`تم نقل الحجز من الغرفة ${rooms.find(r=>r.id===oldRoomId)?.number} إلى ${rooms.find(r=>r.id===newRoomId)?.number}`, 'info', reason);
  };

  const splitBooking = (originalBookingId: string, guestIndicesToMove: number[], newRoomId: number, newPrice: number) => {
      const original = bookings.find(b => b.id === originalBookingId);
      if(!original) return;
      
      const guestsMoving = original.guests.filter((_, i) => guestIndicesToMove.includes(i));
      const guestsStaying = original.guests.filter((_, i) => !guestIndicesToMove.includes(i));
      
      setBookings(prev => {
          const updated = prev.map(b => b.id === originalBookingId ? { ...b, guests: guestsStaying } : b);
          saveAll('bookings', updated); // Immediate Save
          return updated;
      });
      
      addBooking({
          ...original,
          roomId: newRoomId,
          guests: guestsMoving,
          totalAmount: newPrice,
          status: 'active',
          mealPlan: original.mealPlan,
          extraServices: original.extraServices
      }, [newRoomId]);
      
      addNotification('تم فصل الحجز وإنشاء حجز جديد بنجاح', 'success');
  };

  const updateBooking = (bookingId: string, updates: Partial<Booking>) => {
      setBookings(prev => {
          const updated = prev.map(b => b.id === bookingId ? { ...b, ...updates } : b);
          saveAll('bookings', updated); // Immediate Save
          return updated;
      });
      if (updates.totalAmount) {
          addNotification('تم تحديث سعر الحجز بنجاح', 'success');
      }
  };

  const addGuestToRoom = (roomId: number, guest: GuestInfo, newTotalAmount?: number) => {
      setBookings(prev => {
          const updated = prev.map(b => {
              if (b.roomId === roomId && b.status === 'active') {
                  return { 
                      ...b, 
                      guests: [...b.guests, guest],
                      totalAmount: newTotalAmount !== undefined ? newTotalAmount : b.totalAmount
                  };
              }
              return b;
          });
          saveAll('bookings', updated); // Immediate Save
          return updated;
      });
      addNotification(`تم إضافة النزيل ${guest.firstNameAr} للغرفة بنجاح`, 'success');
  };

  const checkIn = (bookingId: string, roomId?: number) => {
      setBookings(prev => {
          const updated = prev.map(b => {
              if (b.id === bookingId) {
                  const targetRoom = roomId || b.roomId;
                  updateRoomStatus(targetRoom, 'occupied');
                  return { 
                      ...b, 
                      status: 'active', 
                      checkInDate: new Date().toISOString(), 
                      roomId: targetRoom, 
                      guestLocation: 'in_hotel' 
                  };
              }
              return b;
          });
          saveAll('bookings', updated); // Immediate Save
          return updated;
      });
      addNotification('تم تسجيل الدخول بنجاح', 'success');
  };

  const checkOut = (bookingId: string) => {
      const b = bookings.find(b => b.id === bookingId);
      if (b) {
          updateRoomStatus(b.roomId, 'dirty');
          setBookings(prev => {
              const updated = prev.map(bk => bk.id === bookingId ? { 
                  ...bk, 
                  status: 'completed', 
                  checkOutDate: new Date().toISOString(), 
                  guestLocation: 'out_of_hotel' 
              } : bk);
              saveAll('bookings', updated); // Immediate Save
              return updated;
          });
          
          const inv: Invoice = {
              id: `inv-${Date.now()}`,
              bookingId: b.id,
              guestName: b.primaryGuestName,
              amount: b.totalAmount,
              date: new Date().toISOString(),
              isPaid: false,
              details: {
                  roomTotal: b.totalAmount,
                  mealTotal: 0,
                  servicesTotal: 0,
                  days: 1,
                  mealPlan: b.mealPlan
              }
          };
          addInvoice(inv);
          addNotification('تم تسجيل الخروج وإصدار الفاتورة', 'success');
      }
  };

  const addInvoice = (invoice: Invoice) => setInvoices(prev => {
      const updated = [invoice, ...prev];
      saveAll('invoices', updated); // Immediate Save
      return updated;
  });

  const updateInvoice = (id: string, updates: Partial<Invoice>) => setInvoices(prev => {
      const updated = prev.map(inv => inv.id === id ? { ...inv, ...updates } : inv);
      saveAll('invoices', updated);
      return updated;
  });

  const addTransaction = (transaction: Omit<Transaction, 'id' | 'date' | 'userId' | 'userName'> & { userId?: string; userName?: string }) => { 
      const newTrans: Transaction = { 
          id: `tx-${Date.now()}`, 
          date: new Date().toISOString(), 
          userId: transaction.userId || currentUser?.id || 'system', 
          userName: transaction.userName || currentUser?.name || 'System', 
          paymentMethod: transaction.paymentMethod || 'cash', // Default to cash
          cardDetails: transaction.cardDetails,
          ...transaction 
      }; 
      setTransactions(prev => {
          const updated = [newTrans, ...prev];
          saveAll('transactions', updated); // Immediate Save
          return updated;
      }); 
  };
  const clearUserBalance = (targetUserId: string, amount: number) => addTransaction({ amount, type: 'settlement', category: 'deduction', description: 'تصفية حساب', targetUserId });
  
  const sendMessage = (content: string, receiverId?: string) => {
      setMessages(prev => [...prev, { id: `msg-${Date.now()}`, senderId: currentUser?.id || 'system', receiverId, content, timestamp: new Date().toISOString() }]);
  };
  
  const sendGuestMessage = (token: string, content: string) => {
      setMessages(prev => [...prev, { id: `msg-${Date.now()}`, senderId: token, receiverId: 'reception', content, isGuestMessage: true, timestamp: new Date().toISOString() }]);
      setChatSessions(prev => {
          const exists = prev.find(s => s.id === token);
          if (exists) return prev.map(s => s.id === token ? { ...s, lastMessage: content, unreadCount: s.unreadCount + 1 } : s);
          return [...prev, { id: token, name: 'Guest', lastMessage: content, unreadCount: 1, isGuest: true, isMuted: false, roomNumber: 'Online' }];
      });
  };
  
  const replyToGuest = (token: string, content: string) => {
      setMessages(prev => [...prev, { id: `msg-${Date.now()}`, senderId: currentUser?.id || 'system', receiverId: token, content, timestamp: new Date().toISOString() }]);
  };
  
  const toggleChatMute = (sessionId: string) => setChatSessions(prev => prev.map(s => s.id === sessionId ? { ...s, isMuted: !s.isMuted } : s));
  const toggleShortcut = (actionId: string) => setUserShortcuts(prev => prev.includes(actionId) ? prev.filter(id => id !== actionId) : [...prev, actionId]);
  const toggleDarkMode = () => updateSettings({ darkMode: !settings.darkMode });
  const setTheme = (theme: AppSettings['theme']) => updateSettings({ theme });
  const searchGuest = (id: string) => guestHistory.find(g => g.idNumber === id);
  
  const hideToast = () => setActiveToast(null);
  const moveToTrash = (id: string) => { setNotifications(prev => prev.map(n => n.id === id ? { ...n, isTrashed: true, deletedAt: new Date().toISOString() } : n)); };
  const deleteNotificationPermanently = (id: string) => { setNotifications(prev => prev.filter(n => n.id !== id)); };
  const restoreNotification = (id: string) => { setNotifications(prev => prev.map(n => n.id === id ? { ...n, isTrashed: false, deletedAt: undefined } : n)); };
  const emptyTrash = () => { setNotifications(prev => prev.filter(n => !n.isTrashed)); };

  const addHallBooking = (b: HallBooking) => setHallBookings(prev => [...prev, b]);
  const cancelHallBooking = (id: string) => setHallBookings(prev => prev.map(b => b.id === id ? { ...b, status: 'cancelled' } : b));
  const createPoolPass = (p: PoolPass) => { setPoolPasses(prev => [p, ...prev]); return p; };
  const invalidatePoolPass = (id: string) => setPoolPasses(prev => prev.map(p => p.id === id ? { ...p, isValid: false } : p));
  const addRestaurantOrder = (order: RestaurantOrder) => { 
      setRestaurantOrders(prev => {
          const updated = [order, ...prev];
          saveAll('orders', updated); // Immediate Save
          return updated;
      }); 
      if(order.tableId) updateTableStatus(order.tableId, 'occupied', order.id); 
  };
  const updateRestaurantOrder = (id: string, status: any) => {
      setRestaurantOrders(prev => {
          const updated = prev.map(o => o.id === id ? { ...o, status } : o);
          saveAll('orders', updated); // Immediate Save
          return updated;
      });
  };
  
  // NEW: Update order items (append/merge)
  const updateRestaurantOrderItems = (orderId: string, newItems: { item: MenuItem; quantity: number }[]) => {
      setRestaurantOrders(prev => {
          const updated = prev.map(order => {
              if (order.id !== orderId) return order;
              
              // Merge items
              const updatedItems = [...order.items];
              newItems.forEach(newItem => {
                  const existingIndex = updatedItems.findIndex(i => i.item.id === newItem.item.id);
                  if (existingIndex >= 0) {
                      updatedItems[existingIndex].quantity += newItem.quantity;
                  } else {
                      updatedItems.push(newItem);
                  }
              });

              // Recalculate total
              const newTotal = updatedItems.reduce((sum, i) => sum + (i.item.price * i.quantity), 0);

              return { ...order, items: updatedItems, totalAmount: newTotal };
          });
          saveAll('orders', updated); // Immediate Save
          return updated;
      });
  };

  const updateInventory = (id: string, qty: number) => {
      setInventory(prev => {
          const updated = prev.map(i => i.id === id ? { ...i, quantity: i.quantity + qty } : i);
          saveAll('inventory', updated); // Immediate Save
          return updated;
      });
  };
  const updateTableStatus = (tableId: string, status: Table['status'], orderId?: string) => setRestaurantTables(prev => prev.map(t => t.id === tableId ? { ...t, status, currentOrderId: orderId } : t));
  const addMenuItem = (i: any) => {
      setMenuItems(prev => {
          const updated = [...prev, { ...i, id: `m-${Date.now()}` }];
          saveAll('menuItems', updated); // Immediate Save
          return updated;
      });
  };
  const updateMenuItem = (id: string, i: any) => {
      setMenuItems(prev => {
          const updated = prev.map(item => item.id === id ? { ...item, ...i } : item);
          saveAll('menuItems', updated); // Immediate Save
          return updated;
      });
  };
  const deleteMenuItem = (id: string) => {
      setMenuItems(prev => {
          const updated = prev.filter(i => i.id !== id);
          saveAll('menuItems', updated); // Immediate Save
          return updated;
      });
  };
  
  const addTable = (table: Table) => setRestaurantTables(prev => [...prev, table]);
  const removeTable = (tableId: string) => setRestaurantTables(prev => prev.filter(t => t.id !== tableId));
  const updateTableDetails = (tableId: string, updates: Partial<Table>) => setRestaurantTables(prev => prev.map(t => t.id === tableId ? { ...t, ...updates } : t));

  const addQRRecord = (r: any, usageType: QRUsageType = 'single_use') => {
      setQrRecords(prev => [...prev, { 
          ...r, 
          id: `qr-${Date.now()}`, 
          createdAt: new Date().toISOString(), 
          scannedCount: 0, 
          currentState: 'fresh',
          usageType: usageType 
      }]);
  };
  
  // FIX: Refactored scanQRRecord to prevent side-effects in updater
  const scanQRRecord = (id: string) => {
      const record = qrRecords.find(r => r.id === id);
      if (!record) return;

      let nextState = record.currentState;
      if (record.usageType === 'single_use') nextState = 'consumed';
      else if (record.usageType === 'access_pass') {
          nextState = record.currentState === 'active_session' ? 'consumed' : 'active_session';
      }

      // Update Record
      setQrRecords(prev => prev.map(r => r.id === id ? { 
          ...r, 
          scannedCount: r.scannedCount + 1, 
          lastScanTime: new Date().toISOString(), 
          currentState: nextState 
      } : r));

      // Update Log
      setQrLogs(l => [{
          id: `log-${Date.now()}`,
          qrId: id,
          scannerId: currentUser?.id || 'sys',
          location: 'Main Gate',
          timestamp: new Date().toISOString(),
          result: 'success',
          message: nextState === 'active_session' ? 'Entry Logged' : 'Exit/Use Logged'
      }, ...l]);
  };

  // ... (Keep existing secure QR methods)
  const generateSystemQR = (type: QRTokenType, id: string, name?: string, expiryDays: number = 1, meta?: any) => {
      const expiry = Date.now() + (expiryDays * 24 * 60 * 60 * 1000);
      const payload: QRPayload = { t: type, i: id, n: name, x: expiry, m: meta };
      return generateSecureToken(payload);
  };

  const parseSystemQR = (token: string) => {
      return parseSecureToken(token);
  };

  const resetQRState = (id: string) => setQrRecords(prev => prev.map(r => r.id === id ? { ...r, currentState: 'fresh' } : r));
  const regenerateBookingQR = (b: Booking) => { 
      return generateSystemQR('ROOM_KEY', b.roomId.toString(), b.primaryGuestName, 1);
  };
  
  // FIX: Separate state updates to avoid side-effects (React #310)
  const toggleGuestPresence = (bid: string, status: any) => {
      const booking = bookings.find(b => b.id === bid);
      if (booking) {
          setRooms(prev => prev.map(r => r.id === booking.roomId ? { ...r, currentGuestLocation: status } : r));
      }
      setBookings(prev => prev.map(b => b.id === bid ? { ...b, guestLocation: status } : b));
  };

  // ... (Keep remaining methods)
  const addMaintenanceTicket = (t: any) => setMaintenanceTickets(prev => [...prev, { ...t, id: `tkt-${Date.now()}`, reportedAt: new Date().toISOString(), status: 'pending', reportedBy: currentUser?.name || 'Staff' }]);
  const resolveMaintenanceTicket = (id: string, cost?: number) => { setMaintenanceTickets(prev => prev.map(t => t.id === id ? { ...t, status: 'resolved' } : t)); if (cost) addTransaction({ amount: cost, type: 'expense', category: 'maintenance', description: `Fix Ticket ${id}` }); };
  const toggleServiceStatus = (id: string) => setGuestServices(prev => prev.map(s => s.id === id ? { ...s, isActive: !s.isActive } : s));
  const addNewService = (s: any) => setGuestServices(prev => [...prev, { ...s, id: `srv-${Date.now()}` }]);
  const removeService = (id: string) => setGuestServices(prev => prev.filter(s => s.id !== id));
  const requestService = (sid: string, lt: any, lid: string, notes?: string) => { setServiceRequests(prev => [...prev, { id: `req-${Date.now()}`, serviceId: sid, guestName: 'Guest', locationType: lt, locationId: lid, status: 'pending', timestamp: new Date().toISOString(), notes }]); };
  const updateServiceRequestStatus = (id: string, s: any) => setServiceRequests(prev => prev.map(r => r.id === id ? { ...r, status: s } : r));
  const updateServiceItem = (id: string, data: Partial<ServiceItem>) => setGuestServices(prev => prev.map(s => s.id === id ? { ...s, ...data } : s));
  const addSecurityLog = (l: any) => setSecurityLogs(prev => [...prev, { ...l, id: `sec-${Date.now()}`, timestamp: new Date().toISOString() }]);
  const submitStaffRequest = (req: any) => setStaffRequests(prev => [...prev, { ...req, id: `sr-${Date.now()}`, status: 'pending', createdAt: new Date().toISOString() }]);

  const addDeliveryDriver = (driver: DeliveryDriver) => setDeliveryDrivers(prev => [...prev, driver]);
  const updateDriverStatus = (id: string, status: DeliveryDriver['status']) => setDeliveryDrivers(prev => prev.map(d => d.id === id ? { ...d, status } : d));
  
  const assignDriverToOrder = (orderId: string, driverId: string) => {
      const driver = deliveryDrivers.find(d => d.id === driverId);
      if (!driver) return;
      
      setRestaurantOrders(prev => prev.map(o => o.id === orderId ? { 
          ...o, 
          status: 'out_for_delivery', 
          driverId, 
          driverName: driver.name,
          deliveryStartTime: new Date().toISOString() 
      } : o));
      
      updateDriverStatus(driverId, 'busy');
      addNotification(`تم إسناد الطلب #${orderId.slice(-4)} للسائق ${driver.name}`, 'info');
  };

  const rateDeliveryOrder = (orderId: string, deliveryRating: number, restaurantRating: number, feedback?: string) => {
      setRestaurantOrders(prev => prev.map(o => {
          if (o.id === orderId) {
              // Update driver stats
              if (o.driverId) {
                  setDeliveryDrivers(drivers => drivers.map(d => {
                      if (d.id === o.driverId) {
                          const newTotal = d.totalDeliveries + 1;
                          const newAvg = ((d.averageRating * d.totalDeliveries) + deliveryRating) / newTotal;
                          return { ...d, totalDeliveries: newTotal, averageRating: newAvg, status: 'available' };
                      }
                      return d;
                  }));
              }
              return { 
                  ...o, 
                  status: 'completed', 
                  deliveryEndTime: new Date().toISOString(),
                  deliveryRating, 
                  restaurantRating, 
                  deliveryFeedback: feedback 
              };
          }
          return o;
      }));
  };

  const chargeOrderToRoom = (orderId: string, roomId: number) => {
      const order = restaurantOrders.find(o => o.id === orderId);
      if (!order) return;
      const booking = bookings.find(b => b.roomId === roomId && b.status === 'active');
      if (!booking) { addNotification("فشل العملية", 'error', "الغرفة غير مشغولة حالياً"); return; }
      setRestaurantOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: 'completed' } : o));
      if (order.tableId) updateTableStatus(order.tableId, 'available');
      setBookings(prev => prev.map(b => { if (b.id === booking.id) { return { ...b, totalAmount: b.totalAmount + order.totalAmount, notes: (b.notes || '') + `\n[مطعمة] ${order.totalAmount} د.ج` }; } return b; }));
      addNotification(`تم تحويل الفاتورة (${order.totalAmount} د.ج) إلى الغرفة ${rooms.find(r => r.id === roomId)?.number}`, 'success', `النزيل: ${booking.primaryGuestName}`);
  };

  const recordAttendance = (userId: string, type: 'in' | 'out', timestamp?: string) => {
      const user = users.find(u => u.id === userId);
      if (!user) return;
      const date = timestamp ? new Date(timestamp) : new Date();
      const dateStr = date.toISOString().split('T')[0];
      const timeStr = date.toISOString();
      setAttendanceRecords(prev => {
          const existing = prev.find(r => r.userId === userId && r.date === dateStr);
          if (type === 'in') {
              if (existing) return prev;
              const limit = new Date(dateStr + 'T' + (settings.workStartTime || '09:00:00'));
              const isLate = date > limit;
              const diffMinutes = isLate ? Math.floor((date.getTime() - limit.getTime()) / 60000) : 0;
              const deduction = diffMinutes > 15 ? Math.floor(diffMinutes / 15) * 100 : 0;
              if (deduction > 0) {
                  addTransaction({ amount: deduction, type: 'expense', category: 'deduction', description: `خصم تأخير آلي - ${user.name}`, notes: `تأخر ${diffMinutes} دقيقة`, targetUserId: userId, userId: 'system' });
                  addNotification(`تم تسجيل تأخير للموظف ${user.name} (${diffMinutes} دقيقة)`, 'warning', `تم خصم ${deduction} د.ج`);
              }
              return [...prev, { id: `att-${Date.now()}`, userId, userName: user.name, date: dateStr, checkInTime: timeStr, status: isLate ? 'late' : 'present', lateDurationMinutes: diffMinutes, deductionAmount: deduction }];
          } else {
              if (!existing) return prev;
              return prev.map(r => r.id === existing.id ? { ...r, checkOutTime: timeStr } : r);
          }
      });
  };

  const updateAttendanceRecord = (recordId: string, updates: Partial<AttendanceRecord>) => {
      setAttendanceRecords(prev => prev.map(record => {
          if (record.id !== recordId) return record;
          return { ...record, ...updates };
      }));
  };

  const addLeaveRequest = (req: Omit<LeaveRequest, 'id' | 'status' | 'createdAt'>) => {
      const newReq: LeaveRequest = {
          id: `leave-${Date.now()}`,
          status: 'pending',
          createdAt: new Date().toISOString(),
          ...req
      };
      setLeaveRequests(prev => [newReq, ...prev]);
      addNotification(`طلب إجازة جديد: ${req.userName}`, 'info', `${req.type} - ${req.daysCount} أيام`);
  };

  const updateLeaveStatus = (id: string, status: LeaveStatus, reason?: string) => {
      setLeaveRequests(prev => prev.map(r => r.id === id ? { ...r, status, rejectionReason: reason, approvedBy: currentUser?.name } : r));
      const req = leaveRequests.find(r => r.id === id);
      if (req && status === 'approved') {
          addNotification(`تمت الموافقة على إجازة ${req.userName}`, 'success');
          if (req.type === 'unpaid' || req.type === 'sick') {
              addNotification(`تنبيه محاسبي: إجازة ${req.type === 'unpaid' ? 'بدون راتب' : 'مرضية'} للموظف ${req.userName}`, 'warning', `يرجى مراجعة الخصومات (${req.daysCount} أيام)`);
          }
      } else if (req && status === 'rejected') {
          addNotification(`تم رفض طلب الإجازة للموظف ${req.userName}`, 'error');
      }
  };

  const addExternalOrder = (order: Omit<ExternalOrder, 'id' | 'createdAt' | 'status'>) => {
      const newOrder: ExternalOrder = {
          ...order,
          id: `ext-${Date.now()}`,
          status: 'pending',
          createdAt: new Date().toISOString()
      };
      setExternalOrders(prev => [newOrder, ...prev]);
      addNotification(`طلب خارجي جديد: ${order.type}`, 'info', `${order.customerName} - ${order.totalAmount} د.ج`);
  };

  const updateExternalOrderStatus = (id: string, status: ExternalOrder['status']) => {
      setExternalOrders(prev => prev.map(o => o.id === id ? { ...o, status } : o));
      const order = externalOrders.find(o => o.id === id);
      if (order) {
          addNotification(`تحديث حالة الطلب الخارجي: ${status}`, 'info', `${order.customerName}`);
      }
  };

  const addCoordinationNote = (note: Omit<CoordinationNote, 'id' | 'createdAt' | 'createdBy' | 'isResolved'>) => {
      const newNote: CoordinationNote = {
          ...note,
          id: `coord-${Date.now()}`,
          createdAt: new Date().toISOString(),
          createdBy: currentUser?.name || 'System',
          isResolved: false
      };
      setCoordinationNotes(prev => [newNote, ...prev]);
      addNotification(`ملاحظة تنسيق جديدة`, 'warning', `${note.content}`, { departments: note.targetDepartments });
  };

  const resolveCoordinationNote = (id: string) => {
      setCoordinationNotes(prev => prev.map(n => n.id === id ? { ...n, isResolved: true } : n));
  };

  const reportIncident = (incident: Omit<IncidentReport, 'id' | 'reportedAt' | 'status' | 'isFineApplied'>) => {
      const newIncident: IncidentReport = {
          id: `inc-${Date.now()}`,
          reportedAt: new Date().toISOString(),
          status: 'reported',
          isFineApplied: false,
          ...incident
      };
      setIncidentReports(prev => [newIncident, ...prev]);
      addNotification(`بلاغ جديد: ${incident.title}`, 'error', incident.location, {roles: ['manager', 'assistant_manager', 'security'] as any});
  };

  const resolveIncident = (id: string, action: 'resolve' | 'dismiss' | 'apply_fine', resolutionNotes?: string) => {
      setIncidentReports(prev => prev.map(inc => {
          if (inc.id !== id) return inc;
          
          let updatedStatus: IncidentReport['status'] = action === 'dismiss' ? 'dismissed' : 'resolved';
          let fineApplied = inc.isFineApplied;

          if (action === 'apply_fine' && inc.fineAmount && !inc.isFineApplied) {
              fineApplied = true;
              updatedStatus = 'resolved';
              
              if (inc.type === 'guest_violation' && inc.relatedRoomId) {
                  const booking = bookings.find(b => b.roomId === inc.relatedRoomId && b.status === 'active');
                  if (booking) {
                      setBookings(curr => curr.map(b => b.id === booking.id ? { 
                          ...b, 
                          totalAmount: b.totalAmount + (inc.fineAmount || 0),
                          notes: (b.notes || '') + `\n[مخالفة] ${inc.fineAmount} د.ج - ${inc.title}`
                      } : b));
                      addNotification(`تم إضافة غرامة (${inc.fineAmount}) للغرفة ${rooms.find(r=>r.id===inc.relatedRoomId)?.number}`, 'warning');
                  } else {
                      addNotification(`تم تسجيل الغرامة ولكن الغرفة ${rooms.find(r=>r.id===inc.relatedRoomId)?.number} غير مشغولة حالياً`, 'info');
                  }
              } else if (inc.type === 'staff_violation' && inc.relatedStaffId) {
                  addTransaction({
                      amount: inc.fineAmount,
                      type: 'income', // Fine is income for hotel
                      category: 'fine',
                      description: `غرامة موظف: ${inc.relatedStaffId} - ${inc.title}`,
                      userId: 'system',
                      userName: 'System',
                      targetUserId: inc.relatedStaffId
                  });
                  addNotification(`تم تسجيل غرامة (${inc.fineAmount}) على الموظف ${users.find(u=>u.id===inc.relatedStaffId)?.name}`, 'warning');
              }
          }

          return { ...inc, status: updatedStatus, isFineApplied: fineApplied, resolutionNotes };
      }));
  };

  const addPartner = (p: Partner) => setPartners(prev => [...prev, p]);
  const updatePartner = (id: string, updates: Partial<Partner>) => setPartners(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
  const removePartner = (id: string) => setPartners(prev => prev.filter(p => p.id !== id));

  const addServicePoint = (point: ServicePoint) => setServicePoints(prev => [...prev, point]);
  const updateServicePoint = (id: string, updates: Partial<ServicePoint>) => setServicePoints(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));

  const addParkingSpot = (spot: ParkingSpot) => setParkingSpots(prev => [...prev, spot]);
  const updateParkingSpot = (id: string, updates: Partial<ParkingSpot>) => setParkingSpots(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));

  const addLegalRule = (rule: LegalRule) => setLegalRules(prev => [...prev, rule]);
  const updateLegalRule = (id: string, updates: Partial<LegalRule>) => setLegalRules(prev => prev.map(r => r.id === id ? { ...r, ...updates } : r));

  const populateDemoData = async () => {
      console.log("Forcing Demo Data Population...");
      const newUsers = generateMockUsers();
      const newRooms = generateMockRooms(INITIAL_SETTINGS.totalRooms);
      const newGuests = generateMockGuests();
      const newBookings = generateMockBookings(newRooms, newGuests);
      const newTransactions = generateMockTransactions(newUsers);
      const newMaintenance = generateMockMaintenanceTickets(newRooms, newUsers);
      const newNotifications = generateMockNotifications(newUsers);
      const newHallBookings = generateMockHallBookings();
      const newOrders = generateMockRestaurantOrders(DEFAULT_MENU);
      const newAttendance = generateMockAttendance(newUsers);
      const newPoolPasses = generateMockPoolPasses();
      const newChatSessions = generateMockChatSessions(newUsers);
      const newMessages = generateMockMessages(newChatSessions);
      const newServiceRequests = generateMockServiceRequests();
      const newExternalOrders = generateMockExternalOrders();
      const newCoordinationNotes = generateMockCoordinationNotes();
      const newIncidentReports = generateMockIncidentReports();

      setUsers(newUsers);
      setRooms(newRooms);
      setBookings(newBookings);
      setGuestHistory(newGuests);
      setTransactions(newTransactions);
      setMaintenanceTickets(newMaintenance);
      setNotifications(newNotifications);
      setHallBookings(newHallBookings);
      setRestaurantOrders(newOrders);
      setAttendanceRecords(newAttendance);
      setPoolPasses(newPoolPasses);
      setChatSessions(newChatSessions);
      setMessages(newMessages);
      setServiceRequests(newServiceRequests);
      setExternalOrders(newExternalOrders);
      setCoordinationNotes(newCoordinationNotes);
      setIncidentReports(newIncidentReports);
      setServicePoints([]); // Reset or populate if needed
      setParkingSpots(INITIAL_PARKING_SPOTS);
      setLegalRules(INITIAL_LEGAL_RULES);
      
      // Save immediately
      await Promise.all([
          saveAll('users', newUsers),
          saveAll('rooms', newRooms),
          saveAll('bookings', newBookings),
          saveAll('transactions', newTransactions),
          saveAll('notifications', newNotifications),
          saveAll('orders', newOrders),
          saveAll('guestHistory', newGuests),
          saveAll('maintenanceTickets', newMaintenance),
          saveAll('hallBookings', newHallBookings),
          saveAll('attendanceRecords', newAttendance),
          saveAll('poolPasses', newPoolPasses),
          saveAll('chatSessions', newChatSessions),
          saveAll('messages', newMessages),
          saveAll('serviceRequests', newServiceRequests),
          saveAll('externalOrders', newExternalOrders),
          saveAll('coordinationNotes', newCoordinationNotes),
          saveAll('incidentReports', newIncidentReports),
          saveAll('parkingSpots', INITIAL_PARKING_SPOTS),
          saveAll('legalRules', INITIAL_LEGAL_RULES)
      ]);
      
      addNotification('تم تحميل البيانات التجريبية بنجاح', 'success');
  };

  const addJobOpening = (job: Omit<JobOpening, 'id' | 'postedDate' | 'status'>) => {
      setJobOpenings(prev => {
          const updated = [...prev, { ...job, id: `job-${Date.now()}`, postedDate: new Date().toISOString(), status: 'open' }];
          saveAll('jobOpenings', updated);
          return updated;
      });
  };

  const updateJobOpening = (id: string, updates: Partial<JobOpening>) => {
      setJobOpenings(prev => {
          const updated = prev.map(j => j.id === id ? { ...j, ...updates } : j);
          saveAll('jobOpenings', updated);
          return updated;
      });
  };

  const addJobApplication = (app: Omit<JobApplication, 'id' | 'appliedDate' | 'status'>) => {
      setJobApplications(prev => {
          const updated = [...prev, { ...app, id: `app-${Date.now()}`, appliedDate: new Date().toISOString(), status: 'received' }];
          saveAll('jobApplications', updated);
          return updated;
      });
  };

  const updateJobApplicationStatus = (id: string, status: JobApplication['status']) => {
      setJobApplications(prev => {
          const updated = prev.map(a => a.id === id ? { ...a, status } : a);
          saveAll('jobApplications', updated);
          return updated;
      });
  };



  const addReservation = (res: Omit<Reservation, 'id' | 'createdAt' | 'status' | 'qrCodeData'>) => {
      const id = `res-${Date.now()}`;
      const qrData = generateSystemQR('RESERVATION', id, res.guestName, 1, { type: res.type, target: res.targetName });
      const newRes: Reservation = {
          ...res,
          id,
          createdAt: new Date().toISOString(),
          status: 'confirmed',
          qrCodeData: qrData
      };
      setReservations(prev => {
          const updated = [...prev, newRes];
          saveAll('reservations', updated);
          return updated;
      });
      addNotification(`تم تأكيد الحجز: ${res.targetName}`, 'success');
  };

  const updateReservation = (id: string, updates: Partial<Reservation>) => {
      setReservations(prev => {
          const updated = prev.map(r => r.id === id ? { ...r, ...updates } : r);
          saveAll('reservations', updated);
          return updated;
      });
      addNotification('تم تحديث الحجز بنجاح', 'success');
  };

  return (
    <HotelContext.Provider value={{
      currentUser, users, rooms, bookings, invoices, notifications, messages, settings, guestHistory, chatSessions, userShortcuts, transactions, hallBookings, poolPasses, restaurantOrders, qrRecords, maintenanceTickets, qrLogs,
      reservations, // New
      login, logout, forgetUser, recentUsers,
      updateUser, updateSettings, updatePageTitle, updateRoomStatus, updateRoomType, addBooking, updateBooking, extendBooking, addGuestToRoom, checkIn, checkOut, 
      addInvoice, updateInvoice, addTransaction, sendMessage, sendGuestMessage, replyToGuest, toggleChatMute, toggleShortcut,
      toggleDarkMode, setTheme, searchGuest, 
      activeToast, hideToast, moveToTrash, restoreNotification, deleteNotificationPermanently, emptyTrash, addNotification,
      addStaff, removeStaff, clearUserBalance,
      addHallBooking, cancelHallBooking, createPoolPass, invalidatePoolPass, 
      addRestaurantOrder, updateRestaurantOrder, inventory, updateInventory,
      menuItems, addMenuItem, updateMenuItem, deleteMenuItem, restaurantTables, updateTableStatus, chargeOrderToRoom, updateRestaurantOrderItems,
      addQRRecord, scanQRRecord, addMaintenanceTicket, resolveMaintenanceTicket,
      activeProfile, setActiveProfile,
      guestServices, serviceRequests, toggleServiceStatus, addNewService, removeService, requestService, updateServiceRequestStatus, updateServiceItem,
      moveBooking, splitBooking, securityLogs, addSecurityLog, 
      generateSystemQR, parseSystemQR,
      resetQRState, regenerateBookingQR,
      toggleGuestPresence,
      updateRoomPrices, updateStandardRate,
      leaveRequests, addLeaveRequest, updateLeaveStatus,
      staffRequests, submitStaffRequest,
      attendanceRecords, recordAttendance, updateAttendanceRecord,
      incidentReports, reportIncident, resolveIncident,
      addTable, removeTable, updateTableDetails,
      externalOrders, addExternalOrder, updateExternalOrderStatus,
      coordinationNotes, addCoordinationNote, resolveCoordinationNote,
      partners, addPartner, updatePartner, removePartner,
      servicePoints, addServicePoint, updateServicePoint,
      parkingSpots, addParkingSpot, updateParkingSpot,
      legalRules, addLegalRule, updateLegalRule,
      jobOpenings, addJobOpening, updateJobOpening,
      jobApplications, addJobApplication, updateJobApplicationStatus,
      deliveryDrivers, addDeliveryDriver, updateDriverStatus, assignDriverToOrder, rateDeliveryOrder,
      populateDemoData
    }}>
      {children}
    </HotelContext.Provider>
  );
};
