
import { AppSettings, Room, User, MenuItem, UserPermissions, ServiceItem, ParkingSpot, LegalRule } from './types';

// ... (Permissions constants remain same)
export const MANAGER_PERMISSIONS: UserPermissions = {
  canManageRooms: true,
  canManageBookings: true,
  canViewSecurityLink: true,
  canManageInvoices: true,
  canViewAccounting: true,
  canManageFinance: true,
  canManageStaff: true,
  canManageSettings: true,
  canManageMenu: true,
  canManageServices: true,
  canUseChat: true,
  canBroadcast: true,
  canPrintGuestForms: true,
};

export const ASSISTANT_MANAGER_PERMISSIONS: UserPermissions = {
  canManageRooms: true,
  canManageBookings: true,
  canViewSecurityLink: true,
  canManageInvoices: true,
  canViewAccounting: true,
  canManageFinance: false,
  canManageStaff: true,
  canManageSettings: false,
  canManageMenu: true,
  canManageServices: true,
  canUseChat: true,
  canBroadcast: true,
};

export const RECEPTIONIST_PERMISSIONS: UserPermissions = {
  canManageRooms: true,
  canManageBookings: true,
  canViewSecurityLink: true,
  canManageInvoices: true,
  canViewAccounting: false,
  canManageFinance: false,
  canManageStaff: false,
  canManageSettings: false,
  canManageMenu: false,
  canManageServices: false,
  canUseChat: true,
  canBroadcast: false,
  canPrintGuestForms: true,
};

export const FB_MANAGER_PERMISSIONS: UserPermissions = {
  canManageRooms: false,
  canManageBookings: false,
  canViewSecurityLink: false,
  canManageInvoices: true,
  canViewAccounting: false,
  canManageFinance: false,
  canManageStaff: false,
  canManageSettings: false,
  canManageMenu: true,
  canManageServices: false,
  canUseChat: true,
  canBroadcast: false,
};

export const STAFF_PERMISSIONS: UserPermissions = {
  canManageRooms: false, // Changed to false
  canManageBookings: false,
  canViewSecurityLink: false,
  canManageInvoices: false,
  canViewAccounting: false,
  canManageFinance: false,
  canManageStaff: false,
  canManageSettings: false,
  canManageMenu: false,
  canManageServices: false,
  canUseChat: true,
  canBroadcast: false,
};

export const HOUSEKEEPING_PERMISSIONS: UserPermissions = {
  canManageRooms: true, // Can update status
  canManageBookings: false,
  canViewSecurityLink: false,
  canManageInvoices: false,
  canViewAccounting: false,
  canManageFinance: false,
  canManageStaff: false,
  canManageSettings: false,
  canManageMenu: false,
  canManageServices: false,
  canUseChat: true,
  canBroadcast: false,
};

export const KITCHEN_PERMISSIONS: UserPermissions = {
  canManageRooms: false,
  canManageBookings: false,
  canViewSecurityLink: false,
  canManageInvoices: false,
  canViewAccounting: false,
  canManageFinance: false,
  canManageStaff: false,
  canManageSettings: false,
  canManageMenu: true, // Can update menu availability
  canManageServices: false,
  canUseChat: true,
  canBroadcast: false,
};

export const INITIAL_SETTINGS: AppSettings = {
  appName: 'AUTHENTIC ZELLIJ',
  welcomeTitle: 'مرحباً بكم في نظام AUTHENTIC ZELLIJ',
  totalRooms: 22,
  allowPrinting: true,
  theme: 'zellige', 
  themeStyle: 'flat', 
  themeVibrancy: 'normal',
  gridDensity: 'comfortable', 
  darkMode: false,
  themeLocked: false,
  invoiceHeaderImage: '',
  registrationHeaderImage: '',
  hotelAddress: 'الجزائر العاصمة، شارع الاستقلال 01',
  hotelPhone: '+213 550 00 00 00',
  hotelEmail: 'contact@authentic-zellij.com',
  taxNumber: 'RC: 12345678 / NIF: 987654321',
  invoiceFooterText: 'شكراً لاختياركم AUTHENTIC ZELLIJ. نتمنى لكم إقامة ممتعة.',
  roomPrices: {
    single: [
      { label: 'سعر عادي', amount: 3000 },
      { label: 'نصف يوم', amount: 2000 },
      { label: 'سعر خاص', amount: 2500 },
      { label: 'موسم العطلات', amount: 4000 },
    ],
    double: [
      { label: 'سعر عادي', amount: 5000 },
      { label: 'نصف يوم', amount: 3000 },
      { label: 'سعر خاص', amount: 4500 },
      { label: 'موسم العطلات', amount: 6000 },
    ],
    suite: [
      { label: 'سعر عادي', amount: 12000 },
      { label: 'نصف يوم', amount: 8000 },
      { label: 'VIP', amount: 15000 },
      { label: 'موسم العطلات', amount: 18000 },
    ],
    vip: [
       { label: 'سعر عادي', amount: 20000 },
       { label: 'نصف يوم', amount: 12000 },
       { label: 'شامل الخدمات', amount: 25000 },
       { label: 'رجال أعمال', amount: 30000 },
    ]
  },
  pageTitles: {
      'dashboard': 'لوحة المعلومات العامة',
      'rooms': 'حالة الغرف',
      'bookings': 'إدارة الحجوزات',
      'invoices': 'الفواتير والتقارير',
      'messages': 'المركز المراسلات',
      'staff': 'إدارة الموظفين',
      'accounting': 'المحاسبة',
      'events': 'قاعات المناسبات',
      'pool': 'النادي والمسبح',
      'restaurant': 'المطعم والمقهى',
      'reports': 'التقارير والتحليلات',
      'operations': 'مركز العمليات والتشغيل',
      'services': 'مدير الخدمات الرقمية',
      'security': 'بوابة التواصل الأمني',
      'print_settings': 'استوديو الطباعة',
      'pricing': 'دليل الأسعار والخدمات'
  },
  activeDepartments: ['administration', 'reception', 'housekeeping', 'food_beverage', 'maintenance'],
  salaryDate: '28',
  marketingConfig: {
      siteUrl: 'https://authentic-zellij.com',
      promoTitle: 'استمتع بتجربة فاخرة',
      promoDescription: 'اكتشف خدماتنا الحصرية واحجز إقامتك القادمة بأفضل الأسعار.',
      buttonText: 'زيارة الموقع الرسمي'
  },
  printConfig: {
      defaultWeddingTemplate: 'royal_andalus',
      defaultMeetingTemplate: 'modern_corporate',
      defaultTicketTemplate: 'classic_ticket',
      defaultRegistrationTemplate: 'classic_reg',
      customFooterText: 'نتشرف بحضوركم',
      showQrCode: true
  },
  standardRates: {
      poolAccess: 2000,
      poolVipAccess: 5000,
      hallBasePrice: 50000,
      hallWeekendSurcharge: 10000,
      breakfastPrice: 800,
      lateArrivalFine: 500
  },
  hotelIdentity: {
      openingDate: '2020-01-01',
      stars: 4,
      classificationType: 'Business',
      crNumber: '16/00-8742912',
      managerName: 'السيد المدير العام',
      bio: 'فندق عريق يجمع بين الأصالة والحداثة في قلب المدينة، يقدم خدمات فندقية راقية لرجال الأعمال والعائلات.',
      globalRank: '#1',
      website: 'www.authentic-zellij.com',
      email: 'info@authentic-zellij.com'
  },
  systemIntegrations: {
      guestWifiSsid: 'Authentic_Guest_Free',
      guestWifiPass: 'Welcome2024',
      staffWifiSsid: 'Authentic_Staff_Secure',
      bookingEngineUrl: 'https://admin.booking.com',
      otaManagerUrl: 'https://expedia.com/partner',
      kitchenKdsUrl: 'http://192.168.1.100:3000',
      localServerIp: '192.168.1.50',
      housekeepingPortalUrl: 'http://housekeeping.local',
      printerIp: '192.168.1.200',
      kioskMode: false,
      policePortalUrl: 'https://police.dz/hotels',
      tourismPortalUrl: 'https://mta.gov.dz'
  },
  digitizationEnabled: true,
  defaultNationality: 'الجزائرية',
  roomConfig: {
      startingNumber: 101,
      prefix: '',
      floorCount: 3,
      roomsPerFloor: 10
  },
  buildings: [
      { id: 'b1', name: 'المبنى الرئيسي', address: 'شارع الاستقلال 01', roomCount: 22, isActive: true }
  ],
  partners: []
};

export const isZelligeTheme = (theme: string) => {
  return theme.startsWith('zellige');
};

export const CHAT_GROUPS = {
  GENERAL: 'GROUP_GENERAL',
  MANAGEMENT: 'GROUP_MANAGEMENT',
  RECEPTION: 'GROUP_RECEPTION',
  OPERATIONS: 'GROUP_OPERATIONS',
};

export const MOCK_USERS: User[] = [
  { 
    id: 'u1', 
    name: 'المدير العام', 
    role: 'manager', 
    department: 'administration',
    isHeadOfDepartment: true,
    salary: 250000,
    joinDate: '2020-01-01',
    avatar: 'https://picsum.photos/100/100?random=1',
    isBlocked: false,
    permissions: MANAGER_PERMISSIONS,
    phone: '0550123456',
    email: 'manager@authentic-zellij.com',
    status: 'active'
  },
  { 
    id: 'u2', 
    name: 'أحمد (استقبال)', 
    role: 'receptionist', 
    department: 'reception',
    isHeadOfDepartment: true,
    salary: 60000,
    joinDate: '2021-05-12',
    avatar: 'https://picsum.photos/100/100?random=2',
    isBlocked: false,
    permissions: RECEPTIONIST_PERMISSIONS,
    phone: '0550987654',
    email: 'reception@authentic-zellij.com',
    status: 'active'
  },
];

export const generateRooms = (count: number): Room[] => {
  return Array.from({ length: count }, (_, i) => ({
    id: i + 1,
    number: `${i + 1}`,
    type: i < 15 ? 'single' : i < 20 ? 'double' : 'suite',
    status: 'available',
    price: 100 + (i % 3) * 50,
  }));
};

export const DEFAULT_MENU: MenuItem[] = [
    { id: 'hd1', name: 'قهوة اسبريسو', category: 'hot_drink', price: 150, isAvailable: true, description: 'حبوب أرابيكا فاخرة' },
    { id: 'hd2', name: 'كابتشينو', category: 'hot_drink', price: 250, isAvailable: true, description: 'رغوة حليب كثيفة' },
    { id: 'hd3', name: 'شاي بالنعناع', category: 'hot_drink', price: 200, isAvailable: true, description: 'إبريق صغير' },
    { id: 'hd4', name: 'لاتيه كراميل', category: 'hot_drink', price: 300, isAvailable: true, description: 'نكهة الكراميل المملح' },
    { id: 'hd5', name: 'شوكولاتة ساخنة', category: 'hot_drink', price: 350, isAvailable: true, description: 'مع الكريمة' },
    { id: 'cd1', name: 'ماء معدني (صغير)', category: 'cold_drink', price: 50, isAvailable: true },
    { id: 'cd2', name: 'ماء معدني (كبير)', category: 'cold_drink', price: 100, isAvailable: true },
    { id: 'cd3', name: 'مشروب غازي', category: 'cold_drink', price: 150, isAvailable: true, description: 'كوكا، فانتا، سبرايت' },
    { id: 'cd4', name: 'عصير برتقال طازج', category: 'cold_drink', price: 400, isAvailable: true },
    { id: 'cd5', name: 'موهيتو كلاسيك', category: 'cold_drink', price: 350, isAvailable: true, description: 'ليمون ونعناع' },
    { id: 'cd6', name: 'ميلك شيك فانيليا', category: 'cold_drink', price: 450, isAvailable: true },
    { id: 'cd7', name: 'ليمونادة', category: 'cold_drink', price: 300, isAvailable: true },
    { id: 'ds1', name: 'تشيز كيك', category: 'dessert', price: 600, isAvailable: true, description: 'توت أزرق أو فراولة' },
    { id: 'ds2', name: 'تيراميسو', category: 'dessert', price: 550, isAvailable: true, description: 'على الطريقة الإيطالية' },
    { id: 'ds3', name: 'سلطة فواكه', category: 'dessert', price: 450, isAvailable: true, description: 'فواكه موسمية طازجة' },
    { id: 'ds4', name: 'كريب نوتيلا', category: 'dessert', price: 400, isAvailable: true },
    { id: 'ds5', name: 'أيس كريم (3 كرات)', category: 'dessert', price: 350, isAvailable: true },
    { id: 'bk1', name: 'فطور صباحي كامل', category: 'breakfast', price: 1200, isAvailable: true, description: 'بيض، أجبان، مربى، كرواسون، مشروب' },
    { id: 'bk2', name: 'أومليت خضار', category: 'breakfast', price: 500, isAvailable: true },
    { id: 'bk3', name: 'بان كيك بالعسل', category: 'breakfast', price: 450, isAvailable: true },
    { id: 'ml1', name: 'شريحة لحم مشوي (Entrecôte)', category: 'meal', price: 2500, isAvailable: true, description: 'مع بطاطا وخضار سوتيه' },
    { id: 'ml2', name: 'دجاج محمر', category: 'meal', price: 1200, isAvailable: true, description: 'نصف دجاجة مع أرز' },
    { id: 'ml3', name: 'سلطة سيزر', category: 'meal', price: 800, isAvailable: true, description: 'دجاج مشوي، خس، جبن بارميزان' },
    { id: 'ml4', name: 'شوربة اليوم', category: 'meal', price: 400, isAvailable: true },
    { id: 'ml5', name: 'كلوب ساندويتش', category: 'meal', price: 600, isAvailable: true, description: 'وجبة خفيفة (مناسب للمقهى)' },
    { id: 'ml6', name: 'برجر كلاسيك', category: 'meal', price: 700, isAvailable: true, description: 'مع بطاطا مقلية' },
    { id: 'ml7', name: 'بيتزا مارجريتا', category: 'meal', price: 600, isAvailable: true },
    { id: 'ml8', name: 'طاجين زيتون', category: 'meal', price: 1400, isAvailable: true, description: 'طبق تقليدي' },
];

export const INITIAL_SERVICES: ServiceItem[] = [
    { id: 'srv1', icon: 'Bell', labelAr: 'تنظيف الغرفة', labelEn: 'Room Cleaning', description: 'طلب تنظيف فوري للغرفة', targetDepartment: 'housekeeping', isActive: true, allowedLocations: ['room', 'suite', 'vip'], price: 0 },
    { id: 'srv2', icon: 'Coffee', labelAr: 'مشروبات', labelEn: 'Beverages', description: 'قهوة، شاي، أو مياه', targetDepartment: 'food_beverage', isActive: true, allowedLocations: ['all'], price: 0 },
    { id: 'srv3', icon: 'Car', labelAr: 'طلب تاكسي', labelEn: 'Taxi Request', description: 'حجز سيارة أجرة', targetDepartment: 'reception', isActive: true, allowedLocations: ['all'], price: 500 },
    { id: 'srv4', icon: 'Shirt', labelAr: 'مكواة ملابس', labelEn: 'Ironing', description: 'طلب طاولة ومكواة', targetDepartment: 'housekeeping', isActive: true, allowedLocations: ['room', 'suite'], price: 0 },
];

export const INITIAL_INVENTORY: any[] = [
    { id: 'inv1', name: 'صابون سائل', quantity: 50, unit: 'لتر', minThreshold: 10, category: 'cleaning', lastUpdated: '2023-01-01' },
    { id: 'inv2', name: 'مناشف حمام', quantity: 200, unit: 'قطعة', minThreshold: 50, category: 'amenities', lastUpdated: '2023-01-01' },
    { id: 'inv3', name: 'قهوة حبوب', quantity: 20, unit: 'كغ', minThreshold: 5, category: 'food', lastUpdated: '2023-01-01' },
];

export const INITIAL_TABLES: any[] = [
    // Restaurant Tables (R)
    { id: 'R1', number: 'R1', capacity: 4, status: 'available', zone: 'main_hall', location: 'restaurant' },
    { id: 'R2', number: 'R2', capacity: 2, status: 'occupied', zone: 'main_hall', location: 'restaurant' },
    { id: 'R3', number: 'R3', capacity: 6, status: 'reserved', zone: 'vip_corner', location: 'restaurant' },
    { id: 'R4', number: 'R4', capacity: 4, status: 'available', zone: 'terrace', location: 'restaurant' },
    { id: 'R5', number: 'R5', capacity: 2, status: 'cleaning', zone: 'main_hall', location: 'restaurant' },
    { id: 'R6', number: 'R6', capacity: 8, status: 'available', zone: 'vip_corner', location: 'restaurant' },
    
    // Cafe Tables (C)
    { id: 'C1', number: 'C1', capacity: 2, status: 'available', zone: 'garden', location: 'cafe' },
    { id: 'C2', number: 'C2', capacity: 4, status: 'occupied', zone: 'main_hall', location: 'cafe' },
    { id: 'C3', number: 'C3', capacity: 2, status: 'available', zone: 'terrace', location: 'cafe' },
    { id: 'C4', number: 'C4', capacity: 3, status: 'available', zone: 'garden', location: 'cafe' },
    { id: 'C5', number: 'C5', capacity: 2, status: 'cleaning', zone: 'main_hall', location: 'cafe' },
];

export const INITIAL_PARKING_SPOTS: ParkingSpot[] = [
    { id: 'p1', number: 'A-01', type: 'shaded', status: 'available', pricePerHour: 200, pricePerDay: 1500, services: ['cleaning'] },
    { id: 'p2', number: 'A-02', type: 'shaded', status: 'occupied', pricePerHour: 200, pricePerDay: 1500, services: [] },
    { id: 'p3', number: 'B-01', type: 'unshaded', status: 'available', pricePerHour: 100, pricePerDay: 800, services: [] },
    { id: 'p4', number: 'V-01', type: 'vip', status: 'reserved', pricePerHour: 500, pricePerDay: 3000, services: ['valet', 'cleaning'] },
];

export const INITIAL_LEGAL_RULES: LegalRule[] = [
    { id: 'lr1', title: 'سياسة التدخين', content: 'يمنع التدخين في جميع الغرف والممرات الداخلية. يسمح به فقط في المناطق المخصصة.', category: 'hotel_policy', isActive: true },
    { id: 'lr2', title: 'استخدام المسبح', content: 'يجب ارتداء ملابس السباحة المناسبة. يمنع القفز في المناطق الضحلة.', category: 'facility_rule', isActive: true },
    { id: 'lr3', title: 'إخلاء المسؤولية', content: 'الفندق غير مسؤول عن فقدان الأشياء الثمينة غير المودعة في الخزنة.', category: 'legal_advice', isActive: true },
];
