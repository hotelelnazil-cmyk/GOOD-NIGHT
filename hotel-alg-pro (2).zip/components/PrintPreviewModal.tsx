
import React from 'react';
import { Modal } from './Modal';
import { Printer } from 'lucide-react';
import { useHotel } from '../context/HotelContext';
import { QRCodeSVG } from 'qrcode.react';
import { printDocument } from '../utils/print';

interface PrintPreviewModalProps {
    isOpen: boolean;
    onClose: () => void;
    title: string;
    content: React.ReactNode; // The content to print (React Node)
    htmlContent?: string; // Optional raw HTML for printing
    onPrint?: () => void;
    qrCodeValue?: string; // Optional QR code value
}

export const PrintPreviewModal: React.FC<PrintPreviewModalProps> = ({ isOpen, onClose, title, content, htmlContent, onPrint, qrCodeValue }) => {
    const { settings } = useHotel();

    const handlePrint = () => {
        if (onPrint) {
            onPrint();
            return;
        }

        printDocument({
            title,
            content: htmlContent || content || '',
            qrCodeValue,
            settings
        });
    };

    const isZellige = settings.theme === 'zellige' || settings.theme === 'zellige-v2';
    const isDark = settings.darkMode;

    const buttonStyles = {
        cancel: isZellige 
            ? (isDark ? 'bg-[#002a2d] text-[#cca43b] hover:bg-[#cca43b]/10 border border-[#cca43b]/30' : 'bg-[#fbf8f1] text-[#006269] hover:bg-[#cca43b]/10 border border-[#cca43b]/20')
            : 'bg-gray-100 text-gray-700 hover:bg-gray-200',
        print: isZellige
            ? (isDark ? 'bg-[#cca43b] text-[#001e21] hover:bg-[#b08d30]' : 'bg-[#006269] text-[#cca43b] hover:bg-[#004d53]')
            : 'bg-blue-600 text-white hover:bg-blue-700'
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={`معاينة الطباعة: ${title}`} size="lg">
            <div className="flex flex-col h-[70vh]">
                <div className="flex-1 overflow-y-auto overflow-x-auto p-8 bg-white border rounded-xl shadow-inner mb-4 custom-scrollbar text-black">
                    <div className="print-preview-content min-w-fit">
                        {htmlContent ? <div dangerouslySetInnerHTML={{ __html: htmlContent }} /> : content}
                        {qrCodeValue && settings.printConfig.showQrCode && (
                            <div className="mt-8 pt-8 border-t flex flex-col items-center justify-center opacity-50">
                                <QRCodeSVG value={qrCodeValue} size={100} />
                                <p className="text-[10px] mt-2 font-mono">{qrCodeValue}</p>
                            </div>
                        )}
                    </div>
                </div>
                <div className={`flex justify-end gap-3 pt-4 border-t ${isDark ? 'border-gray-700' : 'border-gray-100'}`}>
                    <button onClick={onClose} className={`px-6 py-2 rounded-xl font-bold ${buttonStyles.cancel}`}>إلغاء</button>
                    <button onClick={handlePrint} className={`px-8 py-2 rounded-xl font-black shadow-lg flex items-center gap-2 ${buttonStyles.print}`}>
                        <Printer size={20}/> طباعة
                    </button>
                </div>
            </div>
        </Modal>
    );
};
