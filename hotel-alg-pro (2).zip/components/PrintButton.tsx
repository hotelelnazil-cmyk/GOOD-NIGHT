import React, { useState } from 'react';
import { Printer } from 'lucide-react';
import { PrintPreviewModal } from './PrintPreviewModal';
import { useHotel } from '../context/HotelContext';
import { printDocument } from '../utils/print';

interface PrintButtonProps {
    title: string;
    content?: React.ReactNode;
    htmlContent?: string; // Optional raw HTML
    className?: string;
    label?: string;
    iconSize?: number;
    qrCodeValue?: string;
    instantPrint?: boolean; // New prop for instant printing
}

export const PrintButton: React.FC<PrintButtonProps> = ({ 
    title, 
    content, 
    htmlContent, 
    className, 
    label = "طباعة", 
    iconSize = 18, 
    qrCodeValue,
    instantPrint = false 
}) => {
    const [isOpen, setIsOpen] = useState(false);
    const { settings } = useHotel();

    const handlePrint = (e: React.MouseEvent) => {
        e.stopPropagation();
        if (instantPrint) {
            printDocument({
                title,
                content: htmlContent || content || '',
                qrCodeValue,
                settings
            });
        } else {
            setIsOpen(true);
        }
    };

    return (
        <>
            <button 
                onClick={handlePrint} 
                className={className || "flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg font-bold transition"}
                title={label}
            >
                <Printer size={iconSize} />
                {label && <span>{label}</span>}
            </button>

            {isOpen && (
                <PrintPreviewModal 
                    isOpen={isOpen} 
                    onClose={() => setIsOpen(false)} 
                    title={title} 
                    content={content || null}
                    htmlContent={htmlContent}
                    qrCodeValue={qrCodeValue}
                />
            )}
        </>
    );
};
