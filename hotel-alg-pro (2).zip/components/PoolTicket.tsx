import React from 'react';
import { PoolPass } from '../types';
import { QRCodeSVG } from 'qrcode.react';

interface PoolTicketProps {
    pass: PoolPass;
    appName: string;
    qrUrl?: string;
}

export const PoolTicket: React.FC<PoolTicketProps> = ({ pass, appName }) => {
    const qrValue = `POOL:${pass.id}|GUEST:${pass.holderName}|ZONE:${pass.accessZone}`;

    return (
        <div className="w-[350px] bg-white text-black font-sans border border-gray-200 rounded-3xl overflow-hidden relative mx-auto my-4 shadow-sm print:shadow-none print:border-black print:rounded-none print:w-full print:max-w-[80mm] print:break-inside-avoid">
            {/* Header */}
            <div className="bg-[#0093E9] bg-[linear-gradient(160deg,#0093E9_0%,#80D0C7_100%)] text-white p-6 text-center relative overflow-hidden print:bg-none print:text-black print:border-b print:border-black print:p-4">
                <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] print:hidden"></div>
                <h1 className="text-2xl font-black tracking-widest uppercase relative z-10 drop-shadow-md print:drop-shadow-none print:text-xl">{appName}</h1>
                <p className="text-[10px] font-bold tracking-[0.3em] uppercase opacity-90 relative z-10 mt-1 print:text-black">Pool & Club Access</p>
                
                {/* Decorative Circle - Hidden in print */}
                <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-white/10 rounded-full blur-2xl print:hidden"></div>
            </div>

            {/* Body */}
            <div className="p-6 relative print:p-4">
                {/* Side Cutouts (Visual Only) - Hidden in print */}
                <div className="absolute top-0 left-0 w-6 h-6 bg-white rounded-full -translate-x-3 -translate-y-3 border-b border-r border-gray-200 print:hidden shadow-[inset_-2px_-2px_2px_rgba(0,0,0,0.05)]"></div>
                <div className="absolute top-0 right-0 w-6 h-6 bg-white rounded-full translate-x-3 -translate-y-3 border-b border-l border-gray-200 print:hidden shadow-[inset_2px_-2px_2px_rgba(0,0,0,0.05)]"></div>

                <div className="text-center mb-6 print:mb-4">
                    <p className="text-[10px] font-bold text-gray-400 uppercase mb-1 tracking-wider print:text-black">Guest Name</p>
                    <h2 className="text-xl font-black uppercase text-gray-900 leading-none print:text-black">{pass.holderName}</h2>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-8 border-b border-dashed border-gray-200 pb-6 print:border-black print:mb-4 print:pb-4">
                    <div className="text-left">
                        <p className="text-[9px] font-bold text-gray-400 uppercase tracking-wider print:text-black">Date</p>
                        <p className="font-bold text-sm">{new Date(pass.date).toLocaleDateString()}</p>
                    </div>
                    <div className="text-right">
                        <p className="text-[9px] font-bold text-gray-400 uppercase tracking-wider print:text-black">Valid Until</p>
                        <p className="font-bold text-sm">{pass.expiryTime}</p>
                    </div>
                    <div className="text-left">
                        <p className="text-[9px] font-bold text-gray-400 uppercase tracking-wider print:text-black">Zone</p>
                        <p className="font-bold text-sm capitalize">{pass.accessZone.replace('_', ' ')}</p>
                    </div>
                    <div className="text-right">
                        <p className="text-[9px] font-bold text-gray-400 uppercase tracking-wider print:text-black">Type</p>
                        <span className="inline-block px-2 py-0.5 bg-blue-50 text-blue-600 rounded text-[10px] font-black uppercase tracking-wide print:bg-transparent print:text-black print:border print:border-black">{pass.type}</span>
                    </div>
                </div>

                <div className="flex flex-col items-center justify-center gap-2">
                     <div className="p-2 border-2 border-gray-100 rounded-xl print:border-black">
                        <QRCodeSVG value={qrValue} size={120} level="M" />
                     </div>
                     <p className="text-[9px] font-mono text-gray-400 uppercase tracking-widest mt-1 print:text-black">{pass.id}</p>
                </div>
            </div>

            {/* Footer */}
            <div className="bg-gray-50 p-3 text-center border-t border-gray-100 print:bg-transparent print:border-black">
                <p className="text-[8px] text-gray-400 leading-tight font-medium print:text-black">
                    NON-TRANSFERABLE • SHOW AT ENTRY • NO REFUNDS
                </p>
            </div>
        </div>
    );
};
