
import React, { useState, useMemo, useEffect } from 'react';
import { useHotel } from '../context/HotelContext';
import { 
  Home, BedDouble, Receipt, Bell, Send, 
  LayoutGrid, PartyPopper, Waves,
  Building2, Info, ChevronRight, CornerUpRight, Sun, Moon, Lock, User, ShieldCheck, Inbox, Coffee, QrCode, Shield,
  CheckCircle, AlertOctagon, AlertTriangle, Briefcase, Settings, Utensils, MessageSquare, Truck, Tent, Trees, Car, Scale, Store, Users, Calendar
} from 'lucide-react';
import { AppTheme, Notification } from '../types';
import { StaffProfileModal } from './StaffProfileModal';

interface LayoutProps {
  children: React.ReactNode;
  activePage: string;
  setActivePage: (page: string) => void;
}

const ToastNotification = ({ notification, onClose, onClick, onDelete, theme }: { notification: Notification, onClose: () => void, onClick: () => void, onDelete: () => void, theme: AppTheme }) => {
    const getStatusStyles = () => {
        switch (notification.type) {
            case 'success': return { icon: <CheckCircle size={24} />, color: 'text-green-600', bg: 'bg-green-100', border: 'border-green-200' };
            case 'error': return { icon: <AlertOctagon size={24} />, color: 'text-red-600', bg: 'bg-red-100', border: 'border-red-200' };
            case 'warning': return { icon: <AlertTriangle size={24} />, color: 'text-orange-600', bg: 'bg-orange-100', border: 'border-orange-200' };
            default: return { icon: <Info size={24} />, color: 'text-blue-600', bg: 'bg-blue-100', border: 'border-blue-200' };
        }
    };
    const status = getStatusStyles();
    return (
        <div className="fixed top-6 left-1/2 -translate-x-1/2 z-[150] animate-fade-in-up w-[95%] max-w-md">
            <div className={`rounded-[2rem] p-5 flex flex-col gap-3 relative overflow-hidden border-2 bg-white shadow-2xl`}>
                <div className="flex items-start gap-4 relative z-10">
                    <div className={`p-3 rounded-2xl shrink-0 ${status.bg} ${status.color} shadow-sm`}>{status.icon}</div>
                    <div className="flex-1 pt-1">
                        <p className={`font-black text-base leading-tight`}>{notification.message}</p>
                        {notification.details && <p className="text-xs opacity-80 mt-1.5 font-medium leading-relaxed line-clamp-2">{notification.details}</p>}
                    </div>
                </div>
                <div className="flex items-center gap-2 mt-2 pt-3 border-t border-black/5 relative z-10">
                    <button onClick={onClick} className="flex-1 py-2.5 rounded-xl font-bold text-sm shadow-sm bg-blue-600 text-white flex items-center justify-center gap-2">
                        {notification.actionLabel || 'عرض'}
                    </button>
                    <button onClick={onClose} className="flex-1 py-2.5 rounded-xl font-bold text-sm bg-gray-100 flex items-center justify-center gap-2">تأجيل</button>
                </div>
            </div>
        </div>
    );
};

const getMainBackground = (theme: AppTheme, darkMode: boolean, vibrancy: string) => {
  if (darkMode) {
      if (theme === 'zellige') return "bg-[#001517] text-gray-100"; // Deep Dark Teal
      if (theme === 'zellige-v2') return "bg-[#001a14] text-gray-100";
      if (theme === 'zellige-algiers') return "bg-[#0f172a] text-gray-100"; // Dark Slate
      if (theme === 'zellige-tlemcen') return "bg-[#271c19] text-gray-100"; // Dark Earth
      if (theme === 'zellige-sahara') return "bg-[#2a1b12] text-gray-100"; // Dark Sand
      if (theme === 'zellige-chaoui') return "bg-[#2f1b0c] text-gray-100"; // Dark Earth
      if (theme === 'zellige-tergui') return "bg-[#0a0a2a] text-gray-100"; // Dark Indigo
      if (theme === 'zellige-mozabite') return "bg-[#1c1c1c] text-gray-100"; // Dark Neutral
      if (theme === 'modern-ornate') return "bg-[#12031a] text-gray-100";
      return "bg-[#0f172a] text-gray-100";
  }
  if (theme === 'zellige-algiers') return "bg-[#eff6ff] text-slate-900";
  if (theme === 'zellige-tlemcen') return "bg-[#fffbeb] text-slate-900";
  if (theme === 'zellige-sahara') return "bg-[#fff7ed] text-slate-900";
  if (theme === 'zellige-chaoui') return "bg-[#fff8dc] text-slate-900";
  if (theme === 'zellige-tergui') return "bg-[#f0f8ff] text-slate-900";
  if (theme === 'zellige-mozabite') return "bg-[#fffaf0] text-slate-900";
  return "bg-[#f8fafc] text-slate-900";
};

export const Layout: React.FC<LayoutProps> = ({ children, activePage, setActivePage }) => {
  const { settings, currentUser, logout, toggleDarkMode, notifications, activeToast, hideToast, moveToTrash, serviceRequests, addRestaurantOrder, addNotification } = useHotel();
  const [isBottomSheetOpen, setIsBottomSheetOpen] = useState(false);
  const [isNativeKeyboardOpen, setIsNativeKeyboardOpen] = useState(false);
  const [hasOpenModal, setHasOpenModal] = useState(false);
  const [isBottomNavVisible, setIsBottomNavVisible] = useState(true); // New State for Toggle

  // --- Listen for Guest Orders ---
  useEffect(() => {
      const handleGuestOrder = (e: any) => {
          const order = e.detail;
          addRestaurantOrder(order);
          addNotification("طلب جديد من النزيل", "success", `طلب #${order.id.slice(-4)} - ${order.totalAmount} د.ج`);
      };
      window.addEventListener('guest-order-placed', handleGuestOrder);
      return () => window.removeEventListener('guest-order-placed', handleGuestOrder);
  }, [addRestaurantOrder, addNotification]);

  // --- Modal & Keyboard Detection ---
  useEffect(() => {
      let timeoutId: NodeJS.Timeout;
      const checkModals = () => {
          const modals = document.querySelectorAll('.z-\\[100\\], .z-\\[200\\]');
          setHasOpenModal(modals.length > 0);
      };
      
      const observer = new MutationObserver(() => {
          clearTimeout(timeoutId);
          timeoutId = setTimeout(checkModals, 100);
      });
      
      checkModals();
      observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
      return () => {
          observer.disconnect();
          clearTimeout(timeoutId);
      };
  }, []);

  useEffect(() => {
      const handleFocus = (e: FocusEvent) => {
          const target = e.target as HTMLElement;
          if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT') {
              setIsNativeKeyboardOpen(true);
              document.body.classList.add('keyboard-open');
          }
      };
      const handleBlur = () => {
          setIsNativeKeyboardOpen(false);
          document.body.classList.remove('keyboard-open');
      };
      document.addEventListener('focusin', handleFocus);
      document.addEventListener('focusout', handleBlur);
      return () => {
          document.removeEventListener('focusin', handleFocus);
          document.removeEventListener('focusout', handleBlur);
          document.body.classList.remove('keyboard-open');
      };
  }, []);

  const myNotifications = useMemo(() => {
      if (!currentUser) return [];
      return notifications.filter(n => {
          if (n.hiddenFor.includes(currentUser.id) || n.isTrashed) return false;
          if (n.targetDepartments && !n.targetDepartments.includes(currentUser.department) && currentUser.role !== 'manager') return false;
          if (n.targetRoles && !n.targetRoles.includes(currentUser.role)) return false;
          if (n.targetUsers && !n.targetUsers.includes(currentUser.id)) return false;
          return true;
      });
  }, [notifications, currentUser]);

  const activeRequestsCount = useMemo(() => {
      return serviceRequests.filter(r => r.status === 'pending').length;
  }, [serviceRequests]);

  useEffect(() => {
    if (settings.darkMode) document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
  }, [settings.darkMode]);

  useEffect(() => {
      const handleCustomNav = (e: any) => setActivePage(e.detail);
      window.addEventListener('navigate-to', handleCustomNav);
      return () => window.removeEventListener('navigate-to', handleCustomNav);
  }, [setActivePage]);

  const handleGlobalBack = () => window.dispatchEvent(new Event('go-back'));

  const handleLockApp = (e: React.MouseEvent) => {
      e.stopPropagation();
      if (window.confirm("هل أنت متأكد من قفل النظام؟")) {
          logout();
      }
  };

  // --- REORGANIZED NAVIGATION STRUCTURE ---
  const navStructure = useMemo(() => {
      const role = currentUser?.role;
      const dept = currentUser?.department;

      const basicNav = [];

      // 1. MAIN DASHBOARD (Everyone)
      const mainItems: { id: string; label: string; icon: any; count?: number }[] = [{ id: 'dashboard', label: 'الرئيسية', icon: Home }];
      
      // Accommodation: Reception, Managers ONLY
      if (['manager', 'assistant_manager', 'reception_manager', 'receptionist'].includes(role || '')) {
          mainItems.push({ id: 'accommodation', label: 'الإقامة والغرف', icon: BedDouble });
      }
      
      // Requests: Reception, Managers, Concierge
      if (['manager', 'assistant_manager', 'reception_manager', 'receptionist', 'concierge'].includes(role || '')) {
          mainItems.push({ id: 'requests', label: 'طلبات النزلاء', icon: Inbox, count: activeRequestsCount });
      }

      basicNav.push({
          title: 'الواجهة الرئيسية',
          items: mainItems
      });

      // 2. OUTLETS (Food, Pool, Events)
      const outletItems = [];
      
      // Restaurant/Cafe: FB Staff, Managers
      if (['manager', 'assistant_manager', 'restaurant_manager', 'head_chef', 'chef', 'waiter', 'cafe_manager', 'barista'].includes(role || '')) {
          outletItems.push({ id: 'restaurant', label: 'المطعم والمطبخ', icon: Utensils });
          outletItems.push({ id: 'cafe', label: 'المقهى (Coffee Shop)', icon: Coffee });
          outletItems.push({ id: 'delivery', label: 'التوصيل والخدمات', icon: Truck }); // New
          outletItems.push({ id: 'reservations', label: 'الحجوزات', icon: Calendar }); // New
      }

      // Pool: Pool Staff, Managers, Reception (for selling passes)
      if (['manager', 'assistant_manager', 'reception_manager', 'receptionist', 'security_manager'].includes(role || '')) {
           outletItems.push({ id: 'pool', label: 'المسبح والنادي', icon: Waves });
      }

      // Events: Managers, Reception
      if (['manager', 'assistant_manager', 'reception_manager', 'receptionist'].includes(role || '')) {
          outletItems.push({ id: 'events', label: 'قاعات المناسبات', icon: PartyPopper });
          outletItems.push({ id: 'venues', label: 'الساحات والأكشاك', icon: Tent });
          outletItems.push({ id: 'garden_oasis', label: 'واحة البستان', icon: Trees });
          outletItems.push({ id: 'parking', label: 'موقف السيارات', icon: Car });
          outletItems.push({ id: 'kiosk_manager', label: 'إدارة الأكشاك', icon: Store });
      }

      if (outletItems.length > 0) {
          basicNav.push({
              title: 'المرافق (Outlet)',
              items: outletItems
          });
      }

      // 3. OPERATIONS
      const opsItems = [];
      
      // Coordination: Managers, Heads of Dept
      if (currentUser?.isHeadOfDepartment || role === 'manager' || role === 'assistant_manager') {
          opsItems.push({ id: 'coordination', label: 'نافذة التنسيق', icon: MessageSquare });
      }

      // External Services: Concierge, Reception, Managers
      if (['manager', 'assistant_manager', 'reception_manager', 'receptionist', 'concierge'].includes(role || '')) {
          opsItems.push({ id: 'external_services', label: 'خدمات خارجية', icon: Truck });
      }

      // Operations (Maintenance/Housekeeping/Security): Relevant Staff + Managers
      if (['manager', 'assistant_manager', 'maintenance_manager', 'maintenance_staff', 'housekeeping_manager', 'housekeeping_staff', 'security_manager', 'security_guard'].includes(role || '')) {
          opsItems.push({ id: 'operations', label: 'الصيانة والمخالفات', icon: AlertOctagon });
      }

      // Staff Management: HR, Managers
      if (['manager', 'assistant_manager', 'hr_manager'].includes(role || '')) {
          opsItems.push({ id: 'staff', label: 'شؤون الموظفين', icon: Briefcase });
          opsItems.push({ id: 'recruitment', label: 'التوظيف', icon: Users });
      }

      // Messages: Everyone
      opsItems.push({ id: 'messages', label: 'المراسلات', icon: Send });

      if (opsItems.length > 0) {
          basicNav.push({
              title: 'العمليات والمساندة',
              items: opsItems
          });
      }

      // 4. TOOLS (Everyone)
      basicNav.push({
          title: 'أدوات الوصول',
          items: [
            { id: 'qr_scanner', label: 'الماسح الضوئي', icon: QrCode },
            { id: 'notifications', label: 'الإشعارات', icon: Bell, count: myNotifications.length },
          ]
      });

      // 5. ADMIN (Managers Only)
      if (['manager', 'assistant_manager', 'accountant'].includes(role || '')) {
          const adminItems = [];
          if (role !== 'accountant') adminItems.push({ id: 'admin_hub', label: 'لوحة القيادة', icon: ShieldCheck });
          adminItems.push({ id: 'invoices', label: 'الفواتير والمالية', icon: Receipt });
          
          basicNav.push({
              title: 'الإدارة العليا',
              items: adminItems
          });
      }

      // 6. SYSTEM (Managers Only)
      if (['manager', 'it_specialist'].includes(role || '')) {
          basicNav.push({
              title: 'النظام',
              items: [
                  { id: 'settings', label: 'الإعدادات', icon: Settings },
                  { id: 'legal', label: 'السياسات والقوانين', icon: Scale }, // New
                  { id: 'about', label: 'هوية الفندق', icon: Info },
              ]
          });
      }

      return basicNav;
  }, [myNotifications, currentUser, activeRequestsCount]);

  const allNavItems = navStructure.flatMap(g => g.items);
  const mainBgClass = getMainBackground(settings.theme, settings.darkMode, settings.themeVibrancy);

  // --- Theme Styling Functions ---
  const getSidebarStyle = () => {
      const base = "hidden md:flex flex-col w-72 h-full z-40 transition-all duration-300 ease-in-out border-l shrink-0 relative overflow-hidden shadow-2xl";
      
      // Enhanced Dark Mode Logic
      if (settings.darkMode) {
          switch (settings.theme) {
              case 'zellige': return `${base} bg-[#001e21] border-[#cca43b]/30`; // Deep Dark Teal with Gold border
              case 'zellige-v2': return `${base} bg-[#012a20] border-[#024d38]/50`;
              case 'zellige-algiers': return `${base} bg-[#0f172a] border-[#1e3a8a]/30`;
              case 'zellige-tlemcen': return `${base} bg-[#271c19] border-[#b45309]/30`;
              case 'zellige-sahara': return `${base} bg-[#2a1b12] border-[#d97706]/30`;
              case 'zellige-constantine': return `${base} bg-[#1a120b] border-[#5d4037]/30`; // Dark Brown/Bronze
              case 'zellige-ghardaia': return `${base} bg-[#2c1a0e] border-[#ea580c]/30`; // Ochre/Clay
              case 'zellige-kabylie': return `${base} bg-[#0f172a] border-[#dc2626]/30`; // Berber Red/Green/Yellow
              case 'zellige-chaoui': return `${base} bg-[#2f1b0c] border-[#8b4513]/30`; // Saddle Brown
              case 'zellige-tergui': return `${base} bg-[#0a0a2a] border-[#4b0082]/30`; // Indigo
              case 'zellige-mozabite': return `${base} bg-[#1c1c1c] border-[#a0522d]/30`; // Sienna
              case 'modern-ornate': return `${base} bg-[#1a0524] border-[#ffd700]/30`;
              default: return `${base} bg-gray-900 border-gray-800`;
          }
      }
      
      switch (settings.theme) {
          case 'zellige': return `${base} bg-[#fdfbf7] border-[#cca43b]/40`;
          case 'zellige-v2': return `${base} bg-[#f5fcf9] border-[#024d38]`;
          case 'zellige-algiers': return `${base} bg-[#eff6ff] border-[#1e3a8a]/40`;
          case 'zellige-tlemcen': return `${base} bg-[#fffbeb] border-[#b45309]/40`;
          case 'zellige-sahara': return `${base} bg-[#fff7ed] border-[#d97706]/40`;
          case 'zellige-constantine': return `${base} bg-[#fafaf9] border-[#5d4037]/40`;
          case 'zellige-ghardaia': return `${base} bg-[#fff7ed] border-[#ea580c]/40`;
          case 'zellige-kabylie': return `${base} bg-[#fef2f2] border-[#dc2626]/40`;
          case 'zellige-chaoui': return `${base} bg-[#fff8dc] border-[#8b4513]/40`;
          case 'zellige-tergui': return `${base} bg-[#f0f8ff] border-[#4b0082]/40`;
          case 'zellige-mozabite': return `${base} bg-[#fffaf0] border-[#a0522d]/40`;
          case 'modern-ornate': return `${base} bg-[#f3e5f5] border-[#ffd700]`;
          default: return `${base} bg-white border-gray-200`;
      }
  };

  const getBrandCardStyle = () => { 
      const base = "w-full p-6 rounded-[2rem] mb-6 relative overflow-hidden group shadow-lg transition-all duration-500 hover:shadow-xl flex flex-col items-center text-center";
      
      if (settings.darkMode) {
          if (settings.theme === 'zellige') return `${base} bg-[#002a2d] border-[3px] border-[#cca43b] text-[#cca43b] shadow-[#cca43b]/10`;
          if (settings.theme === 'zellige-v2') return `${base} bg-[#012a20] border-[3px] border-[#024d38] text-[#c6e3d8] shadow-[#024d38]/10`;
          if (settings.theme === 'zellige-algiers') return `${base} bg-[#0f172a] border-[3px] border-[#1e3a8a] text-[#f8fafc] shadow-[#1e3a8a]/10`;
          if (settings.theme === 'zellige-tlemcen') return `${base} bg-[#271c19] border-[3px] border-[#b45309] text-[#fffbeb] shadow-[#b45309]/10`;
          if (settings.theme === 'zellige-sahara') return `${base} bg-[#2a1b12] border-[3px] border-[#d97706] text-[#fff7ed] shadow-[#d97706]/10`;
          if (settings.theme === 'zellige-constantine') return `${base} bg-[#1a120b] border-[3px] border-[#5d4037] text-[#e7e5e4] shadow-[#5d4037]/10`;
          if (settings.theme === 'zellige-ghardaia') return `${base} bg-[#2c1a0e] border-[3px] border-[#ea580c] text-[#ffedd5] shadow-[#ea580c]/10`;
          if (settings.theme === 'zellige-kabylie') return `${base} bg-[#0f172a] border-[3px] border-[#dc2626] text-[#fecaca] shadow-[#dc2626]/10`;
          if (settings.theme === 'zellige-chaoui') return `${base} bg-[#2f1b0c] border-[3px] border-[#8b4513] text-[#ffd700] shadow-[#8b4513]/10`;
          if (settings.theme === 'zellige-tergui') return `${base} bg-[#0a0a2a] border-[3px] border-[#4b0082] text-[#c0c0c0] shadow-[#4b0082]/10`;
          if (settings.theme === 'zellige-mozabite') return `${base} bg-[#1c1c1c] border-[3px] border-[#a0522d] text-[#f5deb3] shadow-[#a0522d]/10`;
          if (settings.theme === 'modern-ornate') return `${base} bg-[#2d0b3d] border-[3px] border-[#ffd700] text-[#ffd700]`;
          return `${base} bg-gray-800 border-[3px] border-gray-700 text-white`;
      }

      if (settings.theme === 'zellige') return `${base} bg-[#fdfbf7] border-[3px] border-[#cca43b] text-[#006269] shadow-[#cca43b]/10`;
      if (settings.theme === 'zellige-v2') return `${base} bg-[#f5fcf9] border-[3px] border-[#c6e3d8] text-[#024d38] shadow-[#024d38]/10`;
      if (settings.theme === 'zellige-algiers') return `${base} bg-[#eff6ff] border-[3px] border-[#1e3a8a] text-[#1e3a8a] shadow-[#1e3a8a]/10`;
      if (settings.theme === 'zellige-tlemcen') return `${base} bg-[#fffbeb] border-[3px] border-[#b45309] text-[#064e3b] shadow-[#b45309]/10`;
      if (settings.theme === 'zellige-sahara') return `${base} bg-[#fff7ed] border-[3px] border-[#d97706] text-[#1e40af] shadow-[#d97706]/10`;
      if (settings.theme === 'zellige-constantine') return `${base} bg-[#fafaf9] border-[3px] border-[#5d4037] text-[#1c1917] shadow-[#5d4037]/10`;
      if (settings.theme === 'zellige-ghardaia') return `${base} bg-[#fff7ed] border-[3px] border-[#ea580c] text-[#9a3412] shadow-[#ea580c]/10`;
      if (settings.theme === 'zellige-kabylie') return `${base} bg-[#fef2f2] border-[3px] border-[#dc2626] text-[#991b1b] shadow-[#dc2626]/10`;
      if (settings.theme === 'zellige-chaoui') return `${base} bg-[#fff8dc] border-[3px] border-[#8b4513] text-[#d2691e] shadow-[#8b4513]/10`;
      if (settings.theme === 'zellige-tergui') return `${base} bg-[#f0f8ff] border-[3px] border-[#4b0082] text-[#191970] shadow-[#4b0082]/10`;
      if (settings.theme === 'zellige-mozabite') return `${base} bg-[#fffaf0] border-[3px] border-[#a0522d] text-[#87ceeb] shadow-[#a0522d]/10`;
      if (settings.theme === 'modern-ornate') return `${base} bg-[#4a148c] border-[3px] border-[#ffd700] text-[#ffd700]`;
      return `${base} bg-gradient-to-br from-blue-600 to-indigo-700 text-white`; 
  };

  const getIconBoxClass = (isActive: boolean, isBottomNav: boolean = false) => { 
      const base = `flex items-center justify-center transition-all duration-500 shrink-0 relative overflow-hidden ${isBottomNav ? "w-12 h-12 rounded-2xl" : "w-10 h-10 rounded-xl"}`;
      
      if (isActive) {
          if (settings.darkMode) {
              if (settings.theme === 'zellige') return `${base} bg-[#cca43b] text-[#001e21] shadow-[0_0_15px_rgba(204,164,59,0.3)] border border-[#cca43b] font-bold`;
              if (settings.theme === 'zellige-v2') return `${base} bg-[#024d38] text-[#f5fcf9] shadow-[0_0_15px_rgba(2,77,56,0.3)] border border-[#024d38] font-bold`;
              if (settings.theme === 'zellige-algiers') return `${base} bg-[#1e3a8a] text-[#f8fafc] shadow-[0_0_15px_rgba(30,58,138,0.3)] border border-[#1e3a8a] font-bold`;
              if (settings.theme === 'zellige-tlemcen') return `${base} bg-[#b45309] text-[#fffbeb] shadow-[0_0_15px_rgba(180,83,9,0.3)] border border-[#b45309] font-bold`;
              if (settings.theme === 'zellige-sahara') return `${base} bg-[#d97706] text-[#fff7ed] shadow-[0_0_15px_rgba(217,119,6,0.3)] border border-[#d97706] font-bold`;
              if (settings.theme === 'zellige-constantine') return `${base} bg-[#5d4037] text-[#e7e5e4] shadow-[0_0_15px_rgba(93,64,55,0.3)] border border-[#5d4037] font-bold`;
              if (settings.theme === 'zellige-ghardaia') return `${base} bg-[#ea580c] text-[#ffedd5] shadow-[0_0_15px_rgba(234,88,12,0.3)] border border-[#ea580c] font-bold`;
              if (settings.theme === 'zellige-kabylie') return `${base} bg-[#dc2626] text-[#fecaca] shadow-[0_0_15px_rgba(220,38,38,0.3)] border border-[#dc2626] font-bold`;
              if (settings.theme === 'zellige-chaoui') return `${base} bg-[#8b4513] text-[#ffd700] shadow-[0_0_15px_rgba(139,69,19,0.3)] border border-[#8b4513] font-bold`;
              if (settings.theme === 'zellige-tergui') return `${base} bg-[#4b0082] text-[#c0c0c0] shadow-[0_0_15px_rgba(75,0,130,0.3)] border border-[#4b0082] font-bold`;
              if (settings.theme === 'zellige-mozabite') return `${base} bg-[#a0522d] text-[#f5deb3] shadow-[0_0_15px_rgba(160,82,45,0.3)] border border-[#a0522d] font-bold`;
              return `${base} bg-blue-600 text-white shadow-lg shadow-blue-900/20`;
          }
          if (settings.theme === 'zellige') return `${base} bg-[#006269] text-[#cca43b] border border-[#cca43b]`;
          if (settings.theme === 'zellige-v2') return `${base} bg-[#024d38] text-[#f5fcf9] border border-[#c6e3d8]`;
          if (settings.theme === 'zellige-algiers') return `${base} bg-[#1e3a8a] text-[#f8fafc] border border-[#1e3a8a]`;
          if (settings.theme === 'zellige-tlemcen') return `${base} bg-[#b45309] text-[#fffbeb] border border-[#b45309]`;
          if (settings.theme === 'zellige-sahara') return `${base} bg-[#d97706] text-[#fff7ed] border border-[#d97706]`;
          if (settings.theme === 'zellige-constantine') return `${base} bg-[#5d4037] text-[#fafaf9] border border-[#5d4037]`;
          if (settings.theme === 'zellige-ghardaia') return `${base} bg-[#ea580c] text-[#fff7ed] border border-[#ea580c]`;
          if (settings.theme === 'zellige-kabylie') return `${base} bg-[#dc2626] text-[#fef2f2] border border-[#dc2626]`;
          if (settings.theme === 'zellige-chaoui') return `${base} bg-[#8b4513] text-[#fff8dc] border border-[#8b4513]`;
          if (settings.theme === 'zellige-tergui') return `${base} bg-[#191970] text-[#f0f8ff] border border-[#4b0082]`;
          if (settings.theme === 'zellige-mozabite') return `${base} bg-[#a0522d] text-[#fffaf0] border border-[#a0522d]`;
          if (settings.theme === 'modern-ornate') return `${base} bg-[#4a148c] text-[#ffd700] border border-[#ffd700] shadow-[0_0_15px_rgba(255,215,0,0.5)]`;
          return `${base} bg-blue-600 text-white`;
      }
      // Inactive State
      if (settings.darkMode) {
          if (settings.theme === 'zellige') return `${base} text-[#cca43b]/60 bg-[#cca43b]/5 hover:bg-[#cca43b]/10`;
          if (settings.theme === 'zellige-v2') return `${base} text-[#024d38]/60 bg-[#024d38]/5 hover:bg-[#024d38]/10`;
          if (settings.theme === 'zellige-algiers') return `${base} text-[#f8fafc]/60 bg-[#1e3a8a]/20 hover:bg-[#1e3a8a]/30`;
          if (settings.theme === 'zellige-tlemcen') return `${base} text-[#fffbeb]/60 bg-[#b45309]/20 hover:bg-[#b45309]/30`;
          if (settings.theme === 'zellige-sahara') return `${base} text-[#fff7ed]/60 bg-[#d97706]/20 hover:bg-[#d97706]/30`;
          if (settings.theme === 'zellige-constantine') return `${base} text-[#e7e5e4]/60 bg-[#5d4037]/20 hover:bg-[#5d4037]/30`;
          if (settings.theme === 'zellige-ghardaia') return `${base} text-[#ffedd5]/60 bg-[#ea580c]/20 hover:bg-[#ea580c]/30`;
          if (settings.theme === 'zellige-kabylie') return `${base} text-[#fecaca]/60 bg-[#dc2626]/20 hover:bg-[#dc2626]/30`;
          if (settings.theme === 'zellige-chaoui') return `${base} text-[#ffd700]/60 bg-[#8b4513]/20 hover:bg-[#8b4513]/30`;
          if (settings.theme === 'zellige-tergui') return `${base} text-[#c0c0c0]/60 bg-[#4b0082]/20 hover:bg-[#4b0082]/30`;
          if (settings.theme === 'zellige-mozabite') return `${base} text-[#f5deb3]/60 bg-[#a0522d]/20 hover:bg-[#a0522d]/30`;
      }
      if (settings.theme === 'zellige') return `${base} text-[#006269]/60 bg-[#006269]/5`;
      if (settings.theme === 'zellige-algiers') return `${base} text-[#1e3a8a]/60 bg-[#1e3a8a]/5`;
      if (settings.theme === 'zellige-tlemcen') return `${base} text-[#b45309]/60 bg-[#b45309]/5`;
      if (settings.theme === 'zellige-sahara') return `${base} text-[#d97706]/60 bg-[#d97706]/5`;
      if (settings.theme === 'zellige-constantine') return `${base} text-[#5d4037]/60 bg-[#5d4037]/5`;
      if (settings.theme === 'zellige-ghardaia') return `${base} text-[#ea580c]/60 bg-[#ea580c]/5`;
      if (settings.theme === 'zellige-kabylie') return `${base} text-[#dc2626]/60 bg-[#dc2626]/5`;
      if (settings.theme === 'zellige-chaoui') return `${base} text-[#8b4513]/60 bg-[#8b4513]/5`;
      if (settings.theme === 'zellige-tergui') return `${base} text-[#191970]/60 bg-[#191970]/5`;
      if (settings.theme === 'zellige-mozabite') return `${base} text-[#a0522d]/60 bg-[#a0522d]/5`;
      return `${base} text-gray-400 dark:text-gray-500`; 
  };

  const getNavItemClass = (isActive: boolean) => { 
      const base = "w-full flex items-center gap-3 relative group p-3 rounded-2xl transition-all duration-300 font-bold text-sm mb-2";
      
      if (isActive) {
          if (settings.darkMode) {
               if (settings.theme === 'zellige') return `${base} bg-[#002a2d] text-[#cca43b] border border-[#cca43b]/50 shadow-md shadow-[#cca43b]/10`;
               if (settings.theme === 'zellige-v2') return `${base} bg-[#012a20] text-[#c6e3d8] border border-[#024d38]/50 shadow-md shadow-[#024d38]/10`;
               if (settings.theme === 'zellige-algiers') return `${base} bg-[#0f172a] text-[#f8fafc] border border-[#1e3a8a]/50 shadow-md shadow-[#1e3a8a]/10`;
               if (settings.theme === 'zellige-tlemcen') return `${base} bg-[#271c19] text-[#fffbeb] border border-[#b45309]/50 shadow-md shadow-[#b45309]/10`;
               if (settings.theme === 'zellige-sahara') return `${base} bg-[#2a1b12] text-[#fff7ed] border border-[#d97706]/50 shadow-md shadow-[#d97706]/10`;
               if (settings.theme === 'zellige-constantine') return `${base} bg-[#1a120b] text-[#e7e5e4] border border-[#5d4037]/50 shadow-md shadow-[#5d4037]/10`;
               if (settings.theme === 'zellige-ghardaia') return `${base} bg-[#2c1a0e] text-[#ffedd5] border border-[#ea580c]/50 shadow-md shadow-[#ea580c]/10`;
               if (settings.theme === 'zellige-kabylie') return `${base} bg-[#0f172a] text-[#fecaca] border border-[#dc2626]/50 shadow-md shadow-[#dc2626]/10`;
               if (settings.theme === 'zellige-chaoui') return `${base} bg-[#2f1b0c] text-[#ffd700] border border-[#8b4513]/50 shadow-md shadow-[#8b4513]/10`;
               if (settings.theme === 'zellige-tergui') return `${base} bg-[#0a0a2a] text-[#c0c0c0] border border-[#4b0082]/50 shadow-md shadow-[#4b0082]/10`;
               if (settings.theme === 'zellige-mozabite') return `${base} bg-[#1c1c1c] text-[#f5deb3] border border-[#a0522d]/50 shadow-md shadow-[#a0522d]/10`;
               return `${base} bg-gray-800 text-blue-400 border border-gray-700 shadow-md`;
          }
          if (settings.theme === 'zellige') return `${base} bg-[#fdfbf7] text-[#006269] border border-[#cca43b]/50 shadow-md shadow-[#cca43b]/10`;
          if (settings.theme === 'zellige-v2') return `${base} bg-[#f5fcf9] text-[#024d38] border border-[#c6e3d8]/50 shadow-md shadow-[#024d38]/10`;
          if (settings.theme === 'zellige-algiers') return `${base} bg-[#eff6ff] text-[#1e3a8a] border border-[#1e3a8a]/50 shadow-md shadow-[#1e3a8a]/10`;
          if (settings.theme === 'zellige-tlemcen') return `${base} bg-[#fffbeb] text-[#064e3b] border border-[#b45309]/50 shadow-md shadow-[#b45309]/10`;
          if (settings.theme === 'zellige-sahara') return `${base} bg-[#fff7ed] text-[#1e40af] border border-[#d97706]/50 shadow-md shadow-[#d97706]/10`;
          if (settings.theme === 'zellige-constantine') return `${base} bg-[#fafaf9] text-[#1c1917] border border-[#5d4037]/50 shadow-md shadow-[#5d4037]/10`;
          if (settings.theme === 'zellige-ghardaia') return `${base} bg-[#fff7ed] text-[#9a3412] border border-[#ea580c]/50 shadow-md shadow-[#ea580c]/10`;
          if (settings.theme === 'zellige-kabylie') return `${base} bg-[#fef2f2] text-[#991b1b] border border-[#dc2626]/50 shadow-md shadow-[#dc2626]/10`;
          if (settings.theme === 'zellige-chaoui') return `${base} bg-[#fff8dc] text-[#8b4513] border border-[#8b4513]/50 shadow-md shadow-[#8b4513]/10`;
          if (settings.theme === 'zellige-tergui') return `${base} bg-[#f0f8ff] text-[#191970] border border-[#4b0082]/50 shadow-md shadow-[#4b0082]/10`;
          if (settings.theme === 'zellige-mozabite') return `${base} bg-[#fffaf0] text-[#a0522d] border border-[#a0522d]/50 shadow-md shadow-[#a0522d]/10`;
          if (settings.theme === 'modern-ornate') return `${base} bg-[#4a148c] text-[#ffd700] border border-[#ffd700] shadow-md`;
          return `${base} bg-blue-600 text-white`;
      }
      
      // Inactive Hover States
      if (settings.darkMode) {
          if (settings.theme === 'zellige') return `${base} text-[#cca43b]/70 hover:bg-[#cca43b]/10 hover:text-[#cca43b] hover:border hover:border-[#cca43b]/20`;
          if (settings.theme === 'zellige-v2') return `${base} text-[#c6e3d8]/70 hover:bg-[#024d38]/10 hover:text-[#c6e3d8] hover:border hover:border-[#024d38]/20`;
          if (settings.theme === 'zellige-algiers') return `${base} text-[#f8fafc]/70 hover:bg-[#1e3a8a]/20 hover:text-[#f8fafc] hover:border hover:border-[#1e3a8a]/20`;
          if (settings.theme === 'zellige-tlemcen') return `${base} text-[#fffbeb]/70 hover:bg-[#b45309]/20 hover:text-[#fffbeb] hover:border hover:border-[#b45309]/20`;
          if (settings.theme === 'zellige-sahara') return `${base} text-[#fff7ed]/70 hover:bg-[#d97706]/20 hover:text-[#fff7ed] hover:border hover:border-[#d97706]/20`;
          if (settings.theme === 'zellige-chaoui') return `${base} text-[#ffd700]/70 hover:bg-[#8b4513]/20 hover:text-[#ffd700] hover:border hover:border-[#8b4513]/20`;
          if (settings.theme === 'zellige-tergui') return `${base} text-[#c0c0c0]/70 hover:bg-[#4b0082]/20 hover:text-[#c0c0c0] hover:border hover:border-[#4b0082]/20`;
          if (settings.theme === 'zellige-mozabite') return `${base} text-[#f5deb3]/70 hover:bg-[#a0522d]/20 hover:text-[#f5deb3] hover:border hover:border-[#a0522d]/20`;
      }
      if (settings.theme === 'zellige') return `${base} text-[#006269]/70 hover:bg-[#006269]/10 hover:text-[#006269] hover:border hover:border-[#006269]/20`;
      if (settings.theme === 'zellige-algiers') return `${base} text-[#1e3a8a]/70 hover:bg-[#1e3a8a]/10 hover:text-[#1e3a8a] hover:border hover:border-[#1e3a8a]/20`;
      if (settings.theme === 'zellige-tlemcen') return `${base} text-[#b45309]/70 hover:bg-[#b45309]/10 hover:text-[#b45309] hover:border hover:border-[#b45309]/20`;
      if (settings.theme === 'zellige-sahara') return `${base} text-[#d97706]/70 hover:bg-[#d97706]/10 hover:text-[#d97706] hover:border hover:border-[#d97706]/20`;
      if (settings.theme === 'zellige-chaoui') return `${base} text-[#8b4513]/70 hover:bg-[#8b4513]/10 hover:text-[#8b4513] hover:border hover:border-[#8b4513]/20`;
      if (settings.theme === 'zellige-tergui') return `${base} text-[#191970]/70 hover:bg-[#191970]/10 hover:text-[#191970] hover:border hover:border-[#191970]/20`;
      if (settings.theme === 'zellige-mozabite') return `${base} text-[#a0522d]/70 hover:bg-[#a0522d]/10 hover:text-[#a0522d] hover:border hover:border-[#a0522d]/20`;
      
      return `${base} text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800/50 dark:text-gray-400 dark:hover:text-gray-200`; 
  };

  const getSectionTitleClass = () => { 
      if (settings.darkMode) {
          if (settings.theme === 'zellige') return 'text-[#cca43b] opacity-90 font-serif tracking-widest';
          if (settings.theme === 'zellige-v2') return 'text-[#c6e3d8] opacity-90 font-serif tracking-widest';
          if (settings.theme === 'zellige-algiers') return 'text-[#f8fafc] opacity-90 font-serif tracking-widest';
          if (settings.theme === 'zellige-tlemcen') return 'text-[#fffbeb] opacity-90 font-serif tracking-widest';
          if (settings.theme === 'zellige-sahara') return 'text-[#fff7ed] opacity-90 font-serif tracking-widest';
          return 'text-gray-400';
      }
      if (settings.theme === 'zellige') return 'text-[#006269] font-serif tracking-widest';
      if (settings.theme === 'zellige-v2') return 'text-[#024d38] font-serif tracking-widest';
      if (settings.theme === 'zellige-algiers') return 'text-[#1e3a8a] font-serif tracking-widest';
      if (settings.theme === 'zellige-tlemcen') return 'text-[#b45309] font-serif tracking-widest';
      if (settings.theme === 'zellige-sahara') return 'text-[#d97706] font-serif tracking-widest';
      if (settings.theme === 'modern-ornate') return 'text-[#4a148c]';
      return 'text-gray-400'; 
  };
  
  const getBottomNavContainerStyle = () => { 
      if (settings.darkMode) {
          if (settings.theme === 'zellige') return "md:hidden fixed bottom-6 left-6 right-6 z-50 transition-all duration-500 ease-[cubic-bezier(0.32,0.72,0,1)] flex justify-between items-center px-6 py-3 rounded-[2.5rem] shadow-2xl backdrop-blur-xl border bg-[#001e21]/95 border-[#cca43b]/40 shadow-[#cca43b]/10";
          if (settings.theme === 'zellige-v2') return "md:hidden fixed bottom-6 left-6 right-6 z-50 transition-all duration-500 ease-[cubic-bezier(0.32,0.72,0,1)] flex justify-between items-center px-6 py-3 rounded-[2.5rem] shadow-2xl backdrop-blur-xl border bg-[#012a20]/95 border-[#024d38]/40 shadow-[#024d38]/10";
          if (settings.theme === 'zellige-algiers') return "md:hidden fixed bottom-6 left-6 right-6 z-50 transition-all duration-500 ease-[cubic-bezier(0.32,0.72,0,1)] flex justify-between items-center px-6 py-3 rounded-[2.5rem] shadow-2xl backdrop-blur-xl border bg-[#0f172a]/95 border-[#1e3a8a]/40 shadow-[#1e3a8a]/10";
          if (settings.theme === 'zellige-tlemcen') return "md:hidden fixed bottom-6 left-6 right-6 z-50 transition-all duration-500 ease-[cubic-bezier(0.32,0.72,0,1)] flex justify-between items-center px-6 py-3 rounded-[2.5rem] shadow-2xl backdrop-blur-xl border bg-[#271c19]/95 border-[#b45309]/40 shadow-[#b45309]/10";
          if (settings.theme === 'zellige-sahara') return "md:hidden fixed bottom-6 left-6 right-6 z-50 transition-all duration-500 ease-[cubic-bezier(0.32,0.72,0,1)] flex justify-between items-center px-6 py-3 rounded-[2.5rem] shadow-2xl backdrop-blur-xl border bg-[#2a1b12]/95 border-[#d97706]/40 shadow-[#d97706]/10";
      }
      if (settings.theme === 'zellige') return "md:hidden fixed bottom-6 left-6 right-6 z-50 transition-all duration-500 ease-[cubic-bezier(0.32,0.72,0,1)] flex justify-between items-center px-6 py-3 rounded-[2.5rem] shadow-2xl backdrop-blur-xl border bg-[#FDFBF7]/95 border-[#cca43b]/40 shadow-[#cca43b]/10";
      if (settings.theme === 'zellige-v2') return "md:hidden fixed bottom-6 left-6 right-6 z-50 transition-all duration-500 ease-[cubic-bezier(0.32,0.72,0,1)] flex justify-between items-center px-6 py-3 rounded-[2.5rem] shadow-2xl backdrop-blur-xl border bg-[#f5fcf9]/95 border-[#c6e3d8]/40 shadow-[#024d38]/10";
      if (settings.theme === 'zellige-algiers') return "md:hidden fixed bottom-6 left-6 right-6 z-50 transition-all duration-500 ease-[cubic-bezier(0.32,0.72,0,1)] flex justify-between items-center px-6 py-3 rounded-[2.5rem] shadow-2xl backdrop-blur-xl border bg-[#eff6ff]/95 border-[#1e3a8a]/40 shadow-[#1e3a8a]/10";
      if (settings.theme === 'zellige-tlemcen') return "md:hidden fixed bottom-6 left-6 right-6 z-50 transition-all duration-500 ease-[cubic-bezier(0.32,0.72,0,1)] flex justify-between items-center px-6 py-3 rounded-[2.5rem] shadow-2xl backdrop-blur-xl border bg-[#fffbeb]/95 border-[#b45309]/40 shadow-[#b45309]/10";
      if (settings.theme === 'zellige-sahara') return "md:hidden fixed bottom-6 left-6 right-6 z-50 transition-all duration-500 ease-[cubic-bezier(0.32,0.72,0,1)] flex justify-between items-center px-6 py-3 rounded-[2.5rem] shadow-2xl backdrop-blur-xl border bg-[#fff7ed]/95 border-[#d97706]/40 shadow-[#d97706]/10";
      if (settings.theme === 'modern-ornate') return "md:hidden fixed bottom-6 left-6 right-6 z-50 transition-all duration-500 ease-[cubic-bezier(0.32,0.72,0,1)] flex justify-between items-center px-6 py-3 rounded-[2.5rem] shadow-2xl backdrop-blur-xl border bg-[#f3e5f5]/95 border-[#ffd700]/50";
      return "md:hidden fixed bottom-6 left-6 right-6 z-50 transition-all duration-500 ease-[cubic-bezier(0.32,0.72,0,1)] flex justify-between items-center px-6 py-3 rounded-[2.5rem] shadow-2xl backdrop-blur-xl border bg-white/80 border-white/40"; 
  };
  
  const getHeaderBtnStyle = () => { 
      if (settings.darkMode) {
          if (settings.theme === 'zellige') return "p-2 rounded-xl shadow-md transition-all active:scale-95 flex items-center justify-center relative overflow-hidden bg-[#002a2d] text-[#cca43b] border border-[#cca43b]/30 hover:bg-[#cca43b]/10";
          if (settings.theme === 'zellige-v2') return "p-2 rounded-xl shadow-md transition-all active:scale-95 flex items-center justify-center relative overflow-hidden bg-[#012a20] text-[#c6e3d8] border border-[#024d38]/30 hover:bg-[#024d38]/10";
          if (settings.theme === 'zellige-algiers') return "p-2 rounded-xl shadow-md transition-all active:scale-95 flex items-center justify-center relative overflow-hidden bg-[#0f172a] text-[#f8fafc] border border-[#1e3a8a]/30 hover:bg-[#1e3a8a]/10";
          if (settings.theme === 'zellige-tlemcen') return "p-2 rounded-xl shadow-md transition-all active:scale-95 flex items-center justify-center relative overflow-hidden bg-[#271c19] text-[#fffbeb] border border-[#b45309]/30 hover:bg-[#b45309]/10";
          if (settings.theme === 'zellige-sahara') return "p-2 rounded-xl shadow-md transition-all active:scale-95 flex items-center justify-center relative overflow-hidden bg-[#2a1b12] text-[#fff7ed] border border-[#d97706]/30 hover:bg-[#d97706]/10";
      }
      if (settings.theme === 'zellige') return "p-2 rounded-xl shadow-md transition-all active:scale-95 flex items-center justify-center relative overflow-hidden bg-[#FDFBF7] text-[#006269] border border-[#cca43b]/30 hover:bg-[#006269]/5";
      if (settings.theme === 'zellige-v2') return "p-2 rounded-xl shadow-md transition-all active:scale-95 flex items-center justify-center relative overflow-hidden bg-[#f5fcf9] text-[#024d38] border border-[#c6e3d8]/30 hover:bg-[#024d38]/5";
      if (settings.theme === 'zellige-algiers') return "p-2 rounded-xl shadow-md transition-all active:scale-95 flex items-center justify-center relative overflow-hidden bg-[#eff6ff] text-[#1e3a8a] border border-[#1e3a8a]/30 hover:bg-[#1e3a8a]/5";
      if (settings.theme === 'zellige-tlemcen') return "p-2 rounded-xl shadow-md transition-all active:scale-95 flex items-center justify-center relative overflow-hidden bg-[#fffbeb] text-[#b45309] border border-[#b45309]/30 hover:bg-[#b45309]/5";
      if (settings.theme === 'zellige-sahara') return "p-2 rounded-xl shadow-md transition-all active:scale-95 flex items-center justify-center relative overflow-hidden bg-[#fff7ed] text-[#d97706] border border-[#d97706]/30 hover:bg-[#d97706]/5";
      if (settings.theme === 'modern-ornate') return "p-2 rounded-xl shadow-md transition-all active:scale-95 flex items-center justify-center relative overflow-hidden bg-[#4a148c] text-[#ffd700] border border-[#ffd700]";
      return "p-2 rounded-xl shadow-md transition-all active:scale-95 flex items-center justify-center relative overflow-hidden bg-black text-white"; 
  };
  
  const getMenuIconStyle = () => { 
      if (settings.darkMode) {
          if (settings.theme === 'zellige') return "p-4 rounded-2xl mb-2 transition-all duration-300 group-active:scale-95 shadow-md relative overflow-hidden flex items-center justify-center bg-[#002a2d] text-[#cca43b] border border-[#cca43b]/30";
          if (settings.theme === 'zellige-v2') return "p-4 rounded-2xl mb-2 transition-all duration-300 group-active:scale-95 shadow-md relative overflow-hidden flex items-center justify-center bg-[#012a20] text-[#c6e3d8] border border-[#024d38]/30";
          if (settings.theme === 'zellige-algiers') return "p-4 rounded-2xl mb-2 transition-all duration-300 group-active:scale-95 shadow-md relative overflow-hidden flex items-center justify-center bg-[#0f172a] text-[#f8fafc] border border-[#1e3a8a]/30";
          if (settings.theme === 'zellige-tlemcen') return "p-4 rounded-2xl mb-2 transition-all duration-300 group-active:scale-95 shadow-md relative overflow-hidden flex items-center justify-center bg-[#271c19] text-[#fffbeb] border border-[#b45309]/30";
          if (settings.theme === 'zellige-sahara') return "p-4 rounded-2xl mb-2 transition-all duration-300 group-active:scale-95 shadow-md relative overflow-hidden flex items-center justify-center bg-[#2a1b12] text-[#fff7ed] border border-[#d97706]/30";
      }
      if (settings.theme === 'zellige') return "p-4 rounded-2xl mb-2 transition-all duration-300 group-active:scale-95 shadow-md relative overflow-hidden flex items-center justify-center bg-[#FDFBF7] text-[#006269] border border-[#cca43b]/30";
      if (settings.theme === 'zellige-v2') return "p-4 rounded-2xl mb-2 transition-all duration-300 group-active:scale-95 shadow-md relative overflow-hidden flex items-center justify-center bg-[#f5fcf9] text-[#024d38] border border-[#c6e3d8]/30";
      if (settings.theme === 'zellige-algiers') return "p-4 rounded-2xl mb-2 transition-all duration-300 group-active:scale-95 shadow-md relative overflow-hidden flex items-center justify-center bg-[#eff6ff] text-[#1e3a8a] border border-[#1e3a8a]/30";
      if (settings.theme === 'zellige-tlemcen') return "p-4 rounded-2xl mb-2 transition-all duration-300 group-active:scale-95 shadow-md relative overflow-hidden flex items-center justify-center bg-[#fffbeb] text-[#b45309] border border-[#b45309]/30";
      if (settings.theme === 'zellige-sahara') return "p-4 rounded-2xl mb-2 transition-all duration-300 group-active:scale-95 shadow-md relative overflow-hidden flex items-center justify-center bg-[#fff7ed] text-[#d97706] border border-[#d97706]/30";
      if (settings.theme === 'modern-ornate') return "p-4 rounded-2xl mb-2 transition-all duration-300 group-active:scale-95 shadow-md relative overflow-hidden flex items-center justify-center bg-[#4a148c] text-[#ffd700] border border-[#ffd700]";
      return "p-4 rounded-2xl mb-2 transition-all duration-300 group-active:scale-95 shadow-md relative overflow-hidden flex items-center justify-center bg-blue-50 text-blue-600"; 
  };
  
  const isZelligeTheme = settings.theme.startsWith('zellige');
  const getZelligePatternClass = () => {
      if (settings.theme === 'zellige') return 'bg-zellige-pattern';
      if (settings.theme === 'zellige-v2') return 'bg-zellige-v2-pattern';
      if (settings.theme === 'zellige-algiers') return 'bg-zellige-algiers-pattern';
      if (settings.theme === 'zellige-tlemcen') return 'bg-zellige-tlemcen-pattern';
      if (settings.theme === 'zellige-sahara') return 'bg-zellige-sahara-pattern';
      if (settings.theme === 'zellige-constantine') return 'bg-zellige-constantine-pattern';
      if (settings.theme === 'zellige-ghardaia') return 'bg-zellige-ghardaia-pattern';
      if (settings.theme === 'zellige-kabylie') return 'bg-zellige-kabylie-pattern';
      if (settings.theme === 'zellige-chaoui') return 'bg-zellige-chaoui-pattern';
      if (settings.theme === 'zellige-tergui') return 'bg-zellige-tergui-pattern';
      if (settings.theme === 'zellige-mozabite') return 'bg-zellige-mozabite-pattern';
      return 'bg-zellige-pattern';
  };
  const isOrnateTheme = settings.theme === 'modern-ornate';

  const headerVisibilityClass = isNativeKeyboardOpen || hasOpenModal ? 'translate-y-[-120%] opacity-0 pointer-events-none' : 'translate-y-0 opacity-100';
  const bottomNavVisibilityClass = hasOpenModal ? 'translate-y-[200%] opacity-0 pointer-events-none' : '';

  // Mobile Header Style
  const getMobileHeaderStyle = () => {
      if (settings.darkMode) {
          if (settings.theme === 'zellige') return "pointer-events-auto bg-[#001e21]/95 border border-[#cca43b]/30 backdrop-blur-md shadow-lg rounded-2xl p-3 flex justify-between items-center text-[#cca43b] shadow-[#cca43b]/10";
          if (settings.theme === 'zellige-v2') return "pointer-events-auto bg-[#012a20]/95 border border-[#024d38]/30 backdrop-blur-md shadow-lg rounded-2xl p-3 flex justify-between items-center text-[#c6e3d8] shadow-[#024d38]/10";
          if (settings.theme === 'zellige-algiers') return "pointer-events-auto bg-[#0f172a]/95 border border-[#1e3a8a]/30 backdrop-blur-md shadow-lg rounded-2xl p-3 flex justify-between items-center text-[#f8fafc] shadow-[#1e3a8a]/10";
          if (settings.theme === 'zellige-tlemcen') return "pointer-events-auto bg-[#271c19]/95 border border-[#b45309]/30 backdrop-blur-md shadow-lg rounded-2xl p-3 flex justify-between items-center text-[#fffbeb] shadow-[#b45309]/10";
          if (settings.theme === 'zellige-sahara') return "pointer-events-auto bg-[#2a1b12]/95 border border-[#d97706]/30 backdrop-blur-md shadow-lg rounded-2xl p-3 flex justify-between items-center text-[#fff7ed] shadow-[#d97706]/10";
      }
      if (settings.theme === 'zellige') return "pointer-events-auto bg-[#FDFBF7]/95 border border-[#cca43b]/30 backdrop-blur-md shadow-lg rounded-2xl p-3 flex justify-between items-center text-[#006269] shadow-[#cca43b]/10";
      if (settings.theme === 'zellige-v2') return "pointer-events-auto bg-[#f5fcf9]/95 border border-[#c6e3d8]/30 backdrop-blur-md shadow-lg rounded-2xl p-3 flex justify-between items-center text-[#024d38] shadow-[#024d38]/10";
      if (settings.theme === 'zellige-algiers') return "pointer-events-auto bg-[#eff6ff]/95 border border-[#1e3a8a]/30 backdrop-blur-md shadow-lg rounded-2xl p-3 flex justify-between items-center text-[#1e3a8a] shadow-[#1e3a8a]/10";
      if (settings.theme === 'zellige-tlemcen') return "pointer-events-auto bg-[#fffbeb]/95 border border-[#b45309]/30 backdrop-blur-md shadow-lg rounded-2xl p-3 flex justify-between items-center text-[#b45309] shadow-[#b45309]/10";
      if (settings.theme === 'zellige-sahara') return "pointer-events-auto bg-[#fff7ed]/95 border border-[#d97706]/30 backdrop-blur-md shadow-lg rounded-2xl p-3 flex justify-between items-center text-[#d97706] shadow-[#d97706]/10";
      return "pointer-events-auto bg-white/90 backdrop-blur-md shadow-lg rounded-2xl p-3 flex justify-between items-center text-gray-900";
  };

  return (
    <div className={`h-[100dvh] flex flex-col md:flex-row ${mainBgClass} font-sans transition-colors duration-300 overflow-hidden`}>
      <style>{`
        body.keyboard-open .bottom-nav {
            transform: translateY(200%) !important;
            opacity: 0 !important;
            pointer-events: none !important;
        }
        @media (max-width: 768px) {
            body.keyboard-open .mobile-hide-on-keyboard {
                display: none !important;
            }
            body.keyboard-open .modal-content-area {
                padding-bottom: 20px !important;
            }
        }
      `}</style>

      {activeToast && (
          <ToastNotification 
              notification={activeToast} 
              onClose={hideToast}
              onClick={() => { setActivePage('notifications'); hideToast(); }}
              onDelete={() => moveToTrash(activeToast.id)}
              theme={settings.theme}
          />
      )}
      <StaffProfileModal />

      {/* --- SIDEBAR (Desktop) --- */}
      <aside className={getSidebarStyle()}>
        {isZelligeTheme && (
            <div className={`absolute inset-0 ${getZelligePatternClass()} pointer-events-none ${settings.darkMode ? 'opacity-25 mix-blend-screen' : 'opacity-25 mix-blend-multiply'}`}></div>
        )}
        {settings.theme === 'modern-ornate' && <div className="absolute inset-0 bg-ornate-pattern opacity-10 pointer-events-none mix-blend-multiply"></div>}
        <div className="pt-6 px-4 relative z-10 flex flex-col h-full">
            <div className={getBrandCardStyle()}>
                {settings.darkMode && isZelligeTheme && (
                    <div className={`absolute inset-0 ${getZelligePatternClass()} opacity-30 pointer-events-none mix-blend-screen`}></div>
                )}
                <div className="flex flex-col items-center text-center relative z-10">
                    <div className={`w-14 h-14 backdrop-blur-sm rounded-2xl flex items-center justify-center mb-3 shadow-inner ${
                        settings.darkMode && settings.theme === 'zellige' ? 'bg-[#cca43b]/20 border border-[#cca43b]/50' : 
                        settings.darkMode && settings.theme === 'zellige-algiers' ? 'bg-[#1e3a8a]/20 border border-[#1e3a8a]/50' :
                        settings.darkMode && settings.theme === 'zellige-tlemcen' ? 'bg-[#b45309]/20 border border-[#b45309]/50' :
                        settings.darkMode && settings.theme === 'zellige-sahara' ? 'bg-[#d97706]/20 border border-[#d97706]/50' :
                        'bg-white/20'
                    }`}>
                        <Building2 size={28} className="text-current drop-shadow-sm" />
                    </div>
                    <h1 className="text-xl font-black tracking-tight leading-none mb-1">{settings.appName}</h1>
                    <span className="text-[10px] uppercase font-bold opacity-70 tracking-widest">{settings.hotelIdentity.classificationType} Hotel</span>
                </div>
                <div className="absolute top-0 -left-full w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-12 group-hover:animate-[shine_1.5s_infinite]"></div>
            </div>

            <nav className="flex-1 overflow-y-auto scrollbar-hide space-y-6 pb-4">
                {navStructure.map((group, i) => (
                    <div key={i}>
                        <div className={`px-4 text-[10px] font-black uppercase tracking-wider mb-3 flex items-center gap-2 ${getSectionTitleClass()}`}>
                            {group.title} <div className="h-px flex-1 bg-current opacity-20"></div>
                        </div>
                        {group.items.map(item => {
                            const isActive = activePage === item.id;
                            return (
                                <button key={item.id} onClick={() => setActivePage(item.id)} className={getNavItemClass(isActive)}>
                                    <div className={`${getIconBoxClass(isActive)}`}>
                                        {isZelligeTheme && ( <div className={`absolute inset-0 pointer-events-none ${getZelligePatternClass()} ${settings.darkMode ? 'opacity-30 mix-blend-screen' : 'opacity-20 mix-blend-multiply'}`}></div> )}
                                        {isOrnateTheme && ( <div className="absolute inset-0 opacity-10 bg-ornate-pattern mix-blend-multiply pointer-events-none"></div> )}
                                        <item.icon size={20} strokeWidth={isActive ? 2.5 : 2} className="relative z-10" />
                                    </div>
                                    <span className="flex-1 text-right">{item.label}</span>
                                    {item.count ? (<span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md ${isActive ? 'bg-white/20 text-current' : 'bg-red-500 text-white'}`}>{item.count}</span>) : null}
                                    {isActive && <ChevronRight size={14} className="opacity-50" />}
                                </button>
                            );
                        })}
                    </div>
                ))}
            </nav>
             <div className="pt-2 pb-4 mt-auto">
                <button 
                    onClick={() => setActivePage('user_profile')}
                    className={`w-full p-4 rounded-[1.8rem] border shadow-lg flex items-center justify-between gap-3 relative overflow-hidden group hover:scale-[1.02] transition ${
                        settings.darkMode && settings.theme === 'zellige' ? 'bg-[#002a2d] border-[#cca43b]/40' :
                        settings.darkMode && settings.theme === 'zellige-algiers' ? 'bg-[#0f172a] border-[#1e3a8a]/40' :
                        settings.darkMode && settings.theme === 'zellige-tlemcen' ? 'bg-[#271c19] border-[#b45309]/40' :
                        settings.darkMode && settings.theme === 'zellige-sahara' ? 'bg-[#2a1b12] border-[#d97706]/40' :
                        settings.theme === 'zellige' ? 'bg-[#fbf8f1] border-[#cca43b]/40' :
                        settings.theme === 'zellige-algiers' ? 'bg-[#eff6ff] border-[#1e3a8a]/40' :
                        settings.theme === 'zellige-tlemcen' ? 'bg-[#fffbeb] border-[#b45309]/40' :
                        settings.theme === 'zellige-sahara' ? 'bg-[#fff7ed] border-[#d97706]/40' :
                        'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700'
                    }`}
                >
                    <div className="flex items-center gap-3 relative z-10">
                        <div className={`w-10 h-10 rounded-full overflow-hidden border-2 shadow-sm ${
                            settings.darkMode && settings.theme === 'zellige' ? 'bg-[#001e21] border-[#cca43b]' :
                            settings.darkMode && settings.theme === 'zellige-algiers' ? 'bg-[#0f172a] border-[#1e3a8a]' :
                            settings.darkMode && settings.theme === 'zellige-tlemcen' ? 'bg-[#271c19] border-[#b45309]' :
                            settings.darkMode && settings.theme === 'zellige-sahara' ? 'bg-[#2a1b12] border-[#d97706]' :
                            'bg-gray-200 dark:bg-gray-700 border-white dark:border-gray-600'
                        }`}>
                            {currentUser?.avatar ? <img src={currentUser.avatar} alt="User" /> : <User size={24} className={`m-2 ${
                                settings.darkMode && settings.theme === 'zellige' ? 'text-[#cca43b]' :
                                settings.darkMode && settings.theme === 'zellige-algiers' ? 'text-[#1e3a8a]' :
                                settings.darkMode && settings.theme === 'zellige-tlemcen' ? 'text-[#b45309]' :
                                settings.darkMode && settings.theme === 'zellige-sahara' ? 'text-[#d97706]' :
                                'text-gray-400'
                            }`}/>}
                        </div>
                        <div className="flex flex-col items-start">
                            <span className={`text-xs font-black ${
                                settings.darkMode && settings.theme === 'zellige' ? 'text-[#cca43b]' :
                                settings.darkMode && settings.theme === 'zellige-algiers' ? 'text-[#f8fafc]' :
                                settings.darkMode && settings.theme === 'zellige-tlemcen' ? 'text-[#fffbeb]' :
                                settings.darkMode && settings.theme === 'zellige-sahara' ? 'text-[#fff7ed]' :
                                'text-gray-800 dark:text-gray-100'
                            }`}>{currentUser?.name.split(' ')[0]}</span>
                            <span className={`text-[9px] font-bold px-1.5 rounded uppercase ${
                                settings.darkMode && settings.theme === 'zellige' ? 'bg-[#cca43b]/20 text-[#cca43b]' :
                                settings.darkMode && settings.theme === 'zellige-algiers' ? 'bg-[#1e3a8a]/20 text-[#f8fafc]' :
                                settings.darkMode && settings.theme === 'zellige-tlemcen' ? 'bg-[#b45309]/20 text-[#fffbeb]' :
                                settings.darkMode && settings.theme === 'zellige-sahara' ? 'bg-[#d97706]/20 text-[#fff7ed]' :
                                'text-gray-400 bg-gray-100 dark:bg-gray-700'
                            }`}>{currentUser?.role}</span>
                        </div>
                    </div>
                    <div className="flex gap-1 relative z-10">
                        <div onClick={(e) => { e.stopPropagation(); toggleDarkMode(); }} className={`p-2 rounded-xl transition cursor-pointer ${
                            settings.darkMode && settings.theme === 'zellige' ? 'hover:bg-[#cca43b]/10 text-[#cca43b]' :
                            settings.darkMode && settings.theme === 'zellige-algiers' ? 'hover:bg-[#1e3a8a]/10 text-[#f8fafc]' :
                            settings.darkMode && settings.theme === 'zellige-tlemcen' ? 'hover:bg-[#b45309]/10 text-[#fffbeb]' :
                            settings.darkMode && settings.theme === 'zellige-sahara' ? 'hover:bg-[#d97706]/10 text-[#fff7ed]' :
                            'hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-500'
                        }`}>{settings.darkMode ? <Sun size={16}/> : <Moon size={16}/>}</div>
                        <div onClick={handleLockApp} className={`p-2 rounded-xl transition cursor-pointer ${
                            settings.darkMode && settings.theme === 'zellige' ? 'hover:bg-red-900/50 text-[#cca43b] hover:text-red-400' :
                            settings.darkMode && settings.theme === 'zellige-algiers' ? 'hover:bg-red-900/50 text-[#f8fafc] hover:text-red-400' :
                            settings.darkMode && settings.theme === 'zellige-tlemcen' ? 'hover:bg-red-900/50 text-[#fffbeb] hover:text-red-400' :
                            settings.darkMode && settings.theme === 'zellige-sahara' ? 'hover:bg-red-900/50 text-[#fff7ed] hover:text-red-400' :
                            'hover:bg-red-50 text-gray-500 hover:text-red-500'
                        }`}><Lock size={16}/></div>
                    </div>
                    {settings.theme === 'zellige' && <div className={`absolute bottom-0 left-0 h-1 w-full opacity-40 ${settings.darkMode ? 'bg-[#cca43b]' : 'bg-[#006269]'}`}></div>}
                    {settings.theme === 'zellige-algiers' && <div className={`absolute bottom-0 left-0 h-1 w-full opacity-40 ${settings.darkMode ? 'bg-[#1e3a8a]' : 'bg-[#1e3a8a]'}`}></div>}
                    {settings.theme === 'zellige-tlemcen' && <div className={`absolute bottom-0 left-0 h-1 w-full opacity-40 ${settings.darkMode ? 'bg-[#b45309]' : 'bg-[#b45309]'}`}></div>}
                    {settings.theme === 'zellige-sahara' && <div className={`absolute bottom-0 left-0 h-1 w-full opacity-40 ${settings.darkMode ? 'bg-[#d97706]' : 'bg-[#d97706]'}`}></div>}
                </button>
            </div>
        </div>
      </aside>

      {/* --- MOBILE HEADER (Smart Hide) --- */}
      <div className={`md:hidden fixed top-0 left-0 right-0 z-50 p-2 pointer-events-none transition-all duration-500 ease-[cubic-bezier(0.32,0.72,0,1)] ${headerVisibilityClass}`}>
          <div className={getMobileHeaderStyle()}>
                <div className="flex items-center gap-2">
                    {/* Unique Profile Shape for Mobile */}
                    <button onClick={() => setActivePage('user_profile')} className={`w-9 h-9 relative overflow-hidden shadow-sm ${settings.theme.startsWith('zellige') ? 'rounded-tl-xl rounded-br-xl rounded-tr-sm rounded-bl-sm rotate-3' : 'rounded-full'}`}>
                        {currentUser?.avatar ? (
                            <img src={currentUser.avatar} alt="Profile" className="w-full h-full object-cover" />
                        ) : (
                            <div className={`w-full h-full flex items-center justify-center ${
                                settings.theme === 'zellige' ? 'bg-[#006269] text-[#cca43b]' : 
                                settings.theme === 'zellige-algiers' ? 'bg-[#1e3a8a] text-[#f8fafc]' :
                                settings.theme === 'zellige-tlemcen' ? 'bg-[#b45309] text-[#fffbeb]' :
                                settings.theme === 'zellige-sahara' ? 'bg-[#d97706] text-[#fff7ed]' :
                                'bg-gray-200 text-gray-500'
                            }`}>
                                <User size={16} />
                            </div>
                        )}
                    </button>
                    <h1 className={`font-black text-sm ${settings.theme.startsWith('zellige') ? 'font-serif tracking-wide' : ''}`}>{settings.appName}</h1>
                </div>
                <div className="flex gap-2">
                    {activePage !== 'dashboard' && <button onClick={handleGlobalBack} className={`p-2 rounded-full ${
                        settings.darkMode && settings.theme === 'zellige' ? 'bg-[#cca43b]/10 text-[#cca43b]' : 
                        settings.darkMode && settings.theme === 'zellige-algiers' ? 'bg-[#1e3a8a]/10 text-[#f8fafc]' :
                        settings.darkMode && settings.theme === 'zellige-tlemcen' ? 'bg-[#b45309]/10 text-[#fffbeb]' :
                        settings.darkMode && settings.theme === 'zellige-sahara' ? 'bg-[#d97706]/10 text-[#fff7ed]' :
                        'bg-gray-100 text-gray-600'
                    }`}><CornerUpRight size={20}/></button>}
                    <button onClick={() => setIsBottomSheetOpen(true)} className={getHeaderBtnStyle()}>
                        {isZelligeTheme && ( <div className={`absolute inset-0 pointer-events-none ${getZelligePatternClass()} ${settings.darkMode ? 'opacity-30 mix-blend-screen' : 'opacity-20 mix-blend-multiply'}`}></div> )}
                        {isOrnateTheme && ( <div className="absolute inset-0 opacity-10 bg-ornate-pattern mix-blend-multiply pointer-events-none"></div> )}
                        <LayoutGrid size={20} className="relative z-10" />
                    </button>
                </div>
          </div>
      </div>

      {/* Main Content */}
      <main className={`flex-1 overflow-hidden relative flex flex-col h-full ${isBottomNavVisible ? 'mb-20 md:mb-0' : 'mb-0'} transition-all duration-500 pb-safe ${hasOpenModal ? 'pt-safe' : 'pt-20 md:pt-4'}`}>
        {isZelligeTheme && (
            <div className={`absolute inset-0 ${getZelligePatternClass()} pointer-events-none z-0 ${settings.darkMode ? 'opacity-20 mix-blend-screen' : 'opacity-10 mix-blend-multiply'}`}></div>
        )}
        <div key={activePage} className="flex-1 overflow-y-auto p-4 md:p-8 scroll-smooth z-10 custom-scrollbar relative">
            <div className="max-w-[1920px] mx-auto pb-10">
                {children}
            </div>
        </div>
      </main>

      {/* --- MOBILE BOTTOM NAV (Smart Hide) --- */}
      <div className={`bottom-nav ${getBottomNavContainerStyle()} ${bottomNavVisibilityClass} ${!isBottomNavVisible ? 'translate-y-[200%] opacity-0 pointer-events-none' : ''}`}>
          {['dashboard', 'accommodation', 'qr_scanner', 'admin_hub'].map(id => {
              if (id === 'admin_hub' && (currentUser?.role !== 'manager' && currentUser?.role !== 'assistant_manager')) return null;
              const item = allNavItems.find(i => i.id === id);
              if(!item) return null;
              const isActive = activePage === id;
              return (
                  <button key={id} onClick={() => setActivePage(id)} className="flex flex-col items-center gap-1 group relative">
                      <div className={`${getIconBoxClass(isActive, true)}`}>
                          {isZelligeTheme && ( <div className={`absolute inset-0 pointer-events-none ${getZelligePatternClass()} ${settings.darkMode ? 'opacity-30 mix-blend-screen' : 'opacity-20 mix-blend-multiply'}`}></div> )}
                          {isOrnateTheme && ( <div className="absolute inset-0 opacity-10 bg-ornate-pattern mix-blend-multiply pointer-events-none"></div> )}
                          <item.icon size={24} strokeWidth={isActive ? 2.5 : 2} className="relative z-10" />
                      </div>
                      {isActive && ( <div className={`absolute -bottom-2 w-1.5 h-1.5 rounded-full ${
                          settings.theme === 'zellige' ? 'bg-[#006269]' : 
                          settings.theme === 'zellige-algiers' ? 'bg-[#1e3a8a]' :
                          settings.theme === 'zellige-tlemcen' ? 'bg-[#b45309]' :
                          settings.theme === 'zellige-sahara' ? 'bg-[#d97706]' :
                          settings.theme === 'modern-ornate' ? 'bg-[#ffd700]' : 
                          'bg-current'
                      }`}></div> )}
                  </button>
              )
          })}
      </div>

      {/* --- BOTTOM NAV TOGGLE BUTTON --- */}
      <button 
          onClick={() => setIsBottomNavVisible(!isBottomNavVisible)}
          className={`md:hidden fixed bottom-4 right-4 z-[60] p-3 rounded-full shadow-xl transition-all duration-300 active:scale-95 flex items-center justify-center ${
              isBottomNavVisible 
              ? 'bg-white/80 backdrop-blur-md text-gray-600 border border-gray-200 dark:bg-gray-800/80 dark:text-gray-300 dark:border-gray-700' 
              : 'bg-blue-600 text-white shadow-blue-600/30 animate-pulse'
          }`}
          style={{ marginBottom: isBottomNavVisible ? '90px' : '20px' }}
          aria-label={isBottomNavVisible ? "إخفاء الشريط السفلي" : "إظهار الشريط السفلي"}
      >
          {isBottomNavVisible ? <ChevronRight size={24} className="rotate-90"/> : <LayoutGrid size={24}/>}
      </button>

      {/* Menu Bottom Sheet */}
      {isBottomSheetOpen && (
          <div className="fixed inset-0 z-[60] bg-black/50 backdrop-blur-sm flex items-end" onClick={() => setIsBottomSheetOpen(false)}>
              <div className="bg-white dark:bg-gray-900 w-full rounded-t-[2.5rem] p-6 max-h-[85vh] overflow-y-auto animate-fade-in-up" onClick={e => e.stopPropagation()}>
                  <div className="flex justify-center mb-6"><div className="w-16 h-1.5 bg-gray-300 dark:bg-gray-600 rounded-full"></div></div>
                  
                  {/* Grouped Menu in Bottom Sheet */}
                  <div className="space-y-6">
                      {navStructure.map((group, i) => (
                          <div key={i}>
                              <h4 className="text-xs font-bold text-gray-400 mb-3 px-2 uppercase tracking-wider">{group.title}</h4>
                              <div className="grid grid-cols-3 sm:grid-cols-4 gap-4">
                                  {group.items.map(item => (
                                      <button key={item.id} onClick={() => { setActivePage(item.id); setIsBottomSheetOpen(false); }} className="flex flex-col items-center gap-1 p-2 rounded-2xl group active:scale-95 transition-transform">
                                          <div className={getMenuIconStyle()}>
                                              {isZelligeTheme && ( <div className={`absolute inset-0 pointer-events-none ${getZelligePatternClass()} ${settings.darkMode ? 'opacity-30 mix-blend-screen' : 'opacity-20 mix-blend-multiply'}`}></div> )}
                                              {isOrnateTheme && ( <div className="absolute inset-0 opacity-10 bg-ornate-pattern mix-blend-multiply pointer-events-none"></div> )}
                                              <item.icon size={24} strokeWidth={2} className="relative z-10"/>
                                          </div>
                                          <span className="text-[10px] font-bold text-center text-gray-700 dark:text-gray-300 leading-tight">{item.label}</span>
                                      </button>
                                  ))}
                              </div>
                          </div>
                      ))}
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};
