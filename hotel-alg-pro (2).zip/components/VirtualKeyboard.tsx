
import React, { useState, useEffect } from 'react';
import { useHotel } from '../context/HotelContext';
import { Delete, ChevronDown, Globe, Type, ArrowBigUp, Check, Minus } from 'lucide-react';

interface VirtualKeyboardProps {
    isVisible: boolean;
    onClose: () => void;
    targetInput: HTMLInputElement | HTMLTextAreaElement | null;
}

export const VirtualKeyboard: React.FC<VirtualKeyboardProps> = ({ isVisible, onClose, targetInput }) => {
    const { settings } = useHotel();
    const [layout, setLayout] = useState<'ar' | 'en' | 'num'>('ar');
    const [capsLock, setCapsLock] = useState(false);
    const [shift, setShift] = useState(false);

    // FIX: Optimized scroll to show input directly above keyboard without gap
    useEffect(() => {
        if (isVisible && targetInput) {
            // Slight delay to allow keyboard animation to start
            setTimeout(() => {
                targetInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }, 100);
        }
    }, [isVisible, targetInput]);

    // Layout Definitions
    const layouts = {
        ar: [
            ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
            ['ض', 'ص', 'ث', 'ق', 'ف', 'غ', 'ع', 'ه', 'خ', 'ح', 'ج', 'د'],
            ['ش', 'س', 'ي', 'ب', 'ل', 'ا', 'ت', 'ن', 'م', 'ك', 'ط'],
            ['ئ', 'ء', 'ؤ', 'ر', 'لا', 'ى', 'ة', 'و', 'ز', 'ظ', 'ذ']
        ],
        en: [
            ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
            ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
            ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'],
            ['z', 'x', 'c', 'v', 'b', 'n', 'm']
        ],
        num: [
            ['1', '2', '3'],
            ['4', '5', '6'],
            ['7', '8', '9'],
            ['.', '0', '-']
        ]
    };

    const triggerInputEvent = (input: HTMLInputElement | HTMLTextAreaElement, newValue: string) => {
        const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
            window.HTMLInputElement.prototype, 
            "value"
        )?.set;
        
        if (nativeInputValueSetter) {
            nativeInputValueSetter.call(input, newValue);
        } else {
            input.value = newValue;
        }

        const event = new Event('input', { bubbles: true });
        input.dispatchEvent(event);
    };

    const handleKeyPress = (key: string) => {
        if (!targetInput) return;

        const start = targetInput.selectionStart || 0;
        const end = targetInput.selectionEnd || 0;
        const value = targetInput.value;
        const newValue = value.substring(0, start) + key + value.substring(end);

        triggerInputEvent(targetInput, newValue);

        targetInput.focus();
        const newCursorPos = start + key.length;
        requestAnimationFrame(() => {
            targetInput.setSelectionRange(newCursorPos, newCursorPos);
        });

        if (shift) setShift(false);
    };

    const handleBackspace = () => {
        if (!targetInput) return;
        const start = targetInput.selectionStart || 0;
        const end = targetInput.selectionEnd || 0;
        const value = targetInput.value;

        if (start === end && start === 0) return;

        let newValue;
        let newCursorPos;

        if (start !== end) {
            newValue = value.substring(0, start) + value.substring(end);
            newCursorPos = start;
        } else {
            newValue = value.substring(0, start - 1) + value.substring(end);
            newCursorPos = start - 1;
        }

        triggerInputEvent(targetInput, newValue);

        targetInput.focus();
        requestAnimationFrame(() => {
            targetInput.setSelectionRange(newCursorPos, newCursorPos);
        });
    };

    const getThemeStyles = () => {
        switch (settings.theme) {
            case 'zellige': return {
                container: 'bg-[#FDFBF7] border-t-0 shadow-[0_-2px_10px_rgba(0,0,0,0.1)]',
                key: 'bg-white text-[#006269] border border-[#cca43b]/20 shadow-[0_1px_0_#cca43b] active:translate-y-[1px] active:shadow-none',
                specialKey: 'bg-[#fbf8f1] text-[#cca43b] border border-[#cca43b]/40 shadow-[0_1px_0_#cca43b]',
                actionKey: 'bg-[#006269] text-[#cca43b] border border-[#004d53] shadow-[0_1px_0_#004d53] active:bg-[#004d53]',
                header: 'bg-[#006269]/5 text-[#006269]',
                pattern: 'opacity-10 bg-zellige-pattern'
            };
            case 'zellige-v2': return {
                container: 'bg-[#f5fcf9] border-t-0 shadow-[0_-2px_10px_rgba(0,0,0,0.1)]',
                key: 'bg-white text-[#024d38] border border-[#c6e3d8] shadow-[0_1px_0_#c6e3d8] active:translate-y-[1px] active:shadow-none',
                specialKey: 'bg-[#e6f7f2] text-[#024d38] border border-[#c6e3d8] shadow-[0_1px_0_#024d38]',
                actionKey: 'bg-[#024d38] text-white border border-[#013b2b] shadow-[0_1px_0_#013b2b]',
                header: 'bg-[#024d38]/5 text-[#024d38]',
                pattern: 'opacity-10 bg-zellige-v2-pattern'
            };
            default: return {
                container: 'bg-gray-100 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700',
                key: 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm active:bg-gray-200 dark:active:bg-gray-600',
                specialKey: 'bg-gray-200 dark:bg-gray-600 text-gray-700 dark:text-gray-300',
                actionKey: 'bg-blue-600 text-white shadow-sm active:bg-blue-700',
                header: 'bg-gray-200 dark:bg-gray-800 text-gray-500 dark:text-gray-400',
                pattern: ''
            };
        }
    };
    const ts = getThemeStyles();

    if (!isVisible) return null;

    const currentRows = layouts[layout];
    // Reduced height for tighter fit
    const keyBaseClass = `rounded-md flex items-center justify-center text-lg md:text-xl transition-all duration-75 select-none h-9 md:h-10 font-bold relative overflow-hidden`;

    return (
        <div 
            className={`fixed bottom-0 left-0 right-0 z-[9999] transition-transform duration-200 transform ${isVisible ? 'translate-y-0' : 'translate-y-full'} ${ts.container} pb-safe`}
            onMouseDown={(e) => e.preventDefault()} 
        >
            {ts.pattern && <div className={`absolute inset-0 pointer-events-none ${ts.pattern} mix-blend-multiply`}></div>}

            <div className={`flex justify-between items-center px-1 py-0.5 relative z-10 ${ts.header}`}>
                <div className="flex-1 flex justify-center gap-2 text-[10px] font-bold opacity-80">
                    <span className="cursor-pointer hover:opacity-100 bg-white/50 px-2 py-0.5 rounded">إتمام</span>
                </div>
                <button onClick={onClose} className="p-1 rounded-full hover:bg-black/10 transition active:scale-90">
                    <ChevronDown size={18} />
                </button>
            </div>

            <div className={`p-1 pt-0 max-w-full mx-auto flex flex-col gap-1 relative z-10`}>
                {layout === 'num' ? (
                    <div className="grid grid-cols-3 gap-1 px-4 pb-1 pt-1">
                        {layouts.num.flat().map((key) => (
                            <button key={key} onClick={() => handleKeyPress(key)} className={`${keyBaseClass} text-xl ${ts.key} h-11`}>{key}</button>
                        ))}
                        <button onClick={handleBackspace} className={`${keyBaseClass} ${ts.specialKey} h-11`}><Delete size={18} /></button>
                        <button onClick={() => setLayout('ar')} className={`${keyBaseClass} ${ts.actionKey} h-11`}><Type size={18} /></button>
                    </div>
                ) : (
                    <>
                        {currentRows.map((row, rowIndex) => (
                            <div key={rowIndex} className="flex justify-center gap-1 px-0.5">
                                {row.map((key) => {
                                    const displayKey = (capsLock || shift) && layout === 'en' ? key.toUpperCase() : key;
                                    return (
                                        <button
                                            key={key}
                                            onClick={() => handleKeyPress(displayKey)}
                                            className={`${keyBaseClass} flex-1 ${ts.key}`}
                                            style={{ maxWidth: '10%' }}
                                        >
                                            {displayKey}
                                        </button>
                                    )
                                })}
                            </div>
                        ))}
                        
                        <div className="flex items-center gap-1 px-0.5 mt-0.5 mb-0.5">
                            {layout === 'en' ? (
                                <button onClick={() => { setCapsLock(!capsLock); setShift(!shift); }} className={`${keyBaseClass} w-[12%] ${capsLock || shift ? ts.actionKey : ts.specialKey}`}>
                                    {capsLock ? <ArrowBigUp size={18} fill="currentColor" /> : <ArrowBigUp size={18} />}
                                </button>
                            ) : (
                                <button onClick={() => setLayout('num')} className={`${keyBaseClass} w-[12%] ${ts.specialKey}`}>123</button>
                            )}

                            <button onClick={() => setLayout(layout === 'ar' ? 'en' : 'ar')} className={`${keyBaseClass} w-[10%] ${ts.specialKey}`}><Globe size={16} /></button>
                            <button onClick={() => handleKeyPress(' ')} className={`${keyBaseClass} flex-1 ${ts.key}`}><Minus size={18} className="opacity-30" /></button>
                            <button onClick={handleBackspace} className={`${keyBaseClass} w-[12%] ${ts.specialKey}`}><Delete size={18} /></button>
                            <button onClick={onClose} className={`${keyBaseClass} w-[12%] ${ts.actionKey}`}><Check size={18} /></button>
                        </div>
                    </>
                )}
            </div>
        </div>
    );
};
