import React, { useEffect } from 'react';
import { useHotel } from '../context/HotelContext';
import { X } from 'lucide-react';

interface ModalProps {
    isOpen: boolean;
    onClose: () => void;
    title: React.ReactNode;
    children: React.ReactNode;
    size?: 'sm' | 'md' | 'lg' | 'xl' | 'full';
    className?: string;
}

export const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, children, size = 'md', className = '' }) => {
    const { settings } = useHotel();

    useEffect(() => {
        if (isOpen) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = 'unset';
        }
        return () => {
            document.body.style.overflow = 'unset';
        };
    }, [isOpen]);

    if (!isOpen) return null;

    const isZellige = settings.theme === 'zellige' || settings.theme === 'zellige-v2';
    const isWeaponsFire = settings.theme === 'weapons-fire';

    let containerClass = "";
    let headerClass = "";
    let closeBtnClass = "";
    let bgOverlayClass = "bg-black/60 backdrop-blur-sm";

    if (isZellige) {
        if (settings.darkMode) {
            containerClass = "bg-[#002a2d] border-[3px] border-[#cca43b] text-[#cca43b] shadow-[0_0_30px_rgba(204,164,59,0.1)]";
            headerClass = "bg-[#001e21] text-[#cca43b] border-b border-[#cca43b]/30";
            closeBtnClass = "hover:bg-[#cca43b]/20 hover:text-[#cca43b]";
        } else {
            containerClass = "bg-[#FDFBF7] border-[3px] border-[#cca43b] text-[#006269]";
            headerClass = "bg-[#006269] text-[#cca43b] border-b border-[#cca43b]";
            closeBtnClass = "hover:bg-[#cca43b] hover:text-[#006269]";
        }
    } else if (isWeaponsFire) {
        containerClass = "bg-neutral-900 border-2 border-orange-600 text-orange-50 shadow-[0_0_30px_rgba(234,88,12,0.3)]";
        headerClass = "bg-gradient-to-r from-orange-900 to-red-900 text-orange-100 border-b border-orange-600";
        closeBtnClass = "hover:bg-orange-600 hover:text-white";
        bgOverlayClass = "bg-black/80 backdrop-blur-md";
    } else {
        containerClass = "bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white";
        headerClass = "bg-gray-50 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700";
        closeBtnClass = "hover:bg-gray-200 dark:hover:bg-gray-700";
    }

    const sizeClasses = {
        sm: 'max-w-md',
        md: 'max-w-lg',
        lg: 'max-w-4xl',
        xl: 'max-w-6xl',
        full: 'max-w-full h-[95vh]'
    };

    return (
        <div className={`fixed inset-0 z-[100] flex items-center justify-center p-4 ${bgOverlayClass} animate-fade-in`}>
            <div 
                className={`w-full ${sizeClasses[size]} rounded-[2rem] shadow-2xl flex flex-col overflow-hidden relative max-h-[90vh] ${containerClass} ${className}`}
                onClick={e => e.stopPropagation()}
            >
                {isZellige && <div className="absolute inset-0 opacity-10 bg-zellige-pattern mix-blend-multiply pointer-events-none"></div>}
                {isWeaponsFire && <div className="absolute inset-0 opacity-20 bg-weapons-fire-pattern pointer-events-none"></div>}

                <div className={`p-6 flex justify-between items-center shrink-0 relative z-10 ${headerClass}`}>
                    <div className="text-xl font-black flex items-center gap-3">{title}</div>
                    <button 
                        onClick={onClose} 
                        className={`p-2 rounded-full transition-colors ${closeBtnClass}`}
                    >
                        <X size={24} />
                    </button>
                </div>

                <div className="flex-1 overflow-y-auto custom-scrollbar relative z-10">
                    {children}
                </div>
            </div>
        </div>
    );
};
