import React from 'react';
import { User, Department } from '../types';
import { QrCode, MapPin, Calendar, Phone, Mail, Shield, Award } from 'lucide-react';

interface StaffCardProps {
  user: User;
  deptInfo: { label: string; color: string; bg: string; border: string; icon: any };
  settings: any;
  onClick?: () => void;
}

export const StaffCard: React.FC<StaffCardProps> = ({ user, deptInfo, settings, onClick }) => {
  const isZellige = settings.theme === 'zellige' || settings.theme === 'zellige-v2';
  const isDark = settings.darkMode;

  // Generate a fake ID number based on user ID
  const employeeId = user.id.replace(/\D/g, '').padEnd(6, '0').slice(0, 6);

  const cardBaseClass = isDark 
    ? (isZellige ? "bg-[#001e21] border-[#cca43b]/40 text-[#cca43b]" : "bg-gray-800 border-gray-700 text-white")
    : (isZellige ? "bg-[#FDFBF7] border-[#cca43b]/40 text-[#006269]" : "bg-white border-gray-200 text-gray-800");

  const patternClass = isZellige 
    ? (isDark ? "bg-zellige-pattern opacity-10 mix-blend-screen" : "bg-zellige-pattern opacity-5 mix-blend-multiply")
    : "";

  return (
    <div 
      onClick={onClick}
      className={`relative w-full aspect-[1.586/1] rounded-2xl overflow-hidden border shadow-lg transition-all duration-300 hover:scale-[1.02] hover:shadow-xl cursor-pointer group ${cardBaseClass}`}
    >
      {/* Background Pattern */}
      <div className={`absolute inset-0 pointer-events-none ${patternClass}`}></div>
      
      {/* Header Band */}
      <div className={`absolute top-0 left-0 right-0 h-16 ${isZellige ? (isDark ? 'bg-[#002a2d]/80' : 'bg-[#006269]/10') : 'bg-gray-100 dark:bg-gray-700'} backdrop-blur-sm border-b ${isZellige ? 'border-[#cca43b]/20' : 'border-gray-200 dark:border-gray-600'}`}></div>

      <div className="relative z-10 p-4 h-full flex flex-col">
        
        {/* Top Section */}
        <div className="flex justify-between items-start mb-2">
          <div className="flex items-center gap-3">
            <div className={`w-16 h-16 rounded-xl overflow-hidden border-2 shadow-md ${isZellige ? 'border-[#cca43b]' : 'border-white dark:border-gray-600'}`}>
              <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
            </div>
            <div>
              <h3 className="font-black text-lg leading-tight">{user.name.split('(')[0]}</h3>
              <p className={`text-xs font-bold opacity-80 uppercase tracking-wider`}>{user.role.replace('_', ' ')}</p>
            </div>
          </div>
          <div className="text-right">
             <button onClick={(e) => { e.stopPropagation(); alert(`QR Code for ${user.name}`); }} className="hover:scale-110 transition-transform">
                <QrCode size={32} className={`opacity-80 ${isZellige ? 'text-[#cca43b]' : 'text-gray-400'}`} />
             </button>
          </div>
        </div>

        {/* Middle Section - Details */}
        <div className="flex-1 flex flex-col justify-center gap-1.5 text-[10px] font-medium opacity-90 pl-1">
          <div className="flex items-center gap-2">
            <Shield size={12} />
            <span>ID: <span className="font-mono font-bold text-xs">EMP-{employeeId}</span></span>
          </div>
          <div className="flex items-center gap-2">
            <Award size={12} />
            <span>Dept: {deptInfo.label}</span>
          </div>
          <div className="flex items-center gap-2">
            <Calendar size={12} />
            <span>Joined: {new Date(user.joinDate || Date.now()).toLocaleDateString()}</span>
          </div>
        </div>

        {/* Bottom Section - Status */}
        <div className="flex justify-between items-end mt-auto pt-2 border-t border-current/10">
           <div className={`px-2 py-0.5 rounded text-[9px] font-black uppercase ${user.isBlocked ? 'bg-red-500 text-white' : 'bg-green-500 text-white'}`}>
             {user.isBlocked ? 'SUSPENDED' : 'ACTIVE'}
           </div>
           <div className="text-[8px] opacity-60 font-mono tracking-widest">
             AUTHORIZED PERSONNEL
           </div>
        </div>

      </div>
      
      {/* Holographic Effect Overlay (Simulated) */}
      <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none mix-blend-overlay"></div>
    </div>
  );
};
