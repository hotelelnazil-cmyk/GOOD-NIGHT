import React, { useState, useEffect } from 'react';
import { useHotel } from '../context/HotelContext';
import { Send, Bell, MapPin, Phone, Coffee, Info, MessageCircle, LogOut } from 'lucide-react';

interface GuestPortalProps {
    token: string;
}

export const GuestPortal: React.FC<GuestPortalProps> = ({ token }) => {
    const { bookings, rooms, settings, sendGuestMessage, messages } = useHotel();
    const [input, setInput] = useState('');
    const [activeTab, setActiveTab] = useState<'info' | 'chat'>('info');

    // Find booking
    const booking = bookings.find(b => b.guestToken === token && b.status === 'active');
    const room = booking ? rooms.find(r => r.id === booking.roomId) : null;

    if (!booking || !room) {
        return (
            <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4 text-center">
                <div className="bg-white p-8 rounded-xl shadow-lg">
                    <LogOut size={48} className="mx-auto text-red-400 mb-4" />
                    <h2 className="text-xl font-bold text-gray-800">صلاحية منتهية</h2>
                    <p className="text-gray-500 mt-2">يبدو أن هذا الحجز قد انتهى أو أن الكود غير صحيح.</p>
                </div>
            </div>
        );
    }

    // Filter chat for this guest
    // Internal senderId for guest is the TOKEN
    const chatMessages = messages.filter(m => m.senderId === token || m.receiverId === token);

    const handleSend = (e: React.FormEvent) => {
        e.preventDefault();
        if(!input.trim()) return;
        sendGuestMessage(token, input);
        setInput('');
    }

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col font-sans" dir="rtl">
            {/* Mobile Header */}
            <header className="bg-blue-600 text-white p-4 shadow-lg sticky top-0 z-10">
                <div className="flex justify-between items-center">
                    <div>
                        <h1 className="font-bold text-lg">{settings.appName}</h1>
                        <p className="text-xs opacity-90">بوابة النزيل</p>
                    </div>
                    <div className="text-left">
                        <span className="block text-2xl font-bold font-mono">{room.number}</span>
                        <span className="text-xs opacity-75">رقم الغرفة</span>
                    </div>
                </div>
            </header>

            <main className="flex-1 p-4 overflow-y-auto">
                <div className="flex gap-2 mb-4 bg-white p-1 rounded-lg shadow-sm">
                    <button 
                        onClick={() => setActiveTab('info')}
                        className={`flex-1 py-2 rounded-md font-bold text-sm flex items-center justify-center gap-2 ${activeTab === 'info' ? 'bg-blue-100 text-blue-600' : 'text-gray-500'}`}
                    >
                        <Info size={16} /> معلومات
                    </button>
                    <button 
                        onClick={() => setActiveTab('chat')}
                        className={`flex-1 py-2 rounded-md font-bold text-sm flex items-center justify-center gap-2 ${activeTab === 'chat' ? 'bg-blue-100 text-blue-600' : 'text-gray-500'}`}
                    >
                        <MessageCircle size={16} /> طلبات ومحادثة
                    </button>
                </div>

                {activeTab === 'info' && (
                    <div className="space-y-4 animate-fade-in">
                        <div className="bg-white p-6 rounded-xl shadow-sm text-center">
                            <h2 className="text-xl font-bold text-gray-800 mb-1">مرحباً، {booking.primaryGuestName}</h2>
                            <p className="text-gray-500 text-sm">نتمنى لك إقامة ممتعة ومريحة</p>
                        </div>

                        <div className="bg-white p-4 rounded-xl shadow-sm space-y-3">
                            <h3 className="font-bold border-b pb-2 mb-2">معلومات الفندق</h3>
                            <div className="flex items-center gap-3 text-sm text-gray-600">
                                <MapPin size={16} className="text-blue-500"/>
                                <span>{settings.hotelAddress}</span>
                            </div>
                            <div className="flex items-center gap-3 text-sm text-gray-600">
                                <Phone size={16} className="text-blue-500"/>
                                <a href={`tel:${settings.hotelPhone}`} className="hover:underline">{settings.hotelPhone}</a>
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                            <button onClick={() => { setActiveTab('chat'); setInput('أريد طلب خدمة الغرف (قهوة/ماء)'); }} className="bg-white p-4 rounded-xl shadow-sm flex flex-col items-center justify-center gap-2 active:scale-95 transition">
                                <Coffee size={24} className="text-orange-500" />
                                <span className="font-bold text-sm text-gray-700">طلب مشروبات</span>
                            </button>
                            <button onClick={() => { setActiveTab('chat'); setInput('أحتاج تنظيف الغرفة من فضلك'); }} className="bg-white p-4 rounded-xl shadow-sm flex flex-col items-center justify-center gap-2 active:scale-95 transition">
                                <Bell size={24} className="text-purple-500" />
                                <span className="font-bold text-sm text-gray-700">طلب تنظيف</span>
                            </button>
                        </div>
                    </div>
                )}

                {activeTab === 'chat' && (
                    <div className="flex flex-col h-[calc(100vh-180px)] bg-white rounded-xl shadow-sm overflow-hidden border">
                        <div className="flex-1 overflow-y-auto p-4 space-y-3">
                            {chatMessages.length === 0 && (
                                <div className="text-center text-gray-400 text-sm mt-10">
                                    يمكنك مراسلة الاستقبال مباشرة من هنا
                                </div>
                            )}
                            {chatMessages.map(msg => (
                                <div key={msg.id} className={`flex ${msg.senderId === token ? 'justify-end' : 'justify-start'}`}>
                                    <div className={`max-w-[85%] p-3 rounded-lg text-sm ${msg.senderId === token ? 'bg-blue-600 text-white rounded-tl-none' : 'bg-gray-100 text-gray-800 rounded-tr-none'}`}>
                                        {msg.content}
                                    </div>
                                </div>
                            ))}
                        </div>
                        <form onSubmit={handleSend} className="p-3 border-t bg-gray-50 flex gap-2">
                            <input 
                                type="text" 
                                value={input}
                                onChange={e => setInput(e.target.value)}
                                placeholder="اكتب طلبك..."
                                className="flex-1 border rounded-full px-4 py-2 focus:outline-none focus:border-blue-500"
                            />
                            <button type="submit" className="bg-blue-600 text-white p-2 rounded-full shadow-lg">
                                <Send size={20} />
                            </button>
                        </form>
                    </div>
                )}
            </main>
        </div>
    );
}