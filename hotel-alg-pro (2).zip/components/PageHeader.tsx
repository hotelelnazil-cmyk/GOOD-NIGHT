
import React, { useState } from 'react';
import { useHotel } from '../context/HotelContext';
import { Edit2, Check, X, ArrowRight, Crown, Shield, Headphones, User, Hexagon, ChefHat, Coffee, ChevronRight, CornerUpRight } from 'lucide-react';

interface PageHeaderProps {
  pageKey: string;
  defaultTitle: string;
  icon?: React.ElementType;
  onBack?: () => void; 
}

export const PageHeader: React.FC<PageHeaderProps> = ({ pageKey, defaultTitle, icon: Icon }) => {
  const { settings, updatePageTitle, currentUser } = useHotel();
  const [isEditing, setIsEditing] = useState(false);
  const [tempTitle, setTempTitle] = useState('');

  const currentTitle = settings.pageTitles[pageKey] || defaultTitle;
  const canEdit = currentUser?.role === 'manager' || currentUser?.permissions.canCustomizeTitles;

  // Dispatch global back event handled by App.tsx history logic
  const handleBack = () => {
      window.dispatchEvent(new Event('go-back'));
  };

  const handleEditClick = () => {
      setTempTitle(currentTitle);
      setIsEditing(true);
  };

  const handleSave = () => {
      if (tempTitle.trim()) {
          updatePageTitle(pageKey, tempTitle);
      }
      setIsEditing(false);
  };

  const handleProfileClick = () => {
      // Trigger navigation to user_profile page via event
      window.dispatchEvent(new CustomEvent('navigate-to', { detail: 'user_profile' }));
  };

  const getUserRoleLabel = (role?: string) => {
      switch (role) {
          case 'manager': return 'المدير العام';
          case 'assistant_manager': return 'مساعد إداري';
          case 'receptionist': return 'موظف استقبال';
          case 'restaurant_manager': return 'مدير المطعم';
          case 'cafe_manager': return 'مدير المقهى';
          default: return 'موظف';
      }
  };

  const getUserRoleIcon = (role?: string) => {
      switch (role) {
          case 'manager': return <Crown size={16} className="text-yellow-400 fill-current drop-shadow-sm" />;
          case 'assistant_manager': return <Shield size={16} />;
          case 'restaurant_manager': return <ChefHat size={16} />;
          case 'cafe_manager': return <Coffee size={16} />;
          default: return <Headphones size={16} />;
      }
  };

  // --- Theme Styles ---
  const getContainerStyle = () => {
      const base = "relative mb-8 transition-all duration-500 flex flex-row-reverse items-center justify-between overflow-visible rounded-[2.5rem] p-3 shadow-lg group z-30"; 
      
      if (settings.darkMode) {
          if (settings.theme === 'zellige') return `${base} bg-[#002a2d] border-[3px] border-[#cca43b]/40`;
          if (settings.theme === 'zellige-v2') return `${base} bg-[#012a20] border-[3px] border-[#024d38]/40`;
          if (settings.theme === 'zellige-algiers') return `${base} bg-[#0f172a] border-[3px] border-[#1e3a8a]/40`;
          if (settings.theme === 'zellige-tlemcen') return `${base} bg-[#271c19] border-[3px] border-[#b45309]/40`;
          if (settings.theme === 'zellige-sahara') return `${base} bg-[#2a1b12] border-[3px] border-[#d97706]/40`;
      }

      switch(settings.theme) {
          case 'zellige':
              return `${base} bg-[#fdfbf7] border-[3px] border-[#cca43b]`;
          case 'zellige-algiers':
              return `${base} bg-[#eff6ff] border-[3px] border-[#1e3a8a]`;
          case 'zellige-tlemcen':
              return `${base} bg-[#fffbeb] border-[3px] border-[#b45309]`;
          case 'zellige-sahara':
              return `${base} bg-[#fff7ed] border-[3px] border-[#d97706]`;
          case 'lihab-al-oud':
              return `${base} bg-[#fdfcf0] border-[3px] border-[#d97706]`;
          case 'zellige-v2':
              return `${base} bg-[#f5fcf9] border-[3px] border-[#024d38]`;
          case 'real-madrid':
              return `${base} bg-white border-2 border-[#FEBE10] shadow-blue-900/10`;
          case 'instagram':
              return `${base} bg-gradient-to-r from-[#833AB4] via-[#FD1D1D] to-[#FCAF45] text-white border-none`;
          default:
              return `${base} bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 text-slate-800 dark:text-white`;
      }
  };

  // Title Section Styles
  const getTitleStyle = () => {
      if (settings.darkMode) {
          if (settings.theme === 'zellige') return 'text-[#f0c04a] drop-shadow-sm';
          if (settings.theme === 'zellige-v2') return 'text-[#c6e3d8] drop-shadow-sm';
          if (settings.theme === 'zellige-algiers') return 'text-[#f8fafc] drop-shadow-sm';
          if (settings.theme === 'zellige-tlemcen') return 'text-[#fffbeb] drop-shadow-sm';
          if (settings.theme === 'zellige-sahara') return 'text-[#fff7ed] drop-shadow-sm';
      }

      switch(settings.theme) {
          case 'zellige': return 'text-[#006269]';
          case 'zellige-algiers': return 'text-[#1e3a8a]';
          case 'zellige-tlemcen': return 'text-[#b45309]';
          case 'zellige-sahara': return 'text-[#d97706]';
          case 'lihab-al-oud': return 'text-[#451a03]';
          case 'zellige-v2': return 'text-[#024d38]';
          case 'real-madrid': return 'text-[#00529F]';
          case 'instagram': return 'text-white';
          default: return 'text-slate-800 dark:text-gray-100';
      }
  };

  // Icon Box Style (Consistent with sidebar)
  const getIconBoxStyle = () => {
      if (settings.darkMode) {
          if (settings.theme === 'zellige') return 'bg-[#002a2d] text-[#f0c04a] shadow-lg shadow-[#000]/30 border-2 border-[#cca43b]/40';
          if (settings.theme === 'zellige-v2') return 'bg-[#012a20] text-[#c6e3d8] shadow-lg shadow-[#000]/30 border-2 border-[#024d38]/40';
          if (settings.theme === 'zellige-algiers') return 'bg-[#0f172a] text-[#f8fafc] shadow-lg shadow-[#000]/30 border-2 border-[#1e3a8a]/40';
          if (settings.theme === 'zellige-tlemcen') return 'bg-[#271c19] text-[#fffbeb] shadow-lg shadow-[#000]/30 border-2 border-[#b45309]/40';
          if (settings.theme === 'zellige-sahara') return 'bg-[#2a1b12] text-[#fff7ed] shadow-lg shadow-[#000]/30 border-2 border-[#d97706]/40';
      }

      switch(settings.theme) {
          case 'zellige': return 'bg-[#006269] text-[#cca43b] shadow-lg shadow-[#006269]/30 border-2 border-[#cca43b]';
          case 'zellige-algiers': return 'bg-[#1e3a8a] text-[#f8fafc] shadow-lg shadow-[#1e3a8a]/30 border-2 border-[#1e3a8a]';
          case 'zellige-tlemcen': return 'bg-[#b45309] text-[#fffbeb] shadow-lg shadow-[#b45309]/30 border-2 border-[#b45309]';
          case 'zellige-sahara': return 'bg-[#d97706] text-[#fff7ed] shadow-lg shadow-[#d97706]/30 border-2 border-[#d97706]';
          case 'zellige-v2': return 'bg-[#024d38] text-white shadow-lg border border-[#c6e3d8]';
          case 'lihab-al-oud': return 'bg-[#451a03] text-[#fcd34d] border border-[#d97706]';
          case 'instagram': return 'bg-white/20 text-white backdrop-blur-md shadow-md';
          case 'real-madrid': return 'bg-[#00529F] text-white border border-[#FEBE10]';
          default: return 'bg-blue-600 dark:bg-blue-500 text-white shadow-lg shadow-blue-500/30';
      }
  };

  // Back Button Styles
  const getBackButtonStyle = () => {
      const base = "ml-4 p-3 rounded-full transition-all duration-300 hover:scale-110 active:scale-90 flex items-center justify-center shadow-md relative overflow-hidden group/btn";
      
      if (settings.darkMode) {
          if (settings.theme === 'zellige') return `${base} bg-[#002a2d] text-[#f0c04a] border-2 border-[#cca43b]/40 hover:shadow-[#cca43b]/20`;
          if (settings.theme === 'zellige-v2') return `${base} bg-[#012a20] text-[#c6e3d8] border-2 border-[#024d38]/40 hover:shadow-[#024d38]/20`;
          if (settings.theme === 'zellige-algiers') return `${base} bg-[#0f172a] text-[#f8fafc] border-2 border-[#1e3a8a]/40 hover:shadow-[#1e3a8a]/20`;
          if (settings.theme === 'zellige-tlemcen') return `${base} bg-[#271c19] text-[#fffbeb] border-2 border-[#b45309]/40 hover:shadow-[#b45309]/20`;
          if (settings.theme === 'zellige-sahara') return `${base} bg-[#2a1b12] text-[#fff7ed] border-2 border-[#d97706]/40 hover:shadow-[#d97706]/20`;
      }

      switch(settings.theme) {
          case 'zellige':
              return `${base} bg-[#006269] text-[#cca43b] border-2 border-[#cca43b] hover:shadow-[#006269]/30`;
          case 'zellige-algiers':
              return `${base} bg-[#1e3a8a] text-[#f8fafc] border-2 border-[#1e3a8a] hover:shadow-[#1e3a8a]/30`;
          case 'zellige-tlemcen':
              return `${base} bg-[#b45309] text-[#fffbeb] border-2 border-[#b45309] hover:shadow-[#b45309]/30`;
          case 'zellige-sahara':
              return `${base} bg-[#d97706] text-[#fff7ed] border-2 border-[#d97706] hover:shadow-[#d97706]/30`;
          case 'lihab-al-oud':
              return `${base} bg-[#451a03] text-[#fcd34d] border-2 border-[#d97706] hover:shadow-[#d97706]/40`;
          case 'zellige-v2':
              return `${base} bg-[#024d38] text-white border-2 border-[#c6e3d8]`;
          case 'instagram':
              return `${base} bg-white/20 backdrop-blur-md text-white border border-white/40 hover:bg-white/30`;
          default:
              return `${base} bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 border border-gray-200 dark:border-gray-600 hover:bg-gray-50`;
      }
  };

  const containerClasses = getContainerStyle();
  const titleColor = getTitleStyle();
  const backBtnClass = getBackButtonStyle();
  const iconBoxClass = getIconBoxStyle();
  const isZellige = settings.theme.startsWith('zellige');

  const getZelligePatternClass = () => {
      if (settings.theme === 'zellige') return 'bg-zellige-pattern';
      if (settings.theme === 'zellige-v2') return 'bg-zellige-v2-pattern';
      if (settings.theme === 'zellige-algiers') return 'bg-zellige-algiers-pattern';
      if (settings.theme === 'zellige-tlemcen') return 'bg-zellige-tlemcen-pattern';
      if (settings.theme === 'zellige-sahara') return 'bg-zellige-sahara-pattern';
      return 'bg-zellige-pattern';
  };

  return (
    <div className={containerClasses}>
        
        {/* Patterns */}
        {isZellige && <div className={`absolute inset-0 ${getZelligePatternClass()} pointer-events-none rounded-[2.5rem] ${settings.darkMode ? 'opacity-20 mix-blend-screen' : 'opacity-15 mix-blend-multiply'}`}></div>}
        {settings.theme === 'lihab-al-oud' && <div className="absolute inset-0 bg-oud-pattern opacity-10 pointer-events-none mix-blend-multiply rounded-[2.5rem]"></div>}

        {/* --- LEFT SIDE: User Profile --- */}
        {currentUser && (
            <div 
                className="flex items-center gap-4 relative z-10 pl-6 pr-2 cursor-pointer group/profile hover:bg-white/10 rounded-3xl transition-colors py-1"
                onClick={handleProfileClick}
                title="عرض بطاقة الموظف"
            >
                <div className="flex flex-col items-end">
                    <h3 className={`text-lg font-black leading-tight ${titleColor}`}>
                        {currentUser.name}
                    </h3>
                    <div className={`flex items-center gap-1.5 mt-0.5 px-2 py-0.5 rounded-lg text-xs font-bold uppercase tracking-wider
                        ${settings.darkMode && settings.theme === 'zellige' ? 'bg-[#cca43b]/10 text-[#f0c04a]' :
                          settings.darkMode && settings.theme === 'zellige-v2' ? 'bg-[#024d38]/10 text-[#c6e3d8]' :
                          settings.darkMode && settings.theme === 'zellige-algiers' ? 'bg-[#1e3a8a]/10 text-[#f8fafc]' :
                          settings.darkMode && settings.theme === 'zellige-tlemcen' ? 'bg-[#b45309]/10 text-[#fffbeb]' :
                          settings.darkMode && settings.theme === 'zellige-sahara' ? 'bg-[#d97706]/10 text-[#fff7ed]' :
                          settings.theme === 'zellige' ? 'bg-[#cca43b]/10 text-[#006269]' : 
                          settings.theme === 'zellige-algiers' ? 'bg-[#1e3a8a]/10 text-[#1e3a8a]' :
                          settings.theme === 'zellige-tlemcen' ? 'bg-[#b45309]/10 text-[#b45309]' :
                          settings.theme === 'zellige-sahara' ? 'bg-[#d97706]/10 text-[#d97706]' :
                          settings.theme === 'lihab-al-oud' ? 'bg-[#fef3c7] text-[#78350f]' :
                          settings.theme === 'zellige-v2' ? 'bg-[#c6e3d8]/30 text-[#024d38]' :
                          settings.theme === 'instagram' ? 'bg-white/20 text-white' :
                          'bg-gray-100 dark:bg-gray-700/50 text-gray-500 dark:text-gray-300'
                        }
                    `}>
                        {getUserRoleLabel(currentUser.role)}
                        {getUserRoleIcon(currentUser.role)}
                    </div>
                </div>

                <div className="relative group cursor-pointer">
                    <div className={`p-1 rounded-[1.5rem] shadow-lg transition-transform duration-500 group-hover:scale-105 group-hover:rotate-2 
                        ${settings.darkMode && settings.theme === 'zellige' ? 'bg-[#002a2d]' :
                          settings.darkMode && settings.theme === 'zellige-v2' ? 'bg-[#012a20]' :
                          settings.darkMode && settings.theme === 'zellige-algiers' ? 'bg-[#0f172a]' :
                          settings.darkMode && settings.theme === 'zellige-tlemcen' ? 'bg-[#271c19]' :
                          settings.darkMode && settings.theme === 'zellige-sahara' ? 'bg-[#2a1b12]' :
                          settings.theme === 'zellige' ? 'bg-[#006269]' : 
                          settings.theme === 'zellige-algiers' ? 'bg-[#1e3a8a]' :
                          settings.theme === 'zellige-tlemcen' ? 'bg-[#b45309]' :
                          settings.theme === 'zellige-sahara' ? 'bg-[#d97706]' :
                          settings.theme === 'lihab-al-oud' ? 'bg-[#451a03]' : 
                          settings.theme === 'zellige-v2' ? 'bg-[#024d38]' :
                          settings.theme === 'instagram' ? 'bg-white' :
                          'bg-gray-100 dark:bg-gray-700'}
                    `}>
                        <img 
                            src={currentUser.avatar} 
                            alt={currentUser.name} 
                            className="w-16 h-16 rounded-[1.2rem] object-cover border-2 border-white dark:border-gray-800" 
                        />
                    </div>
                    <span className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-500 border-4 border-white dark:border-gray-800 rounded-full shadow-sm animate-pulse"></span>
                </div>
            </div>
        )}

        {/* --- RIGHT SIDE: Page Title & Icon & BACK BUTTON --- */}
        <div className="flex items-center gap-4 relative z-10 pr-4 border-r border-black/5 dark:border-white/10 mr-4 h-12">
            
            {Icon && (
                <div className={`w-14 h-14 flex items-center justify-center rounded-2xl shadow-md transition-transform duration-500 hover:scale-110 hover:rotate-3 relative overflow-hidden ${iconBoxClass}`}>
                    {isZellige && (
                        <div className={`absolute inset-0 opacity-20 ${getZelligePatternClass()} mix-blend-multiply pointer-events-none`}></div>
                    )}
                    <Icon size={28} strokeWidth={2.5} className="relative z-10" />
                </div>
            )}

            <div className="flex flex-col justify-center">
                {isEditing ? (
                    <div className="flex items-center gap-2">
                        <input 
                            type="text" 
                            value={tempTitle} 
                            onChange={(e) => setTempTitle(e.target.value)}
                            className="bg-transparent border-b-2 border-current outline-none text-xl font-bold w-40"
                            autoFocus
                        />
                        <button onClick={handleSave} className="hover:text-green-600"><Check size={18}/></button>
                        <button onClick={() => setIsEditing(false)} className="hover:text-red-600"><X size={18}/></button>
                    </div>
                ) : (
                    <div className="flex items-center gap-2 group/edit">
                        <h1 className={`text-2xl font-black tracking-tight ${titleColor} opacity-90 ${settings.theme === 'zellige' ? 'font-serif tracking-wide' : ''}`}>
                            {currentTitle}
                        </h1>
                        {canEdit && (
                            <button 
                                onClick={handleEditClick} 
                                className="opacity-0 group-hover/edit:opacity-100 transition-opacity p-1 text-gray-400 hover:text-gray-600"
                            >
                                <Edit2 size={14} />
                            </button>
                        )}
                    </div>
                )}
                
                {/* Decorative Lines */}
                {(settings.theme.startsWith('zellige') || settings.theme === 'lihab-al-oud') && (
                    <div className="flex gap-1 mt-1">
                        <div className={`w-8 h-1.5 rounded-full ${
                            settings.theme === 'lihab-al-oud' ? 'bg-[#d97706]' : 
                            settings.theme === 'zellige' ? 'bg-[#cca43b]' : 
                            settings.theme === 'zellige-algiers' ? 'bg-[#1e3a8a]' :
                            settings.theme === 'zellige-tlemcen' ? 'bg-[#b45309]' :
                            settings.theme === 'zellige-sahara' ? 'bg-[#d97706]' :
                            'bg-[#024d38]'
                        }`}></div>
                        <div className={`w-2 h-1.5 rounded-full ${
                            settings.theme === 'lihab-al-oud' ? 'bg-[#451a03]' : 
                            settings.theme === 'zellige' ? 'bg-[#006269]' : 
                            settings.theme === 'zellige-algiers' ? 'bg-[#93c5fd]' :
                            settings.theme === 'zellige-tlemcen' ? 'bg-[#fcd34d]' :
                            settings.theme === 'zellige-sahara' ? 'bg-[#fdba74]' :
                            'bg-[#c6e3d8]'
                        }`}></div>
                    </div>
                )}
            </div>

            {/* Premium Back Button (Always visible if not dashboard, or has history) */}
            {pageKey !== 'dashboard' && (
                <button 
                    onClick={handleBack}
                    className={backBtnClass}
                    title="العودة للسابق"
                >
                    <CornerUpRight size={24} strokeWidth={3} className="relative z-10" />
                    {/* Hover Glow Effect */}
                    <div className="absolute inset-0 bg-white/20 translate-x-full group-hover/btn:translate-x-0 transition-transform duration-300"></div>
                </button>
            )}
        </div>
    </div>
  );
};
