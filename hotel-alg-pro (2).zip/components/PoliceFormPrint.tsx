import React from 'react';
import { GuestInfo } from '../types';

interface PoliceFormPrintProps {
    guest: GuestInfo;
    roomNumber?: string;
    checkInDate: string;
    hotelName: string;
}

export const PoliceFormPrint: React.FC<PoliceFormPrintProps> = ({ guest, roomNumber, checkInDate, hotelName }) => {
    return (
        <div className="bg-white p-8 text-black font-serif max-w-[210mm] mx-auto relative overflow-hidden" dir="rtl">
            {/* Header */}
            <div className="text-center mb-8 border-b-2 border-black pb-4">
                <h1 className="text-2xl font-bold mb-2">الجمهورية الجزائرية الديمقراطية الشعبية</h1>
                <h2 className="text-xl font-bold mb-4">RÉPUBLIQUE ALGÉRIENNE DÉMOCRATIQUE ET POPULAIRE</h2>
                <div className="flex justify-between items-end px-4">
                    <div className="text-right">
                        <p className="font-bold">ولاية: ........................</p>
                        <p className="font-bold">دائرة: ........................</p>
                    </div>
                    <div className="text-center border-2 border-black px-6 py-2 rounded">
                        <h3 className="text-xl font-black uppercase">بطاقة الشرطة</h3>
                        <h4 className="text-lg font-bold uppercase">FICHE DE POLICE</h4>
                    </div>
                    <div className="text-left">
                        <p className="font-bold">Wilaya: ........................</p>
                        <p className="font-bold">Daïra: ........................</p>
                    </div>
                </div>
            </div>

            {/* Hotel Info */}
            <div className="mb-6 flex justify-between items-center bg-gray-50 p-2 border border-gray-300">
                <p className="font-bold">فندق: {hotelName}</p>
                <p className="font-bold">غرفة رقم: {roomNumber || '___'}</p>
                <p className="font-bold">تاريخ الدخول: {new Date(checkInDate).toLocaleDateString('en-GB')}</p>
            </div>

            {/* Guest Info Grid */}
            <div className="grid grid-cols-2 gap-x-8 gap-y-6 text-sm border-2 border-black p-6">
                
                {/* Name */}
                <div className="col-span-2 grid grid-cols-2 gap-4 border-b border-gray-300 pb-4">
                    <div>
                        <label className="block font-bold mb-1">اللقب (Nom):</label>
                        <div className="font-mono text-lg uppercase">{guest.lastNameEn || guest.lastNameAr}</div>
                    </div>
                    <div>
                        <label className="block font-bold mb-1">الاسم (Prénom):</label>
                        <div className="font-mono text-lg capitalize">{guest.firstNameEn || guest.firstNameAr}</div>
                    </div>
                </div>

                {/* Parents */}
                <div className="grid grid-cols-2 gap-4 border-b border-gray-300 pb-4 col-span-2">
                    <div>
                        <label className="block font-bold mb-1">ابن (Fils de):</label>
                        <div>{guest.fatherName || '....................'}</div>
                    </div>
                    <div>
                        <label className="block font-bold mb-1">و (Et de):</label>
                        <div>{guest.motherName || '....................'}</div>
                    </div>
                </div>

                {/* Birth */}
                <div className="border-b border-gray-300 pb-4">
                    <label className="block font-bold mb-1">تاريخ الميلاد (Date de Naissance):</label>
                    <div className="font-mono text-lg">{guest.birthDate || '../../....'}</div>
                </div>
                <div className="border-b border-gray-300 pb-4">
                    <label className="block font-bold mb-1">مكان الميلاد (Lieu de Naissance):</label>
                    <div>{guest.birthPlace || '....................'}</div>
                </div>

                {/* Nationality & Profession */}
                <div className="border-b border-gray-300 pb-4">
                    <label className="block font-bold mb-1">الجنسية (Nationalité):</label>
                    <div>{guest.nationality || 'Jazairia'}</div>
                </div>
                <div className="border-b border-gray-300 pb-4">
                    <label className="block font-bold mb-1">المهنة (Profession):</label>
                    <div>....................</div>
                </div>

                {/* Address */}
                <div className="col-span-2 border-b border-gray-300 pb-4">
                    <label className="block font-bold mb-1">العنوان الدائم (Domicile Habituel):</label>
                    <div>................................................................................................</div>
                </div>

                {/* ID Document */}
                <div className="col-span-2 grid grid-cols-3 gap-4 border-b border-gray-300 pb-4">
                    <div>
                        <label className="block font-bold mb-1">نوع الوثيقة (Nature):</label>
                        <div>{guest.idType}</div>
                    </div>
                    <div>
                        <label className="block font-bold mb-1">رقمها (Numéro):</label>
                        <div className="font-mono font-bold">{guest.idNumber}</div>
                    </div>
                    <div>
                        <label className="block font-bold mb-1">تاريخ الإصدار (Délivré le):</label>
                        <div>../../....</div>
                    </div>
                </div>

                {/* Coming From / Going To */}
                <div className="border-b border-gray-300 pb-4">
                    <label className="block font-bold mb-1">قادم من (Venant de):</label>
                    <div>....................</div>
                </div>
                <div className="border-b border-gray-300 pb-4">
                    <label className="block font-bold mb-1">ذاهب إلى (Allant à):</label>
                    <div>....................</div>
                </div>
            </div>

            {/* Footer Signatures */}
            <div className="flex justify-between mt-12 px-8">
                <div className="text-center">
                    <p className="font-bold mb-12">توقيع النزيل<br/>Signature du Client</p>
                    <div className="w-32 border-b border-black"></div>
                </div>
                <div className="text-center">
                    <p className="font-bold mb-12">ختم وتوقيع الفندق<br/>Cachet et Signature</p>
                    <div className="w-32 border-b border-black"></div>
                </div>
            </div>

            <div className="mt-8 text-center text-[10px] text-gray-500">
                <p>يجب ملء هذه الاستمارة بدقة وعناية طبقا للقوانين المعمول بها.</p>
            </div>
        </div>
    );
};
