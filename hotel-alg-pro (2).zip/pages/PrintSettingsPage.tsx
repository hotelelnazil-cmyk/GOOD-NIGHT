
import React, { useState } from 'react';
import { useHotel } from '../context/HotelContext';
import { PageHeader } from '../components/PageHeader';
import { PrintButton } from '../components/PrintButton';
import { RegistrationCard } from '../components/RegistrationCard';
import { Printer, Check, Star, Briefcase, Ticket, Copy, Eye, FileText, FileCheck, Search, User, QrCode, FileBarChart, LayoutTemplate, Shield } from 'lucide-react';
import { PrintTemplateStyle, RegistrationTemplateStyle, Booking } from '../types';
import { QRCodeSVG } from 'qrcode.react';

// Mock Card Component for Tickets/Events
const CardPreview = ({ style, type, title, subtitle }: { style: PrintTemplateStyle, type: string, title: string, subtitle: string }) => {
    let containerClass = "border p-4 rounded-xl shadow-md h-40 flex flex-col justify-between relative overflow-hidden transition-all duration-300";
    
    if (style === 'royal_andalus') {
        containerClass += " bg-[#fdfbf7] border-[#cca43b] text-[#006269]";
    } else if (style === 'modern_corporate') {
        containerClass += " bg-white border-blue-200 text-slate-800";
    } else if (style === 'vibrant_party') {
        containerClass += " bg-gradient-to-r from-purple-600 to-pink-600 text-white border-none";
    } else {
        containerClass += " bg-gray-50 border-gray-300 text-gray-700 font-mono";
    }

    return (
        <div className={containerClass}>
            {style === 'royal_andalus' && <div className="absolute inset-0 bg-zellige-pattern opacity-10 pointer-events-none mix-blend-multiply"></div>}
            
            <div className="relative z-10">
                <div className="flex justify-between items-center mb-2">
                    <span className="text-[10px] uppercase font-bold tracking-widest opacity-70">{type}</span>
                    <div className={`w-2 h-2 rounded-full ${style === 'vibrant_party' ? 'bg-white' : 'bg-current'}`}></div>
                </div>
                <h3 className={`font-bold text-lg leading-tight ${style === 'royal_andalus' ? 'font-serif' : ''}`}>{title}</h3>
                <p className="text-xs opacity-80 mt-1">{subtitle}</p>
            </div>
            
            <div className={`relative z-10 flex justify-between items-end border-t pt-2 ${style === 'royal_andalus' ? 'border-[#cca43b]/30' : 'border-current/20'}`}>
                <div className="w-8 h-8 bg-current opacity-20 rounded-md"></div>
                <span className="text-[9px] font-bold">AUTHENTIC ZELLIJ</span>
            </div>
        </div>
    );
};

// Mock Document Component for Registration Forms
const FormPreview = ({ style }: { style: RegistrationTemplateStyle }) => {
    let containerClass = "border rounded-xl shadow-sm h-56 flex flex-col relative overflow-hidden transition-all duration-300 bg-white p-3";
    let headerClass = "flex justify-between items-center mb-2 pb-2 border-b";
    let bodyClass = "flex-1 space-y-2";
    
    // Theme logic for the preview
    if (style === 'classic_reg') {
        containerClass += " border-[#cca43b] bg-[#fffbf0]";
        headerClass += " border-[#cca43b]/30";
    } else if (style === 'modern_reg') {
        containerClass += " border-gray-200";
        headerClass = "mb-3 pb-0";
    } else if (style === 'vip_reg') {
        containerClass += " border-gray-800 bg-[#1a1a1a] text-yellow-500";
        headerClass += " border-yellow-500/30";
    } else if (style === 'legal_reg') {
        containerClass += " border-gray-300 font-serif text-[8px]";
    } else if (style === 'express_reg') {
        containerClass += " border-blue-200 bg-blue-50";
    }

    return (
        <div className={containerClass}>
            {/* Background Pattern for specific styles */}
            {style === 'classic_reg' && <div className="absolute inset-0 bg-zellige-pattern opacity-5 pointer-events-none mix-blend-multiply"></div>}
            {style === 'vip_reg' && <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-bl from-yellow-500/20 to-transparent rounded-bl-full pointer-events-none"></div>}

            {/* Header */}
            <div className={`${headerClass} relative z-10`}>
                <div className="flex items-center gap-2">
                    <div className={`w-6 h-6 rounded ${style === 'vip_reg' ? 'bg-yellow-500' : style === 'modern_reg' ? 'bg-black' : 'bg-gray-200'}`}></div>
                    <span className={`text-[10px] font-bold ${style === 'modern_reg' ? 'uppercase tracking-widest' : ''}`}>
                        HOTEL REGISTRATION
                    </span>
                </div>
                {style === 'security_reg' && <div className="w-8 h-8 border border-dashed border-gray-400 rounded flex items-center justify-center text-[6px]">PHOTO</div>}
            </div>

            {/* Body simulation */}
            <div className={`${bodyClass} relative z-10`}>
                {/* Rows */}
                <div className="flex gap-2">
                    <div className={`h-2 w-1/2 rounded ${style === 'vip_reg' ? 'bg-yellow-500/20' : 'bg-gray-100'}`}></div>
                    <div className={`h-2 w-1/2 rounded ${style === 'vip_reg' ? 'bg-yellow-500/20' : 'bg-gray-100'}`}></div>
                </div>
                <div className={`h-2 w-full rounded ${style === 'vip_reg' ? 'bg-yellow-500/20' : 'bg-gray-100'}`}></div>
                <div className="flex gap-2">
                    <div className={`h-2 w-1/3 rounded ${style === 'vip_reg' ? 'bg-yellow-500/20' : 'bg-gray-100'}`}></div>
                    <div className={`h-2 w-2/3 rounded ${style === 'vip_reg' ? 'bg-yellow-500/20' : 'bg-gray-100'}`}></div>
                </div>
                
                {/* Legal Text / Footer simulation */}
                {style === 'legal_reg' && (
                    <div className="space-y-1 mt-2">
                        <div className="h-1 w-full bg-gray-200 rounded-full"></div>
                        <div className="h-1 w-full bg-gray-200 rounded-full"></div>
                        <div className="h-1 w-3/4 bg-gray-200 rounded-full"></div>
                    </div>
                )}

                {style === 'family_reg' && (
                    <div className="mt-2 border p-1 rounded bg-white/50">
                        <div className="h-1 w-1/2 bg-gray-200 mb-1"></div>
                        <div className="h-1 w-1/2 bg-gray-200 mb-1"></div>
                        <div className="h-1 w-1/2 bg-gray-200"></div>
                    </div>
                )}
            </div>

            {/* Signature Area */}
            <div className="mt-auto relative z-10 pt-2">
                <div className={`h-px w-1/2 ml-auto ${style === 'vip_reg' ? 'bg-yellow-500/50' : 'bg-black/20'}`}></div>
                <p className="text-[6px] text-right mt-0.5 opacity-60">Guest Signature</p>
            </div>
        </div>
    );
};

export const PrintSettingsPage: React.FC = () => {
    const { settings, updateSettings, currentUser, bookings, rooms, addNotification } = useHotel();
    const [config, setConfig] = useState(settings.printConfig);
    const [searchTerm, setSearchTerm] = useState('');
    const [activeTab, setActiveTab] = useState<'registration' | 'tickets' | 'qr' | 'reports' | 'official_forms' | 'other_docs'>('registration');

    const canManageTickets = ['manager', 'assistant_manager', 'reception_manager', 'receptionist'].includes(currentUser?.role || '');

    const handleSave = () => {
        updateSettings({ printConfig: config });
        addNotification('تم حفظ إعدادات الطباعة بنجاح', "success");
    };

    const templates: { id: PrintTemplateStyle, label: string }[] = [
        { id: 'royal_andalus', label: 'الملكي الأندلسي' },
        { id: 'modern_corporate', label: 'الرسمي الحديث' },
        { id: 'vibrant_party', label: 'الحفلات العصرية' },
        { id: 'classic_ticket', label: 'تذكرة كلاسيكية' },
    ];

    const formTemplates: { id: RegistrationTemplateStyle, label: string, desc: string }[] = [
        { id: 'classic_reg', label: 'الكلاسيكي الرسمي', desc: 'تصميم تقليدي بإطار وزخارف' },
        { id: 'modern_reg', label: 'المودرن الحديث', desc: 'نظيف، بسيط، وواضح' },
        { id: 'vip_reg', label: 'الذهبي VIP', desc: 'للنزلاء المميزين بلمسة فخامة' },
        { id: 'legal_reg', label: 'القانوني المفصل', desc: 'يحتوي على كافة البنود والشروط' },
        { id: 'express_reg', label: 'السريع (Express)', desc: 'مختصر لسرعة الدخول' },
        { id: 'security_reg', label: 'الأمني (Security)', desc: 'يركز على الهوية والبصمة' },
        { id: 'family_reg', label: 'العائلي المجمع', desc: 'يتسع لأسماء مرافقين متعددين' },
    ];

    const getThemeStyles = () => {
        switch (settings.theme) {
            case 'zellige': return {
                card: 'bg-[#FDFBF7] border border-[#cca43b]/40',
                header: 'text-[#006269]',
                activeBtn: 'bg-[#006269] text-[#cca43b] border-[#cca43b]',
                btn: 'bg-[#006269] text-[#cca43b] hover:bg-[#004d53]',
                input: 'border-[#cca43b]/40 focus:border-[#006269] bg-[#fbf8f1] text-[#006269]',
                tabActive: 'bg-[#006269] text-[#cca43b]',
                tabInactive: 'text-[#006269] hover:bg-[#006269]/10'
            };
            default: return {
                card: 'bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700',
                header: 'text-gray-900 dark:text-white',
                activeBtn: 'bg-blue-600 text-white',
                btn: 'bg-blue-600 text-white hover:bg-blue-700',
                input: 'border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white',
                tabActive: 'bg-blue-600 text-white',
                tabInactive: 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700'
            };
        }
    };
    const ts = getThemeStyles();

    const filteredBookings = bookings.filter(b => 
        b.status === 'active' && 
        b.guests.some(g => 
            g.firstNameEn.toLowerCase().includes(searchTerm.toLowerCase()) || 
            g.lastNameEn.toLowerCase().includes(searchTerm.toLowerCase()) ||
            g.firstNameAr.includes(searchTerm) ||
            g.lastNameAr.includes(searchTerm)
        )
    );

    return (
        <div className="space-y-8 pb-32 animate-fade-in">
            <PageHeader pageKey="print_settings" defaultTitle="مركز الطباعة الشامل" icon={Printer} />

            {/* Tabs */}
            <div className="flex flex-wrap gap-2 p-1 bg-gray-100 dark:bg-gray-800 rounded-2xl w-fit mx-auto">
                {[
                    { id: 'registration', label: 'استمارات التسجيل', icon: FileCheck },
                    { id: 'official_forms', label: 'الوثائق الرسمية', icon: Shield },
                    { id: 'tickets', label: 'التذاكر والبطاقات', icon: Ticket, hidden: !canManageTickets },
                    { id: 'qr', label: 'رموز الاستجابة (QR)', icon: QrCode },
                    { id: 'reports', label: 'التقارير والبيانات', icon: FileBarChart },
                    { id: 'other_docs', label: 'نماذج أخرى', icon: Copy },
                ].filter(t => !t.hidden).map(tab => (
                    <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id as any)}
                        className={`px-6 py-3 rounded-xl font-bold flex items-center gap-2 transition-all ${activeTab === tab.id ? ts.tabActive : ts.tabInactive}`}
                    >
                        <tab.icon size={18}/> {tab.label}
                    </button>
                ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                
                {/* --- TAB: REGISTRATION --- */}
                {activeTab === 'registration' && (
                    <>
                        <div className={`p-6 rounded-[2.5rem] shadow-sm lg:col-span-3 ${ts.card}`}>
                            <h3 className={`text-xl font-black mb-2 flex items-center gap-2 ${ts.header}`}>
                                <FileCheck size={24} className="text-green-600"/> نماذج استمارات التسجيل
                            </h3>
                            <p className="text-sm text-gray-500 mb-6">اختر التصميم المعتمد لاستمارات تسجيل النزلاء.</p>
                            
                            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                                {formTemplates.map(t => (
                                    <button
                                        key={t.id}
                                        onClick={() => setConfig({...config, defaultRegistrationTemplate: t.id})}
                                        className={`p-4 rounded-2xl border-2 transition-all flex flex-col gap-3 text-right group ${config.defaultRegistrationTemplate === t.id ? ts.activeBtn : 'border-transparent bg-gray-50 dark:bg-gray-700 hover:bg-gray-100'}`}
                                    >
                                        <div className="flex justify-between w-full items-center">
                                            <span className="text-xs font-bold">{t.label}</span>
                                            {config.defaultRegistrationTemplate === t.id && <Check size={16} className="shrink-0"/>}
                                        </div>
                                        <div className="w-full opacity-100 pointer-events-none transform group-hover:scale-[1.02] transition-transform duration-500">
                                            <FormPreview style={t.id} />
                                        </div>
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div className={`p-6 rounded-[2.5rem] shadow-sm lg:col-span-3 ${ts.card}`}>
                            <h3 className={`text-xl font-black mb-4 flex items-center gap-2 ${ts.header}`}>
                                <Printer size={24} className="text-blue-600"/> طباعة فورية للنزلاء
                            </h3>
                            
                            <div className="relative mb-6">
                                <input 
                                    type="text" 
                                    placeholder="بحث باسم النزيل..." 
                                    className={`w-full p-4 pr-12 rounded-2xl border-2 outline-none font-bold ${ts.input}`}
                                    value={searchTerm}
                                    onChange={e => setSearchTerm(e.target.value)}
                                />
                                <Search size={20} className="absolute right-4 top-1/2 -translate-y-1/2 opacity-50"/>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                {filteredBookings.length > 0 ? filteredBookings.map(booking => (
                                    booking.guests.map((guest, idx) => (
                                        <div key={`${booking.id}-${idx}`} className="flex justify-between items-center p-4 bg-gray-50 dark:bg-gray-700/50 rounded-2xl border border-gray-100 dark:border-gray-600">
                                            <div className="flex items-center gap-3 overflow-hidden">
                                                <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-600 dark:text-blue-400 font-bold">
                                                    {guest.firstNameAr.charAt(0)}
                                                </div>
                                                <div>
                                                    <p className="font-bold text-sm truncate text-gray-900 dark:text-white">{guest.firstNameAr} {guest.lastNameAr}</p>
                                                    <p className="text-xs text-gray-500 dark:text-gray-400">غرفة {rooms.find(r => r.id === booking.roomId)?.number}</p>
                                                </div>
                                            </div>
                                            <PrintButton 
                                                label="طباعة الاستمارة"
                                                className={`px-4 py-2 rounded-xl text-xs font-bold shadow-sm ${ts.btn}`}
                                                content={
                                                    <RegistrationCard 
                                                        guest={guest}
                                                        roomNumber={rooms.find(r => r.id === booking.roomId)?.number}
                                                        checkInDate={booking.checkInDate}
                                                        appName={settings.appName}
                                                        variant={config.defaultRegistrationTemplate === 'classic_reg' ? 'classic' : config.defaultRegistrationTemplate === 'express_reg' ? 'minimal' : 'modern'}
                                                    />
                                                }
                                            />
                                        </div>
                                    ))
                                )) : (
                                    <div className="col-span-full text-center py-10 opacity-50">
                                        <User size={48} className="mx-auto mb-2"/>
                                        <p>لا توجد نتائج مطابقة</p>
                                    </div>
                                )}
                            </div>
                        </div>
                    </>
                )}

                {/* --- TAB: TICKETS --- */}
                {activeTab === 'tickets' && (
                    <>
                        <div className={`p-6 rounded-[2.5rem] shadow-sm lg:col-span-3 ${ts.card}`}>
                            <h3 className={`text-xl font-black mb-6 flex items-center gap-2 ${ts.header}`}>
                                <LayoutTemplate size={24} className="text-purple-500"/> قوالب التذاكر والبطاقات
                            </h3>
                            
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <div className="space-y-4">
                                    <label className="block text-xs font-bold opacity-70">بطاقات الأفراح</label>
                                    <div className="grid grid-cols-1 gap-3">
                                        {templates.slice(0, 2).map(t => (
                                            <button
                                                key={t.id}
                                                onClick={() => setConfig({...config, defaultWeddingTemplate: t.id})}
                                                className={`p-3 rounded-xl border-2 transition-all flex items-center gap-3 text-right ${config.defaultWeddingTemplate === t.id ? ts.activeBtn : 'border-transparent bg-gray-50 dark:bg-gray-700 hover:bg-gray-100'}`}
                                            >
                                                {config.defaultWeddingTemplate === t.id && <Check size={16} className="shrink-0"/>}
                                                <span className="text-xs font-bold">{t.label}</span>
                                            </button>
                                        ))}
                                    </div>
                                </div>
                                <div className="space-y-4">
                                    <label className="block text-xs font-bold opacity-70">بطاقات المؤتمرات</label>
                                    <div className="grid grid-cols-1 gap-3">
                                        {templates.slice(1, 3).map(t => (
                                            <button
                                                key={t.id}
                                                onClick={() => setConfig({...config, defaultMeetingTemplate: t.id})}
                                                className={`p-3 rounded-xl border-2 transition-all flex items-center gap-3 text-right ${config.defaultMeetingTemplate === t.id ? ts.activeBtn : 'border-transparent bg-gray-50 dark:bg-gray-700 hover:bg-gray-100'}`}
                                            >
                                                {config.defaultMeetingTemplate === t.id && <Check size={16} className="shrink-0"/>}
                                                <span className="text-xs font-bold">{t.label}</span>
                                            </button>
                                        ))}
                                    </div>
                                </div>
                                <div className="space-y-4">
                                    <label className="block text-xs font-bold opacity-70">تذاكر الدخول</label>
                                    <div className="grid grid-cols-1 gap-3">
                                        {templates.map(t => (
                                            <button
                                                key={t.id}
                                                onClick={() => setConfig({...config, defaultTicketTemplate: t.id})}
                                                className={`p-3 rounded-xl border-2 transition-all flex items-center gap-3 text-right ${config.defaultTicketTemplate === t.id ? ts.activeBtn : 'border-transparent bg-gray-50 dark:bg-gray-700 hover:bg-gray-100'}`}
                                            >
                                                {config.defaultTicketTemplate === t.id && <Check size={16} className="shrink-0"/>}
                                                <span className="text-xs font-bold">{t.label}</span>
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className={`p-6 rounded-[2.5rem] shadow-sm lg:col-span-3 ${ts.card}`}>
                            <h3 className={`text-xl font-black mb-6 flex items-center gap-2 ${ts.header}`}>
                                <Ticket size={24} className="text-red-500"/> إصدار تذاكر فورية
                            </h3>
                            <div className="flex flex-col md:flex-row gap-8 items-start">
                                <div className="flex-1 w-full space-y-4">
                                    <div>
                                        <label className="block text-xs font-bold opacity-70 mb-2">عنوان التذكرة / الفعالية</label>
                                        <input type="text" className={`w-full p-4 rounded-2xl border-2 outline-none font-bold ${ts.input}`} placeholder="مثال: حفل عشاء فاخر" />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-bold opacity-70 mb-2">النص السفلي</label>
                                        <input 
                                            type="text" 
                                            className={`w-full p-4 rounded-2xl border-2 outline-none font-bold ${ts.input}`}
                                            value={config.customFooterText}
                                            onChange={e => setConfig({...config, customFooterText: e.target.value})}
                                        />
                                    </div>
                                    <label className="flex items-center gap-3 p-4 rounded-2xl bg-gray-50 dark:bg-gray-900 cursor-pointer">
                                        <input 
                                            type="checkbox" 
                                            checked={config.showQrCode}
                                            onChange={e => setConfig({...config, showQrCode: e.target.checked})}
                                            className="w-5 h-5 rounded"
                                        />
                                        <span className="font-bold text-sm text-gray-900 dark:text-white">تضمين QR Code للتحقق الأمني</span>
                                    </label>
                                    <PrintButton 
                                        label="طباعة نموذج تجريبي"
                                        className={`w-full py-4 rounded-xl font-black shadow-lg flex items-center justify-center gap-2 ${ts.btn}`}
                                        content={
                                            <div className="p-8 bg-white text-center border-4 border-double border-gray-800 m-4 relative">
                                                <h1 className="text-4xl font-black mb-4">تذكرة دخول</h1>
                                                <p className="text-xl mb-8">نموذج تجريبي للطباعة</p>
                                                
                                                {config.showQrCode && (
                                                    <div className="my-6 flex justify-center p-4 border-2 border-dashed border-gray-200 inline-block rounded-xl">
                                                        <QRCodeSVG value={`TICKET:${Date.now()}|${config.customFooterText}`} size={150} />
                                                    </div>
                                                )}

                                                <div className="border-t-2 border-dashed border-gray-300 my-8"></div>
                                                <p className="font-mono text-sm">{config.customFooterText}</p>
                                                <p className="text-[10px] text-gray-400 mt-4">{new Date().toLocaleString()}</p>
                                            </div>
                                        }
                                    />
                                </div>
                                <div className="flex-1 w-full">
                                    <label className="block text-xs font-bold opacity-70 mb-2">معاينة حية</label>
                                    <CardPreview style={config.defaultTicketTemplate} type="ENTRY TICKET" title="حفل عشاء فاخر" subtitle={`001 | ${config.customFooterText}`} />
                                </div>
                            </div>
                        </div>
                    </>
                )}

                {/* --- TAB: OFFICIAL FORMS (Police) --- */}
                {activeTab === 'official_forms' && (
                    <div className={`p-6 rounded-[2.5rem] shadow-sm lg:col-span-3 ${ts.card}`}>
                        <h3 className={`text-xl font-black mb-6 flex items-center gap-2 ${ts.header}`}>
                            <Shield size={24} className="text-blue-800"/> استمارة الشرطة (Police Form)
                        </h3>
                        <p className="text-sm text-gray-500 mb-6">طباعة الاستمارة الأمنية الرسمية للنزلاء الأجانب والمحليين.</p>

                        <div className="relative mb-6">
                            <input 
                                type="text" 
                                placeholder="بحث باسم النزيل..." 
                                className={`w-full p-4 pr-12 rounded-2xl border-2 outline-none font-bold ${ts.input}`}
                                value={searchTerm}
                                onChange={e => setSearchTerm(e.target.value)}
                            />
                            <Search size={20} className="absolute right-4 top-1/2 -translate-y-1/2 opacity-50"/>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {filteredBookings.length > 0 ? filteredBookings.map(booking => (
                                booking.guests.map((guest, idx) => (
                                    <div key={`police-${booking.id}-${idx}`} className="flex justify-between items-center p-4 bg-gray-50 dark:bg-gray-700/50 rounded-2xl border border-gray-100 dark:border-gray-600">
                                        <div className="flex items-center gap-3 overflow-hidden">
                                            <div className="w-10 h-10 rounded-full bg-blue-800 text-white flex items-center justify-center font-bold">
                                                <Shield size={16}/>
                                            </div>
                                            <div>
                                                <p className="font-bold text-sm truncate text-gray-900 dark:text-white">{guest.firstNameAr} {guest.lastNameAr}</p>
                                                <p className="text-xs text-gray-500 dark:text-gray-400">{guest.nationality}</p>
                                            </div>
                                        </div>
                                        <PrintButton 
                                            label="طباعة"
                                            className={`px-4 py-2 rounded-xl text-xs font-bold shadow-sm ${ts.btn}`}
                                            content={
                                                <div className="p-8 bg-white font-serif text-black max-w-A4 mx-auto border-2 border-black m-4" dir="rtl">
                                                    <div className="text-center border-b-2 border-black pb-4 mb-6">
                                                        <h2 className="text-xl font-bold mb-1">الجمهورية الجزائرية الديمقراطية الشعبية</h2>
                                                        <h3 className="text-lg font-bold mb-2">وزارة الداخلية والجماعات المحلية</h3>
                                                        <h1 className="text-2xl font-black uppercase border-2 border-black inline-block px-6 py-2 rounded-lg mt-2">استمارة الفندق / FICHE DE POLICE</h1>
                                                    </div>
                                                    
                                                    <div className="grid grid-cols-2 gap-6 text-right mb-6">
                                                        <div className="space-y-4">
                                                            <div className="border-b border-dotted border-black pb-1">
                                                                <span className="font-bold ml-2">اللقب / Nom:</span> {guest.lastNameEn} / {guest.lastNameAr}
                                                            </div>
                                                            <div className="border-b border-dotted border-black pb-1">
                                                                <span className="font-bold ml-2">الاسم / Prénom:</span> {guest.firstNameEn} / {guest.firstNameAr}
                                                            </div>
                                                            <div className="border-b border-dotted border-black pb-1">
                                                                <span className="font-bold ml-2">تاريخ الميلاد / Date de Naissance:</span> {guest.dateOfBirth || '....................'}
                                                            </div>
                                                            <div className="border-b border-dotted border-black pb-1">
                                                                <span className="font-bold ml-2">الجنسية / Nationalité:</span> {guest.nationality}
                                                            </div>
                                                        </div>
                                                        <div className="space-y-4">
                                                            <div className="border-b border-dotted border-black pb-1">
                                                                <span className="font-bold ml-2">رقم الغرفة / N° Chambre:</span> {rooms.find(r => r.id === booking.roomId)?.number}
                                                            </div>
                                                            <div className="border-b border-dotted border-black pb-1">
                                                                <span className="font-bold ml-2">تاريخ الدخول / Date d'Arrivée:</span> {booking.checkInDate}
                                                            </div>
                                                            <div className="border-b border-dotted border-black pb-1">
                                                                <span className="font-bold ml-2">رقم الوثيقة / N° Pièce d'Identité:</span> {guest.identificationNumber || '....................'}
                                                            </div>
                                                            <div className="border-b border-dotted border-black pb-1">
                                                                <span className="font-bold ml-2">قادم من / Venant de:</span> ....................................
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div className="border-2 border-black p-4 mb-6 rounded-lg">
                                                        <h4 className="font-bold border-b border-black w-fit mb-2">للأجانب فقط / Pour les Étrangers</h4>
                                                        <div className="grid grid-cols-2 gap-4">
                                                            <div><span className="font-bold">رقم التأشيرة / N° Visa:</span> ....................</div>
                                                            <div><span className="font-bold">تاريخ انتهاء الصلاحية / Validité:</span> ....................</div>
                                                        </div>
                                                    </div>

                                                    <div className="flex justify-between items-end mt-12 px-8">
                                                        <div className="text-center">
                                                            <p className="font-bold mb-4">توقيع النزيل</p>
                                                            <p className="font-bold">Signature du Client</p>
                                                        </div>
                                                        <div className="text-center">
                                                            <p className="font-bold mb-4">ختم المؤسسة</p>
                                                            <p className="font-bold">Cachet de l'Établissement</p>
                                                            <div className="w-24 h-24 border-2 border-dashed border-gray-300 rounded-full mt-2 mx-auto"></div>
                                                        </div>
                                                    </div>
                                                    
                                                    <div className="text-center text-[10px] mt-8 pt-4 border-t border-gray-300">
                                                        {settings.appName} - {settings.hotelAddress}
                                                    </div>
                                                </div>
                                            }
                                        />
                                    </div>
                                ))
                            )) : (
                                <div className="col-span-full text-center py-10 opacity-50">
                                    <User size={48} className="mx-auto mb-2"/>
                                    <p>لا توجد نتائج مطابقة</p>
                                </div>
                            )}
                        </div>
                    </div>
                )}

                {/* --- TAB: OTHER DOCS (5 New Templates) --- */}
                {activeTab === 'other_docs' && (
                    <div className={`p-6 rounded-[2.5rem] shadow-sm lg:col-span-3 ${ts.card}`}>
                        <h3 className={`text-xl font-black mb-6 flex items-center gap-2 ${ts.header}`}>
                            <Copy size={24} className="text-purple-600"/> نماذج وثائق متنوعة
                        </h3>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            
                            {/* 1. Welcome Letter */}
                            <div className="p-6 rounded-3xl bg-gray-50 dark:bg-gray-700/30 border border-gray-200 dark:border-gray-600">
                                <h4 className="font-bold text-lg mb-2 text-gray-900 dark:text-white">رسالة ترحيب (Welcome Letter)</h4>
                                <p className="text-xs text-gray-500 mb-4">رسالة ترحيبية شخصية للنزلاء VIP توضع في الغرفة.</p>
                                <PrintButton 
                                    label="طباعة نموذج"
                                    className={`w-full py-3 rounded-xl font-bold ${ts.btn}`}
                                    content={
                                        <div className="p-12 bg-white m-4 font-serif text-black max-w-2xl mx-auto border shadow-lg relative overflow-hidden">
                                            <div className="absolute top-0 left-0 w-full h-2 bg-[#cca43b]"></div>
                                            <div className="text-center mb-10">
                                                <h1 className="text-3xl font-bold text-[#006269] mb-2">{settings.appName}</h1>
                                                <div className="w-16 h-1 bg-[#cca43b] mx-auto"></div>
                                            </div>
                                            <div className="space-y-6 text-lg leading-relaxed">
                                                <p><strong>Dear Guest,</strong></p>
                                                <p>It is with great pleasure that we welcome you to <strong>{settings.appName}</strong>.</p>
                                                <p>We are honored that you have chosen to stay with us. Our team is dedicated to ensuring your stay is comfortable, relaxing, and memorable. Should you require any assistance, please do not hesitate to contact the Front Desk.</p>
                                                <p>We wish you a wonderful stay.</p>
                                            </div>
                                            <div className="mt-12 pt-6 border-t border-gray-200 flex justify-between items-center">
                                                <div>
                                                    <p className="font-bold text-[#006269]">General Manager</p>
                                                    <p className="font-script text-2xl mt-2">{settings.hotelIdentity.managerName}</p>
                                                </div>
                                                <div className="text-right text-sm text-gray-500">
                                                    <p>{new Date().toLocaleDateString()}</p>
                                                    <p>Room: 101 (VIP)</p>
                                                </div>
                                            </div>
                                        </div>
                                    }
                                />
                            </div>

                            {/* 2. Luggage Tag */}
                            <div className="p-6 rounded-3xl bg-gray-50 dark:bg-gray-700/30 border border-gray-200 dark:border-gray-600">
                                <h4 className="font-bold text-lg mb-2 text-gray-900 dark:text-white">بطاقة أمتعة (Luggage Tag)</h4>
                                <p className="text-xs text-gray-500 mb-4">بطاقة تعريفية لتعليقها على حقائب النزلاء.</p>
                                <PrintButton 
                                    label="طباعة نموذج"
                                    className={`w-full py-3 rounded-xl font-bold ${ts.btn}`}
                                    content={
                                        <div className="p-8 bg-white m-4 flex justify-center">
                                            <div className="border-4 border-black w-64 h-96 relative p-4 flex flex-col justify-between rounded-xl">
                                                <div className="w-4 h-4 bg-black rounded-full mx-auto mb-2 border-2 border-white ring-2 ring-black"></div>
                                                <div className="text-center border-b-2 border-black pb-2">
                                                    <h2 className="font-black text-xl uppercase">{settings.appName}</h2>
                                                    <p className="text-xs font-bold">LUGGAGE TAG</p>
                                                </div>
                                                <div className="space-y-4 flex-1 py-4">
                                                    <div>
                                                        <p className="text-[10px] font-bold uppercase text-gray-500">GUEST NAME</p>
                                                        <p className="font-bold text-lg border-b border-black">Mr. John Doe</p>
                                                    </div>
                                                    <div>
                                                        <p className="text-[10px] font-bold uppercase text-gray-500">ROOM NO</p>
                                                        <p className="font-black text-4xl">205</p>
                                                    </div>
                                                    <div className="flex gap-2">
                                                        <div className="flex-1">
                                                            <p className="text-[10px] font-bold uppercase text-gray-500">DATE</p>
                                                            <p className="font-bold">{new Date().toLocaleDateString()}</p>
                                                        </div>
                                                        <div className="flex-1">
                                                            <p className="text-[10px] font-bold uppercase text-gray-500">PIECES</p>
                                                            <p className="font-bold">02</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="text-center pt-2 border-t-2 border-black">
                                                    <QRCodeSVG value="LUGGAGE:205:JD" size={60} className="mx-auto"/>
                                                </div>
                                            </div>
                                        </div>
                                    }
                                />
                            </div>

                            {/* 3. Kitchen Order Ticket (KOT) */}
                            <div className="p-6 rounded-3xl bg-gray-50 dark:bg-gray-700/30 border border-gray-200 dark:border-gray-600">
                                <h4 className="font-bold text-lg mb-2 text-gray-900 dark:text-white">تذكرة مطبخ (KOT)</h4>
                                <p className="text-xs text-gray-500 mb-4">نموذج طلب الطعام للمطبخ (Kitchen Order Ticket).</p>
                                <PrintButton 
                                    label="طباعة نموذج"
                                    className={`w-full py-3 rounded-xl font-bold ${ts.btn}`}
                                    content={
                                        <div className="p-4 bg-white m-4 w-64 mx-auto font-mono text-sm border border-gray-300 shadow-sm">
                                            <div className="text-center border-b border-dashed border-black pb-2 mb-2">
                                                <h2 className="font-bold text-lg">KITCHEN ORDER</h2>
                                                <p>KOT #8821</p>
                                                <p>{new Date().toLocaleString()}</p>
                                            </div>
                                            <div className="flex justify-between font-bold mb-2">
                                                <span>TABLE: T-05</span>
                                                <span>WAITER: Ahmed</span>
                                            </div>
                                            <div className="border-b border-black mb-2"></div>
                                            <div className="space-y-2 mb-4">
                                                <div className="flex justify-between">
                                                    <span>2 x Grilled Steak</span>
                                                    <span>(Med-Rare)</span>
                                                </div>
                                                <div className="flex justify-between">
                                                    <span>1 x Caesar Salad</span>
                                                    <span>(No Sauce)</span>
                                                </div>
                                                <div className="flex justify-between">
                                                    <span>3 x Coke Zero</span>
                                                </div>
                                            </div>
                                            <div className="border-t border-black pt-2 mt-2">
                                                <p className="font-bold">NOTES:</p>
                                                <p className="border border-black p-1 mt-1">Guest has nut allergy.</p>
                                            </div>
                                        </div>
                                    }
                                />
                            </div>

                            {/* 4. Invoice / Facture */}
                            <div className="p-6 rounded-3xl bg-gray-50 dark:bg-gray-700/30 border border-gray-200 dark:border-gray-600">
                                <h4 className="font-bold text-lg mb-2 text-gray-900 dark:text-white">فاتورة رسمية (Invoice)</h4>
                                <p className="text-xs text-gray-500 mb-4">نموذج فاتورة تفصيلية للخدمات والإقامة.</p>
                                <PrintButton 
                                    label="طباعة نموذج"
                                    className={`w-full py-3 rounded-xl font-bold ${ts.btn}`}
                                    content={
                                        <div className="p-8 bg-white m-4 font-sans text-black" dir="rtl">
                                            <div className="flex justify-between items-start mb-8">
                                                <div>
                                                    <h1 className="text-2xl font-black mb-1">{settings.appName}</h1>
                                                    <p className="text-sm text-gray-600">{settings.hotelAddress}</p>
                                                    <p className="text-sm text-gray-600">{settings.hotelPhone}</p>
                                                </div>
                                                <div className="text-left">
                                                    <h2 className="text-3xl font-bold text-gray-200 uppercase">INVOICE</h2>
                                                    <p className="font-bold">رقم الفاتورة: #INV-2024-001</p>
                                                    <p>التاريخ: {new Date().toLocaleDateString()}</p>
                                                </div>
                                            </div>
                                            
                                            <div className="mb-8 border-t border-b py-4">
                                                <div className="flex justify-between">
                                                    <div>
                                                        <p className="text-xs font-bold text-gray-500 uppercase">فاتورة إلى</p>
                                                        <p className="font-bold text-lg">السيد محمد عبد الله</p>
                                                        <p>غرفة رقم: 302</p>
                                                    </div>
                                                    <div className="text-left">
                                                        <p className="text-xs font-bold text-gray-500 uppercase">طريقة الدفع</p>
                                                        <p className="font-bold">نقداً / Cash</p>
                                                    </div>
                                                </div>
                                            </div>

                                            <table className="w-full mb-8 text-right">
                                                <thead>
                                                    <tr className="border-b-2 border-black">
                                                        <th className="py-2">البيان</th>
                                                        <th className="py-2">الكمية</th>
                                                        <th className="py-2">السعر</th>
                                                        <th className="py-2">المجموع</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr className="border-b">
                                                        <td className="py-3">إقامة غرفة مزدوجة (3 ليالي)</td>
                                                        <td className="py-3">3</td>
                                                        <td className="py-3">5,000 د.ج</td>
                                                        <td className="py-3">15,000 د.ج</td>
                                                    </tr>
                                                    <tr className="border-b">
                                                        <td className="py-3">خدمة غرف (عشاء)</td>
                                                        <td className="py-3">1</td>
                                                        <td className="py-3">2,500 د.ج</td>
                                                        <td className="py-3">2,500 د.ج</td>
                                                    </tr>
                                                    <tr className="border-b">
                                                        <td className="py-3">مصبغة (غسيل وكوي)</td>
                                                        <td className="py-3">4</td>
                                                        <td className="py-3">200 د.ج</td>
                                                        <td className="py-3">800 د.ج</td>
                                                    </tr>
                                                </tbody>
                                            </table>

                                            <div className="flex justify-end mb-12">
                                                <div className="w-64">
                                                    <div className="flex justify-between py-1">
                                                        <span>المجموع الفرعي:</span>
                                                        <span className="font-bold">18,300 د.ج</span>
                                                    </div>
                                                    <div className="flex justify-between py-1 border-b border-black mb-1">
                                                        <span>الضريبة (0%):</span>
                                                        <span>0 د.ج</span>
                                                    </div>
                                                    <div className="flex justify-between py-2 text-xl font-black">
                                                        <span>الإجمالي:</span>
                                                        <span>18,300 د.ج</span>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="text-center text-sm text-gray-500 border-t pt-4">
                                                <p>{settings.invoiceFooterText}</p>
                                            </div>
                                        </div>
                                    }
                                />
                            </div>

                            {/* 5. Lost & Found Form */}
                            <div className="p-6 rounded-3xl bg-gray-50 dark:bg-gray-700/30 border border-gray-200 dark:border-gray-600">
                                <h4 className="font-bold text-lg mb-2 text-gray-900 dark:text-white">تقرير مفقودات (Lost & Found)</h4>
                                <p className="text-xs text-gray-500 mb-4">نموذج الإبلاغ عن الأغراض المفقودة أو المعثور عليها.</p>
                                <PrintButton 
                                    label="طباعة نموذج"
                                    className={`w-full py-3 rounded-xl font-bold ${ts.btn}`}
                                    content={
                                        <div className="p-8 bg-white m-4 font-sans text-black border-2 border-gray-300" dir="rtl">
                                            <div className="flex items-center justify-between border-b-2 border-black pb-4 mb-6">
                                                <h1 className="text-2xl font-black">تقرير المفقودات / المعثورات</h1>
                                                <div className="text-left">
                                                    <p className="font-bold">REF: LF-{new Date().getFullYear()}-042</p>
                                                    <p className="text-sm">{new Date().toLocaleDateString()}</p>
                                                </div>
                                            </div>

                                            <div className="space-y-6">
                                                <div className="grid grid-cols-2 gap-4">
                                                    <div className="border p-2 rounded">
                                                        <span className="block text-xs font-bold text-gray-500">نوع التقرير</span>
                                                        <div className="flex gap-4 mt-1">
                                                            <label className="flex items-center gap-1"><div className="w-4 h-4 border border-black"></div> مفقود</label>
                                                            <label className="flex items-center gap-1"><div className="w-4 h-4 border border-black bg-black"></div> معثور عليه</label>
                                                        </div>
                                                    </div>
                                                    <div className="border p-2 rounded">
                                                        <span className="block text-xs font-bold text-gray-500">التاريخ والوقت</span>
                                                        <span className="font-bold">{new Date().toLocaleString()}</span>
                                                    </div>
                                                </div>

                                                <div className="border p-2 rounded">
                                                    <span className="block text-xs font-bold text-gray-500">وصف الغرض (اللون، العلامة التجارية، الحجم...)</span>
                                                    <div className="h-20 border-b border-dotted border-gray-300 mt-2"></div>
                                                    <div className="h-8 border-b border-dotted border-gray-300"></div>
                                                </div>

                                                <div className="grid grid-cols-2 gap-4">
                                                    <div className="border p-2 rounded">
                                                        <span className="block text-xs font-bold text-gray-500">المكان (الغرفة / المنطقة)</span>
                                                        <div className="h-8 border-b border-dotted border-gray-300 mt-1"></div>
                                                    </div>
                                                    <div className="border p-2 rounded">
                                                        <span className="block text-xs font-bold text-gray-500">وجد من طرف / أبلغ من طرف</span>
                                                        <div className="h-8 border-b border-dotted border-gray-300 mt-1"></div>
                                                    </div>
                                                </div>

                                                <div className="border p-4 rounded bg-gray-50 mt-4">
                                                    <p className="font-bold mb-4">الاستلام / التسليم</p>
                                                    <div className="flex justify-between items-end h-16">
                                                        <div className="text-center w-1/3">
                                                            <div className="border-b border-black mb-1"></div>
                                                            <p className="text-xs">توقيع الموظف</p>
                                                        </div>
                                                        <div className="text-center w-1/3">
                                                            <div className="border-b border-black mb-1"></div>
                                                            <p className="text-xs">توقيع المستلم</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    }
                                />
                            </div>

                        </div>
                    </div>
                )}

                {/* --- TAB: QR CODES --- */}
                {activeTab === 'qr' && (
                    <div className={`p-6 rounded-[2.5rem] shadow-sm lg:col-span-3 ${ts.card}`}>
                        <h3 className={`text-xl font-black mb-6 flex items-center gap-2 ${ts.header}`}>
                            <QrCode size={24} className="text-orange-500"/> طباعة رموز الاستجابة السريعة (QR Codes)
                        </h3>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {/* Wifi QR */}
                            <div className="p-6 rounded-3xl bg-gray-50 dark:bg-gray-700/30 border border-gray-200 dark:border-gray-600 flex flex-col items-center text-center gap-4">
                                <div className="bg-white p-4 rounded-xl shadow-sm">
                                    <QrCode size={64} className="text-gray-800"/>
                                </div>
                                <div>
                                    <h4 className="font-bold text-lg text-gray-900 dark:text-white">شبكة الواي فاي</h4>
                                    <p className="text-xs text-gray-500 dark:text-gray-400">طباعة رمز الاتصال التلقائي بالإنترنت</p>
                                </div>
                                <PrintButton 
                                    label="طباعة رمز WiFi"
                                    className={`w-full py-2 rounded-xl font-bold text-sm ${ts.btn}`}
                                    content={
                                        <div className="flex flex-col items-center justify-center p-8 text-center border-4 border-black m-4">
                                            <h2 className="text-3xl font-black mb-4">Free Wi-Fi</h2>
                                            <QrCode size={200} />
                                            <p className="mt-4 font-mono font-bold">Network: Hotel_Guest</p>
                                            <p className="font-mono">Password: welcome2024</p>
                                        </div>
                                    }
                                />
                            </div>

                            {/* Room Access QR */}
                            <div className="p-6 rounded-3xl bg-gray-50 dark:bg-gray-700/30 border border-gray-200 dark:border-gray-600 flex flex-col items-center text-center gap-4">
                                <div className="bg-white p-4 rounded-xl shadow-sm">
                                    <QrCode size={64} className="text-blue-600"/>
                                </div>
                                <div>
                                    <h4 className="font-bold text-lg text-gray-900 dark:text-white">بطاقات الغرف</h4>
                                    <p className="text-xs text-gray-500 dark:text-gray-400">طباعة رموز الوصول للغرف</p>
                                </div>
                                <button className={`w-full py-2 rounded-xl font-bold text-sm opacity-50 cursor-not-allowed bg-gray-200 text-gray-500`}>
                                    متاح في صفحة الغرف
                                </button>
                            </div>

                             {/* App Download QR */}
                             <div className="p-6 rounded-3xl bg-gray-50 dark:bg-gray-700/30 border border-gray-200 dark:border-gray-600 flex flex-col items-center text-center gap-4">
                                <div className="bg-white p-4 rounded-xl shadow-sm">
                                    <QrCode size={64} className="text-green-600"/>
                                </div>
                                <div>
                                    <h4 className="font-bold text-lg text-gray-900 dark:text-white">تطبيق الفندق</h4>
                                    <p className="text-xs text-gray-500 dark:text-gray-400">رمز تحميل التطبيق للنزلاء</p>
                                </div>
                                <PrintButton 
                                    label="طباعة رمز التطبيق"
                                    className={`w-full py-2 rounded-xl font-bold text-sm ${ts.btn}`}
                                    content={
                                        <div className="flex flex-col items-center justify-center p-8 text-center border-4 border-black m-4">
                                            <h2 className="text-3xl font-black mb-4">Download Our App</h2>
                                            <QrCode size={200} />
                                            <p className="mt-4 font-bold">Scan to access hotel services</p>
                                        </div>
                                    }
                                />
                            </div>
                        </div>
                    </div>
                )}

                {/* --- TAB: REPORTS --- */}
                {activeTab === 'reports' && (
                    <div className={`p-6 rounded-[2.5rem] shadow-sm lg:col-span-3 ${ts.card}`}>
                        <h3 className={`text-xl font-black mb-6 flex items-center gap-2 ${ts.header}`}>
                            <FileBarChart size={24} className="text-gray-600"/> تقارير وبيانات شاملة
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                             <div className="p-6 rounded-3xl bg-gray-50 dark:bg-gray-700/30 border border-gray-200 dark:border-gray-600">
                                <h4 className="font-bold text-lg mb-2 text-gray-900 dark:text-white">قائمة النزلاء الحاليين</h4>
                                <p className="text-xs text-gray-500 mb-4">تقرير مفصل بجميع النزلاء المتواجدين حالياً في الفندق.</p>
                                <PrintButton 
                                    label="طباعة القائمة"
                                    className={`w-full py-3 rounded-xl font-bold ${ts.btn}`}
                                    content={
                                        <div className="p-8 bg-white m-4 font-sans" dir="rtl">
                                            <div className="flex justify-between items-center border-b-2 border-black pb-6 mb-6">
                                                <div>
                                                    <h1 className="text-3xl font-black mb-2">قائمة النزلاء الحاليين</h1>
                                                    <p className="text-sm text-gray-500 font-bold">{settings.appName} • {new Date().toLocaleDateString()}</p>
                                                </div>
                                                <div className="p-2 border-2 border-black rounded-lg">
                                                    <QRCodeSVG value={`REPORT:GUESTS:${new Date().toISOString()}`} size={80} />
                                                </div>
                                            </div>
                                            <table className="w-full text-right text-sm border-collapse">
                                                <thead>
                                                    <tr className="bg-gray-100 border-b-2 border-black">
                                                        <th className="p-3 font-black">الغرفة</th>
                                                        <th className="p-3 font-black">الاسم</th>
                                                        <th className="p-3 font-black">تاريخ الدخول</th>
                                                        <th className="p-3 font-black">تاريخ الخروج</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {bookings.filter(b => b.status === 'active').map(b => (
                                                        <tr key={b.id} className="border-b">
                                                            <td className="p-2 font-bold">{rooms.find(r => r.id === b.roomId)?.number}</td>
                                                            <td className="p-2">{b.guests[0].firstNameAr} {b.guests[0].lastNameAr}</td>
                                                            <td className="p-2">{b.checkInDate}</td>
                                                            <td className="p-2">{b.checkOutDate}</td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                        </div>
                                    }
                                />
                             </div>
                             
                             <div className="p-6 rounded-3xl bg-gray-50 dark:bg-gray-700/30 border border-gray-200 dark:border-gray-600">
                                <h4 className="font-bold text-lg mb-2 text-gray-900 dark:text-white">تقرير الغرف</h4>
                                <p className="text-xs text-gray-500 mb-4">حالة جميع الغرف (مشغولة، فارغة، صيانة).</p>
                                <PrintButton 
                                    label="طباعة التقرير"
                                    className={`w-full py-3 rounded-xl font-bold ${ts.btn}`}
                                    content={
                                        <div className="p-8 bg-white m-4 font-sans" dir="rtl">
                                            <div className="flex justify-between items-center border-b-2 border-black pb-6 mb-6">
                                                <div>
                                                    <h1 className="text-3xl font-black mb-2">تقرير حالة الغرف</h1>
                                                    <p className="text-sm text-gray-500 font-bold">{settings.appName} • {new Date().toLocaleDateString()}</p>
                                                </div>
                                                <div className="p-2 border-2 border-black rounded-lg">
                                                    <QRCodeSVG value={`REPORT:ROOMS:${new Date().toISOString()}`} size={80} />
                                                </div>
                                            </div>
                                            <div className="grid grid-cols-4 gap-4">
                                                {rooms.map(r => (
                                                    <div key={r.id} className={`border-2 p-4 text-center rounded-xl ${r.status === 'occupied' ? 'bg-red-50 border-red-200' : r.status === 'available' ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'}`}>
                                                        <div className="font-black text-2xl mb-1">{r.number}</div>
                                                        <div className="text-xs font-bold uppercase tracking-wider opacity-70">{r.status}</div>
                                                    </div>
                                                ))}
                                            </div>
                                            <div className="mt-8 pt-4 border-t border-gray-200 text-center text-xs text-gray-400 font-mono">
                                                Generated by {settings.appName} System
                                            </div>
                                        </div>
                                    }
                                />
                             </div>
                        </div>
                    </div>
                )}

            </div>

            <div className="fixed bottom-6 left-6 z-50">
                <button onClick={handleSave} className={`px-8 py-4 rounded-full font-black shadow-2xl flex items-center gap-3 transition transform hover:-translate-y-1 hover:scale-105 ${ts.btn}`}>
                    <Check size={24}/> حفظ الإعدادات
                </button>
            </div>
        </div>
    );
};
