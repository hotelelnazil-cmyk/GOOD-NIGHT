
import React, { useState, useRef } from 'react';
import { useHotel } from '../context/HotelContext';
import { 
    Building2, Search, QrCode, MapPin, Phone, Mail, 
    Star, Coffee, Wifi, Car, CheckCircle, ArrowLeft, Scan, Camera, X, Sparkles
} from 'lucide-react';
import { Booking } from '../types';

export const PublicLandingPage: React.FC = () => {
    const { settings, rooms, bookings, menuItems, addNotification } = useHotel();
    const [activeSection, setActiveSection] = useState<'home' | 'verify' | 'rooms'>('home');
    const [bookingRef, setBookingRef] = useState('');
    const [verificationResult, setVerificationResult] = useState<Booking | null>(null);
    const [showCamera, setShowCamera] = useState(false);
    const videoRef = useRef<HTMLVideoElement>(null);

    // --- Theme Helpers ---
    const getThemeColors = () => {
        if (settings.theme === 'zellige' || settings.theme === 'zellige-v2') {
            return {
                bg: 'bg-[#FDFBF7]',
                primary: 'bg-[#006269]',
                text: 'text-[#006269]',
                accent: 'text-[#cca43b]',
                border: 'border-[#cca43b]',
                pattern: 'bg-zellige-pattern'
            };
        }
        return {
            bg: 'bg-gray-50',
            primary: 'bg-blue-900',
            text: 'text-blue-900',
            accent: 'text-yellow-500',
            border: 'border-blue-200',
            pattern: ''
        };
    };
    const th = getThemeColors();

    // --- Verification Logic ---
    const handleVerify = (e: React.FormEvent) => {
        e.preventDefault();
        // Simulate lookup (in real app, this would be an API call)
        // Check both ID and guestToken
        const found = bookings.find(b => 
            b.id.toLowerCase().includes(bookingRef.toLowerCase()) || 
            b.guestToken === bookingRef
        );
        
        if (found) {
            setVerificationResult(found);
        } else {
            addNotification('لم يتم العثور على حجز بهذا الرقم', "error");
            setVerificationResult(null);
        }
    };

    const startCamera = async () => {
        setShowCamera(true);
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
            if (videoRef.current) videoRef.current.srcObject = stream;
        } catch (err) {
            addNotification("تعذر الوصول للكاميرا", "error");
            setShowCamera(false);
        }
    };

    return (
        <div className={`min-h-screen ${th.bg} font-sans text-gray-800 flex flex-col`} dir="rtl">
            
            {/* --- HERO HEADER --- */}
            <header className={`relative text-white overflow-hidden ${th.primary} rounded-b-[3rem] shadow-2xl`}>
                {th.pattern && <div className={`absolute inset-0 opacity-10 ${th.pattern} mix-blend-multiply`}></div>}
                
                <div className="relative z-10 px-6 pt-8 pb-16">
                    <nav className="flex justify-between items-center mb-10">
                        <div className="flex items-center gap-2">
                            <div className="bg-white/20 p-2 rounded-xl backdrop-blur-md">
                                <Building2 size={24} />
                            </div>
                            <span className="font-black text-lg tracking-wide">{settings.appName}</span>
                        </div>
                        <div className="flex gap-4 text-sm font-bold">
                            <button onClick={() => setActiveSection('home')} className={`opacity-80 hover:opacity-100 ${activeSection==='home'?'border-b-2':''}`}>الرئيسية</button>
                            <button onClick={() => setActiveSection('rooms')} className={`opacity-80 hover:opacity-100 ${activeSection==='rooms'?'border-b-2':''}`}>الغرف</button>
                            <button onClick={() => setActiveSection('verify')} className={`bg-white text-black px-4 py-1.5 rounded-full shadow-lg flex items-center gap-2 hover:scale-105 transition`}>
                                <Search size={14}/> تتبع الحجز
                            </button>
                        </div>
                    </nav>

                    <div className="text-center max-w-2xl mx-auto mt-8 animate-fade-in-up">
                        <h1 className="text-4xl md:text-5xl font-black mb-4 leading-tight">
                            {settings.marketingConfig.promoTitle}
                        </h1>
                        <p className="text-white/80 text-lg font-medium mb-8">
                            {settings.marketingConfig.promoDescription}
                        </p>
                        <button onClick={() => setActiveSection('rooms')} className="bg-[#cca43b] text-white px-8 py-4 rounded-2xl font-black shadow-xl hover:bg-[#b08d33] transition transform hover:-translate-y-1">
                            {settings.marketingConfig.buttonText}
                        </button>
                    </div>
                </div>
            </header>

            {/* --- MAIN CONTENT AREA --- */}
            <main className="flex-1 max-w-6xl mx-auto w-full px-4 -mt-10 relative z-20 pb-20">
                
                {/* VERIFICATION SECTION */}
                {activeSection === 'verify' && (
                    <div className="bg-white rounded-[2.5rem] p-8 shadow-xl animate-fade-in border-4 border-white">
                        <h2 className={`text-2xl font-black mb-6 flex items-center gap-2 ${th.text}`}>
                            <CheckCircle /> التحقق من الحجز
                        </h2>
                        
                        {!verificationResult ? (
                            <div className="max-w-md mx-auto">
                                <div className="flex gap-4 mb-6 justify-center">
                                    <button onClick={startCamera} className="flex-1 py-4 bg-gray-900 text-white rounded-2xl font-bold flex flex-col items-center gap-2 shadow-lg hover:bg-black transition">
                                        <QrCode size={24}/> مسح رمز QR
                                    </button>
                                </div>

                                {showCamera && (
                                    <div className="relative aspect-video bg-black rounded-2xl overflow-hidden mb-6 border-4 border-gray-200">
                                        <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover"></video>
                                        <button onClick={() => setShowCamera(false)} className="absolute top-4 right-4 bg-white text-black p-2 rounded-full"><X/></button>
                                        <div className="absolute inset-0 border-2 border-white/50 m-8 rounded-xl pointer-events-none"></div>
                                        <p className="absolute bottom-4 w-full text-center text-white text-xs font-bold shadow-black drop-shadow-md">قم بتوجيه الكاميرا نحو رمز الحجز</p>
                                    </div>
                                )}

                                <div className="relative flex items-center">
                                    <div className="flex-grow border-t border-gray-200"></div>
                                    <span className="flex-shrink-0 mx-4 text-gray-400 text-sm font-bold">أو أدخل الرقم يدوياً</span>
                                    <div className="flex-grow border-t border-gray-200"></div>
                                </div>

                                <form onSubmit={handleVerify} className="mt-6">
                                    <input 
                                        type="text" 
                                        placeholder="رقم الحجز أو التذكرة (REF...)" 
                                        className="w-full p-4 rounded-xl bg-gray-100 border-2 border-transparent focus:border-blue-500 outline-none font-bold text-center text-lg mb-4"
                                        value={bookingRef}
                                        onChange={e => setBookingRef(e.target.value)}
                                    />
                                    <button type="submit" className={`w-full py-4 rounded-xl text-white font-bold text-lg shadow-lg ${th.primary}`}>
                                        تحقق الآن
                                    </button>
                                </form>
                            </div>
                        ) : (
                            <div className="bg-green-50 p-6 rounded-3xl border border-green-100 text-center">
                                <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                                    <CheckCircle size={40}/>
                                </div>
                                <h3 className="text-2xl font-black text-gray-800 mb-1">حجز مؤكد</h3>
                                <p className="text-gray-500 font-bold mb-6">أهلاً بك، {verificationResult.primaryGuestName}</p>
                                
                                <div className="grid grid-cols-2 gap-4 text-right bg-white p-4 rounded-2xl shadow-sm mb-6">
                                    <div>
                                        <span className="text-xs text-gray-400 font-bold block">تاريخ الدخول</span>
                                        <span className="font-black">{new Date(verificationResult.checkInDate).toLocaleDateString()}</span>
                                    </div>
                                    <div>
                                        <span className="text-xs text-gray-400 font-bold block">الغرفة</span>
                                        <span className="font-black">{rooms.find(r=>r.id===verificationResult.roomId)?.number || 'Pending'}</span>
                                    </div>
                                </div>

                                <button onClick={() => setVerificationResult(null)} className="text-gray-500 font-bold underline text-sm">
                                    فحص حجز آخر
                                </button>
                            </div>
                        )}
                    </div>
                )}

                {/* HOME CONTENT */}
                {activeSection === 'home' && (
                    <div className="space-y-8 animate-fade-in">
                        {/* Features */}
                        <div className="bg-white rounded-[2.5rem] p-8 shadow-lg border border-gray-100">
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
                                {[
                                    {label: 'واي فاي مجاني', icon: Wifi},
                                    {label: 'مطعم فاخر', icon: Coffee},
                                    {label: 'مواقف سيارات', icon: Car},
                                    {label: 'خدمة 24/7', icon: Star},
                                ].map((f, i) => (
                                    <div key={i} className="flex flex-col items-center gap-2">
                                        <div className={`p-4 rounded-2xl ${th.primary} text-white shadow-lg`}>
                                            <f.icon size={24}/>
                                        </div>
                                        <span className="font-bold text-sm text-gray-600">{f.label}</span>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* Tourism Sectors & Services Showcase */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            {[
                                { title: 'النقل والسياحة', icon: Car, desc: 'جولات سياحية، توصيل للمطار، وتأجير سيارات فاخرة.' },
                                { title: 'الصحة والسبا', icon: Sparkles, desc: 'حمام تركي، ساونا، وتدليك احترافي للاسترخاء.' },
                                { title: 'المناسبات والمؤتمرات', icon: Building2, desc: 'قاعات مجهزة للأعراس والاجتماعات الرسمية.' }
                            ].map((s, i) => (
                                <div key={i} className="bg-white p-6 rounded-[2rem] shadow-sm border border-gray-100 hover:shadow-md transition">
                                    <div className={`w-12 h-12 rounded-2xl ${th.bg} flex items-center justify-center mb-4 ${th.text}`}>
                                        <s.icon size={24}/>
                                    </div>
                                    <h3 className="font-black text-lg mb-2">{s.title}</h3>
                                    <p className="text-sm text-gray-500 leading-relaxed">{s.desc}</p>
                                </div>
                            ))}
                        </div>

                        {/* Info Card */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className={`p-8 rounded-[2.5rem] bg-white shadow-lg border-l-4 ${th.border}`}>
                                <h3 className={`text-xl font-black mb-4 ${th.text}`}>عن الفندق</h3>
                                <p className="text-gray-500 leading-relaxed font-medium">
                                    {settings.hotelIdentity.bio}
                                </p>
                                <div className="mt-6 flex flex-col gap-3">
                                    <div className="flex items-center gap-3 text-gray-600 font-bold text-sm">
                                        <MapPin className={th.accent} size={18}/> {settings.hotelAddress}
                                    </div>
                                    <div className="flex items-center gap-3 text-gray-600 font-bold text-sm">
                                        <Phone className={th.accent} size={18}/> {settings.hotelPhone}
                                    </div>
                                    <div className="flex items-center gap-3 text-gray-600 font-bold text-sm">
                                        <Mail className={th.accent} size={18}/> {settings.hotelEmail}
                                    </div>
                                </div>
                            </div>
                            
                            <div className="rounded-[2.5rem] overflow-hidden shadow-lg relative h-64 md:h-auto group">
                                <img src="https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" className="w-full h-full object-cover transition duration-700 group-hover:scale-110" alt="Hotel" />
                                <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                                    <a href={`https://maps.google.com/?q=${settings.hotelAddress}`} target="_blank" className="bg-white/90 backdrop-blur px-6 py-3 rounded-full font-bold flex items-center gap-2 hover:bg-white transition">
                                        <MapPin size={18}/> موقعنا على الخريطة
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {/* ROOMS SHOWCASE */}
                {activeSection === 'rooms' && (
                    <div className="space-y-6 animate-fade-in">
                        <div className="bg-white rounded-[2.5rem] p-6 shadow-sm border border-gray-100 mb-6">
                            <h2 className={`text-2xl font-black mb-2 ${th.text}`}>إقامتك المثالية</h2>
                            <p className="text-gray-500">اختر من بين تشكيلة متنوعة من الغرف والأجنحة الفاخرة.</p>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            {['single', 'double', 'suite'].map(type => {
                                const price = settings.roomPrices[type]?.[0]?.amount || 0;
                                return (
                                    <div key={type} className="bg-white rounded-[2rem] overflow-hidden shadow-lg group hover:shadow-xl transition border border-gray-100">
                                        <div className="h-48 bg-gray-200 relative">
                                            <img 
                                                src={`https://source.unsplash.com/random/400x300/?hotel,room,${type}`} 
                                                className="w-full h-full object-cover" 
                                                alt={type}
                                            />
                                            <div className="absolute top-4 right-4 bg-white/90 backdrop-blur px-3 py-1 rounded-lg text-xs font-black uppercase tracking-wider">
                                                {type}
                                            </div>
                                        </div>
                                        <div className="p-6">
                                            <h3 className="font-black text-lg mb-2 capitalize">{type === 'suite' ? 'جناح ملكي' : type + ' Room'}</h3>
                                            <p className="text-gray-400 text-xs font-bold mb-4">خدمة واي فاي • إفطار مجاني • إطلالة</p>
                                            <div className="flex justify-between items-center">
                                                <span className={`text-xl font-black ${th.text}`}>{price} د.ج <span className="text-xs font-normal text-gray-400">/ليلة</span></span>
                                                <button className="bg-black text-white px-4 py-2 rounded-xl text-xs font-bold">حجز</button>
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                )}

            </main>

            {/* --- FOOTER --- */}
            <footer className="bg-gray-900 text-white py-8 text-center relative z-10">
                <p className="opacity-50 text-sm font-medium">© {new Date().getFullYear()} {settings.appName}. All Rights Reserved.</p>
                <div className="mt-4 flex justify-center gap-4 opacity-40">
                    <Building2 size={20}/>
                    <Wifi size={20}/>
                    <Coffee size={20}/>
                </div>
            </footer>
        </div>
    );
};
