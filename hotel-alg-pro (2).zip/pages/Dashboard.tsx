
import React, { useState } from 'react';
import { useHotel } from '../context/HotelContext';
import { PageHeader } from '../components/PageHeader';
import { Modal } from '../components/Modal';
import { LayoutGrid, BedDouble, TrendingUp, LogIn, LogOut, AlertTriangle, CheckCircle, Clock, AlertOctagon, DollarSign, PieChart as PieIcon, Truck, Utensils, ShoppingBag, Briefcase, Send, MessageSquare, Users, Phone, X } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';

import { isZelligeTheme } from '../constants';

export const Dashboard: React.FC<{ navigate: (page: string) => void }> = ({ navigate }) => {
  const { rooms, bookings, maintenanceTickets, incidentReports, settings, transactions, externalOrders, restaurantOrders, currentUser, addNotification, users } = useHotel();
  const [showTeamModal, setShowTeamModal] = useState(false);
  const [messageModal, setMessageModal] = useState<{ isOpen: boolean, type: 'broadcast' | 'report' | null }>({ isOpen: false, type: null });
  const [messageText, setMessageText] = useState('');

  const occupiedRooms = rooms.filter(r => r.status === 'occupied').length;
  const maintenanceRooms = rooms.filter(r => r.status === 'maintenance').length;
  const availableRooms = rooms.filter(r => r.status === 'available').length;
  const dirtyRooms = rooms.filter(r => r.status === 'dirty').length;
  const occupancyRate = Math.round((occupiedRooms / rooms.length) * 100) || 0;

  const today = new Date().toISOString().split('T')[0];
  // Safe date comparison
  const checkIns = bookings.filter(b => b.checkInDate.split('T')[0] === today).length;
  const checkOuts = bookings.filter(b => b.checkOutDate.split('T')[0] === today).length;
  
  const activeIncidents = incidentReports.filter(i => i.status === 'reported' || i.status === 'investigating').length;
  
  // New Stats
  const activeExternalOrders = externalOrders.filter(o => o.status !== 'delivered' && o.status !== 'cancelled').length;
  const activeRestaurantOrders = restaurantOrders.filter(o => o.status !== 'completed' && o.status !== 'cancelled').length;
  const deliveryOrders = restaurantOrders.filter(o => o.type === 'delivery' && o.status !== 'completed' && o.status !== 'cancelled').length;

  // Access Control Helpers
  const role = currentUser?.role || '';
  const canAccessExternal = ['manager', 'assistant_manager', 'reception_manager', 'receptionist', 'concierge'].includes(role);
  const canAccessAccommodation = ['manager', 'assistant_manager', 'reception_manager', 'receptionist', 'housekeeping_manager', 'housekeeping_staff'].includes(role);
  const canAccessOperations = ['manager', 'assistant_manager', 'maintenance_manager', 'maintenance_staff', 'housekeeping_manager', 'housekeeping_staff', 'security_manager', 'security_guard'].includes(role);

  // Department Alliance Logic
  const myDept = currentUser?.department;
  const isHead = currentUser?.isHeadOfDepartment;
  
  const handleTeamBroadcast = () => {
      setMessageModal({ isOpen: true, type: 'broadcast' });
  };

  const handleReportToHead = () => {
      setMessageModal({ isOpen: true, type: 'report' });
  };

  const handleSendMessage = () => {
      if (!messageText.trim()) return;
      
      if (messageModal.type === 'broadcast') {
          if (myDept) {
             addNotification(`توجيه من رئيس القسم (${currentUser?.name})`, 'warning', messageText, { departments: [myDept as any] });
             addNotification("تم إرسال التوجيه للفريق", "success");
          } else {
             addNotification("خطأ: لم يتم تحديد القسم", "error");
          }
      } else if (messageModal.type === 'report') {
          const targetRoles = ['manager', 'assistant_manager'];
          if (myDept) targetRoles.push(`${myDept}_manager`);
          
          addNotification(`تقرير من ${currentUser?.name}`, 'info', messageText, { roles: targetRoles as any });
          addNotification("تم إرسال التقرير", "success");
      }
      
      setMessageModal({ isOpen: false, type: null });
      setMessageText('');
  };

  // Chart Data Preparation
  const roomStatusData = [
      { name: 'متاحة', value: availableRooms, color: '#10B981' },
      { name: 'مشغولة', value: occupiedRooms, color: '#3B82F6' },
      { name: 'تنظيف', value: dirtyRooms, color: '#F59E0B' },
      { name: 'صيانة', value: maintenanceRooms, color: '#EF4444' },
  ];

  // Revenue Last 7 Days
  const revenueData = Array.from({ length: 7 }, (_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - (6 - i));
      const dateStr = d.toISOString().split('T')[0];
      const dailyTotal = transactions
          .filter(t => t.date.startsWith(dateStr) && t.type === 'payment')
          .reduce((sum, t) => sum + t.amount, 0);
      return {
          name: d.toLocaleDateString('ar-EG', { weekday: 'short' }),
          amount: dailyTotal
      };
  });

  const getThemeStyles = () => {
      // Radical Fix: Dark mode overrides all themes for consistency but respects theme identity
      if (settings.darkMode) {
          if (settings.theme === 'zellige') {
              return {
                  card: 'bg-[#002a2d] border-2 border-[#cca43b]/30 shadow-lg relative overflow-hidden',
                  iconBox: 'bg-[#001e21] text-[#cca43b] border border-[#cca43b]/50 shadow-[0_0_15px_rgba(204,164,59,0.2)]',
                  text: 'text-[#cca43b] drop-shadow-sm',
                  button: 'bg-[#cca43b] text-[#002a2d] hover:bg-[#b08d30] font-bold border border-[#cca43b]',
                  input: 'bg-[#001e21] text-[#cca43b] border-[#cca43b]/40 placeholder-[#cca43b]/40',
                  subText: 'text-[#cca43b]/70',
                  chartBar: '#cca43b',
                  colors: { primary: '#cca43b', secondary: '#002a2d', accent: '#f0c04a', border: '#cca43b', bg: '#002a2d', text: '#cca43b' }
              };
          }
          if (settings.theme === 'zellige-algiers') {
              return {
                  card: 'bg-[#1e293b] border-2 border-[#1e3a8a]/30 shadow-lg relative overflow-hidden',
                  iconBox: 'bg-[#0f172a] text-[#1e3a8a] border border-[#1e3a8a]/50 shadow-[0_0_15px_rgba(30,58,138,0.2)]',
                  text: 'text-[#f8fafc] drop-shadow-sm',
                  button: 'bg-[#1e3a8a] text-[#f8fafc] hover:bg-[#172554] font-bold border border-[#1e3a8a]',
                  input: 'bg-[#0f172a] text-[#f8fafc] border-[#1e3a8a]/40 placeholder-[#1e3a8a]/40',
                  subText: 'text-[#94a3b8]',
                  chartBar: '#1e3a8a',
                  colors: { primary: '#1e3a8a', secondary: '#0f172a', accent: '#60a5fa', border: '#1e3a8a', bg: '#1e293b', text: '#f8fafc' }
              };
          }
          if (settings.theme === 'zellige-tlemcen') {
              return {
                  card: 'bg-[#3f2e25] border-2 border-[#b45309]/30 shadow-lg relative overflow-hidden',
                  iconBox: 'bg-[#271c19] text-[#b45309] border border-[#b45309]/50 shadow-[0_0_15px_rgba(180,83,9,0.2)]',
                  text: 'text-[#fffbeb] drop-shadow-sm',
                  button: 'bg-[#b45309] text-[#fffbeb] hover:bg-[#92400e] font-bold border border-[#b45309]',
                  input: 'bg-[#271c19] text-[#fffbeb] border-[#b45309]/40 placeholder-[#b45309]/40',
                  subText: 'text-[#d6d3d1]',
                  chartBar: '#b45309',
                  colors: { primary: '#b45309', secondary: '#271c19', accent: '#fbbf24', border: '#b45309', bg: '#3f2e25', text: '#fffbeb' }
              };
          }
          if (settings.theme === 'zellige-sahara') {
              return {
                  card: 'bg-[#432c1c] border-2 border-[#d97706]/30 shadow-lg relative overflow-hidden',
                  iconBox: 'bg-[#2a1b12] text-[#d97706] border border-[#d97706]/50 shadow-[0_0_15px_rgba(217,119,6,0.2)]',
                  text: 'text-[#fff7ed] drop-shadow-sm',
                  button: 'bg-[#d97706] text-[#fff7ed] hover:bg-[#b45309] font-bold border border-[#d97706]',
                  input: 'bg-[#2a1b12] text-[#fff7ed] border-[#d97706]/40 placeholder-[#d97706]/40',
                  subText: 'text-[#fed7aa]',
                  chartBar: '#d97706',
                  colors: { primary: '#d97706', secondary: '#2a1b12', accent: '#fb923c', border: '#d97706', bg: '#432c1c', text: '#fff7ed' }
              };
          }
          if (settings.theme === 'algerian-military') {
              return {
                  card: 'bg-[#1a211a] border-2 border-[#D4AF37]/40 shadow-lg',
                  iconBox: 'bg-[#D4AF37] text-[#1a211a] shadow-md',
                  text: 'text-[#D4AF37]',
                  button: 'bg-[#D4AF37] text-[#1a211a] hover:bg-[#b08d30] font-bold',
                  input: 'bg-[#1a211a] text-[#D4AF37] border-[#D4AF37]/40 placeholder-[#D4AF37]/40',
                  subText: 'text-[#D4AF37]/70',
                  chartBar: '#D4AF37',
                  colors: { primary: '#D4AF37', secondary: '#1a211a', accent: '#D4AF37', border: '#D4AF37', bg: '#1a211a', text: '#D4AF37' }
              };
          }
          if (settings.theme === 'modern-ornate') {
               return {
                  card: 'bg-[#2d0b3d] border-2 border-[#ffd700]/40 shadow-lg',
                  iconBox: 'bg-[#ffd700] text-[#2d0b3d] shadow-md',
                  text: 'text-[#ffd700]',
                  button: 'bg-[#ffd700] text-[#2d0b3d] hover:bg-[#e6c200] font-bold',
                  input: 'bg-[#2d0b3d] text-[#ffd700] border-[#ffd700]/40 placeholder-[#ffd700]/40',
                  subText: 'text-[#ffd700]/70',
                  chartBar: '#ffd700',
                  colors: { primary: '#ffd700', secondary: '#2d0b3d', accent: '#ffd700', border: '#ffd700', bg: '#2d0b3d', text: '#ffd700' }
              };
          }
          return {
              card: 'bg-gray-800 border border-gray-700 shadow-sm',
              iconBox: 'bg-blue-600 text-white shadow-lg shadow-blue-900/20',
              text: 'text-gray-100',
              button: 'bg-blue-600 text-white hover:bg-blue-700',
              input: 'bg-gray-800 text-gray-100 border-gray-700',
              subText: 'text-gray-400',
              chartBar: '#3B82F6',
              colors: { primary: '#3B82F6', secondary: '#1f2937', accent: '#60a5fa', border: '#374151', bg: '#1f2937', text: '#f3f4f6' }
          };
      }

      switch (settings.theme) {
          case 'zellige': return {
              card: 'bg-[#fdfbf7] border-2 border-[#cca43b]/20 hover:border-[#006269] relative overflow-hidden',
              iconBox: 'bg-[#006269] text-[#cca43b] border border-[#cca43b]/20',
              text: 'text-[#006269]',
              button: 'bg-[#006269] text-[#cca43b] hover:bg-[#004d52] border border-[#cca43b]/20',
              input: 'bg-[#fbf8f1] text-[#006269] border-[#cca43b]/20 placeholder-[#cca43b]/40',
              subText: 'text-[#006269]/70',
              chartBar: '#006269',
              colors: { primary: '#006269', secondary: '#fdfbf7', accent: '#cca43b', border: '#cca43b', bg: '#fdfbf7', text: '#006269' }
          };
          case 'zellige-v2': return {
              card: 'bg-[#f5fcf9] border-2 border-[#c6e3d8] hover:border-[#024d38]',
              iconBox: 'bg-[#024d38] text-white',
              text: 'text-[#024d38]',
              button: 'bg-[#024d38] text-white hover:bg-[#013b2b]',
              input: 'bg-white text-[#024d38] border-[#c6e3d8] placeholder-[#024d38]/40',
              subText: 'text-[#024d38]/70',
              chartBar: '#024d38',
              colors: { primary: '#024d38', secondary: '#f5fcf9', accent: '#024d38', border: '#c6e3d8', bg: '#f5fcf9', text: '#024d38' }
          };
          case 'zellige-algiers': return {
              card: 'bg-[#eff6ff] border-2 border-[#1e3a8a]/20 hover:border-[#1e3a8a] relative overflow-hidden',
              iconBox: 'bg-[#1e3a8a] text-[#f8fafc] border border-[#1e3a8a]/20',
              text: 'text-[#1e3a8a]',
              button: 'bg-[#1e3a8a] text-[#f8fafc] hover:bg-[#172554] border border-[#1e3a8a]/20',
              input: 'bg-white text-[#1e3a8a] border-[#1e3a8a]/20 placeholder-[#1e3a8a]/40',
              subText: 'text-[#64748b]',
              chartBar: '#1e3a8a',
              colors: { primary: '#1e3a8a', secondary: '#eff6ff', accent: '#1e3a8a', border: '#1e3a8a', bg: '#eff6ff', text: '#1e3a8a' }
          };
          case 'zellige-tlemcen': return {
              card: 'bg-[#fffbeb] border-2 border-[#b45309]/20 hover:border-[#b45309] relative overflow-hidden',
              iconBox: 'bg-[#b45309] text-[#fffbeb] border border-[#b45309]/20',
              text: 'text-[#064e3b]',
              button: 'bg-[#b45309] text-[#fffbeb] hover:bg-[#92400e] border border-[#b45309]/20',
              input: 'bg-white text-[#064e3b] border-[#b45309]/20 placeholder-[#b45309]/40',
              subText: 'text-[#7c2d12]',
              chartBar: '#b45309',
              colors: { primary: '#b45309', secondary: '#fffbeb', accent: '#b45309', border: '#b45309', bg: '#fffbeb', text: '#064e3b' }
          };
          case 'zellige-sahara': return {
              card: 'bg-[#fff7ed] border-2 border-[#d97706]/20 hover:border-[#d97706] relative overflow-hidden',
              iconBox: 'bg-[#d97706] text-[#fff7ed] border border-[#d97706]/20',
              text: 'text-[#1e40af]',
              button: 'bg-[#d97706] text-[#fff7ed] hover:bg-[#b45309] border border-[#d97706]/20',
              input: 'bg-white text-[#1e40af] border-[#d97706]/20 placeholder-[#d97706]/40',
              subText: 'text-[#ea580c]',
              chartBar: '#d97706',
              colors: { primary: '#d97706', secondary: '#fff7ed', accent: '#d97706', border: '#d97706', bg: '#fff7ed', text: '#1e40af' }
          };
          case 'algerian-military': return {
              card: 'bg-[#F0EFEA] border-2 border-[#D4AF37]/20 hover:border-[#2F3E2E]',
              iconBox: 'bg-[#2F3E2E] text-[#D4AF37]',
              text: 'text-[#2F3E2E]',
              button: 'bg-[#2F3E2E] text-[#D4AF37] hover:bg-[#4B5320]',
              input: 'bg-[#F0EFEA] text-[#2F3E2E] border-[#D4AF37]/20 placeholder-[#2F3E2E]/40',
              subText: 'text-[#2F3E2E]/70',
              chartBar: '#2F3E2E',
              colors: { primary: '#2F3E2E', secondary: '#F0EFEA', accent: '#D4AF37', border: '#D4AF37', bg: '#F0EFEA', text: '#2F3E2E' }
          };
          case 'modern-ornate': return {
              card: 'bg-[#f3e5f5] border-2 border-[#ffd700]/20 hover:border-[#4a148c]',
              iconBox: 'bg-[#4a148c] text-[#ffd700]',
              text: 'text-[#4a148c]',
              button: 'bg-[#4a148c] text-[#ffd700] hover:bg-[#380d6b]',
              input: 'bg-white text-[#4a148c] border-[#ffd700]/20 placeholder-[#4a148c]/40',
              subText: 'text-[#4a148c]/70',
              chartBar: '#4a148c',
              colors: { primary: '#4a148c', secondary: '#f3e5f5', accent: '#ffd700', border: '#ffd700', bg: '#f3e5f5', text: '#4a148c' }
          };
          default: return {
              card: 'bg-white border border-gray-200',
              iconBox: 'bg-blue-600 text-white',
              text: 'text-gray-900',
              button: 'bg-blue-600 text-white hover:bg-blue-700',
              input: 'bg-white text-gray-900 border-gray-200',
              subText: 'text-gray-500',
              chartBar: '#3B82F6',
              colors: { primary: '#3B82F6', secondary: '#ffffff', accent: '#60a5fa', border: '#e5e7eb', bg: '#ffffff', text: '#111827' }
          };
      }
  };
  const ts = getThemeStyles();

  const getQuickActionTheme = () => {
      if (settings.darkMode) {
          if (settings.theme === 'zellige') return 'bg-[#002a2d] text-[#cca43b] border border-[#cca43b]/30 hover:bg-[#cca43b]/10';
          if (settings.theme === 'zellige-algiers') return 'bg-[#0f172a] text-[#f8fafc] border border-[#1e3a8a]/30 hover:bg-[#1e3a8a]/10';
          if (settings.theme === 'zellige-tlemcen') return 'bg-[#271c19] text-[#fffbeb] border border-[#b45309]/30 hover:bg-[#b45309]/10';
          if (settings.theme === 'zellige-sahara') return 'bg-[#2a1b12] text-[#fff7ed] border border-[#d97706]/30 hover:bg-[#d97706]/10';
      }
      if (settings.theme === 'zellige') return 'bg-[#fdfbf7] text-[#006269] border border-[#cca43b]/30 hover:bg-[#006269]/5';
      if (settings.theme === 'zellige-algiers') return 'bg-[#eff6ff] text-[#1e3a8a] border border-[#1e3a8a]/30 hover:bg-[#1e3a8a]/5';
      if (settings.theme === 'zellige-tlemcen') return 'bg-[#fffbeb] text-[#b45309] border border-[#b45309]/30 hover:bg-[#b45309]/5';
      if (settings.theme === 'zellige-sahara') return 'bg-[#fff7ed] text-[#d97706] border border-[#d97706]/30 hover:bg-[#d97706]/5';
      return null;
  };

  const quickActionClass = getQuickActionTheme();

  const getStatTheme = () => {
      if (settings.darkMode) {
          if (settings.theme === 'zellige') return { color: 'text-[#f0c04a]', bg: 'bg-[#002a2d] border border-[#cca43b]/30 shadow-[inset_0_0_10px_rgba(204,164,59,0.1)]' };
          if (settings.theme === 'zellige-algiers') return { color: 'text-[#f8fafc]', bg: 'bg-[#1e3a8a] border border-[#60a5fa]/30 shadow-[inset_0_0_10px_rgba(96,165,250,0.1)]' };
          if (settings.theme === 'zellige-tlemcen') return { color: 'text-[#fffbeb]', bg: 'bg-[#451a03] border border-[#b45309]/30 shadow-[inset_0_0_10px_rgba(180,83,9,0.1)]' };
          if (settings.theme === 'zellige-sahara') return { color: 'text-[#fff7ed]', bg: 'bg-[#431407] border border-[#d97706]/30 shadow-[inset_0_0_10px_rgba(217,119,6,0.1)]' };
      }
      if (settings.theme === 'zellige') return { color: 'text-[#006269]', bg: 'bg-[#fdfbf7] border border-[#cca43b]/30' };
      if (settings.theme === 'zellige-algiers') return { color: 'text-[#1e3a8a]', bg: 'bg-[#eff6ff] border border-[#1e3a8a]/30' };
      if (settings.theme === 'zellige-tlemcen') return { color: 'text-[#7c2d12]', bg: 'bg-[#fffbeb] border border-[#b45309]/30' };
      if (settings.theme === 'zellige-sahara') return { color: 'text-[#c2410c]', bg: 'bg-[#fff7ed] border border-[#d97706]/30' };
      return null;
  };

  const statTheme = getStatTheme();
  const isZelligeDark = settings.darkMode && isZelligeTheme(settings.theme);

  const getZelligePatternClass = () => {
      if (settings.theme === 'zellige') return 'bg-zellige-pattern';
      if (settings.theme === 'zellige-v2') return 'bg-zellige-v2-pattern';
      if (settings.theme === 'zellige-algiers') return 'bg-zellige-algiers-pattern';
      if (settings.theme === 'zellige-tlemcen') return 'bg-zellige-tlemcen-pattern';
      if (settings.theme === 'zellige-sahara') return 'bg-zellige-sahara-pattern';
      return 'bg-zellige-pattern';
  };

  const stats = [
      { 
          label: 'نسبة الإشغال', 
          value: `${occupancyRate}%`, 
          icon: TrendingUp, 
          color: statTheme ? statTheme.color : 'text-blue-500', 
          bg: statTheme ? statTheme.bg : 'bg-blue-100 dark:bg-blue-900/30' 
      },
      { 
          label: 'غرف مشغولة', 
          value: occupiedRooms, 
          icon: BedDouble, 
          color: statTheme ? statTheme.color : 'text-indigo-500', 
          bg: statTheme ? statTheme.bg : 'bg-indigo-100 dark:bg-indigo-900/30' 
      },
      { 
          label: 'دخول اليوم', 
          value: checkIns, 
          icon: LogIn, 
          color: statTheme ? statTheme.color : 'text-green-500', 
          bg: statTheme ? statTheme.bg : 'bg-green-100 dark:bg-green-900/30' 
      },
      { 
          label: 'مغادرة اليوم', 
          value: checkOuts, 
          icon: LogOut, 
          color: statTheme ? statTheme.color : 'text-orange-500', 
          bg: statTheme ? statTheme.bg : 'bg-orange-100 dark:bg-orange-900/30' 
      },
      { 
          label: 'تحت الصيانة', 
          value: maintenanceRooms, 
          icon: AlertTriangle, 
          color: statTheme ? statTheme.color : 'text-red-500', 
          bg: statTheme ? statTheme.bg : 'bg-red-100 dark:bg-red-900/30' 
      },
  ];

  return (
    <div className="space-y-8 pb-20 animate-fade-in">
        <PageHeader pageKey="dashboard" defaultTitle="لوحة المعلومات العامة" icon={LayoutGrid} />
        
        {/* Violation Alert Banner - Only for Operations/Managers */}
        {activeIncidents > 0 && canAccessOperations && (
            <button 
                onClick={() => navigate('operations')}
                className="w-full bg-red-600 text-white p-4 rounded-[2rem] shadow-lg flex items-center justify-between animate-pulse hover:bg-red-700 transition"
            >
                <div className="flex items-center gap-3">
                    <div className="bg-white/20 p-2 rounded-full"><AlertOctagon size={24}/></div>
                    <div className="text-right">
                        <h4 className="font-bold text-lg">تنبيهات نشطة</h4>
                        <p className="text-xs opacity-90">يوجد {activeIncidents} مخالفات أو أضرار تتطلب المعالجة</p>
                    </div>
                </div>
                <div className="bg-white/20 px-4 py-2 rounded-xl font-black text-xl">{activeIncidents}</div>
            </button>
        )}

        {/* Department Alliance Hub (New) */}
        <div className={`p-6 rounded-[2.5rem] border shadow-sm ${ts.card} relative overflow-hidden`}>
            {isZelligeDark && <div className={`absolute inset-0 ${getZelligePatternClass()} opacity-10 pointer-events-none mix-blend-screen`}></div>}
            <div className="flex justify-between items-center mb-4 relative z-10">
                <h3 className={`text-lg font-black flex items-center gap-2 ${ts.text}`}>
                    <div className={`p-2 rounded-xl ${ts.iconBox}`}><Briefcase size={18}/></div>
                    التحالف الخدماتي: {myDept === 'food_beverage' ? 'المطعم والمقهى' : myDept === 'reception' ? 'الاستقبال' : myDept === 'housekeeping' ? 'التنظيف' : myDept === 'maintenance' ? 'الصيانة' : 'الإدارة'}
                </h3>
                {isHead && <span className={`text-xs font-bold px-2 py-1 rounded-lg border ${isZelligeDark ? 'bg-[#cca43b]/20 text-[#cca43b] border-[#cca43b]/40' : 'bg-yellow-100 text-yellow-800 border-yellow-200'}`}>رئيس القطاع</span>}
            </div>
            


  // ... (rest of the code)

            {/* Quick Actions Grid based on Department */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4 relative z-10">
                {myDept === 'reception' && (
                    <>
                        <button onClick={() => navigate('accommodation')} className={`p-3 rounded-xl font-bold text-xs transition flex flex-col items-center gap-2 ${quickActionClass || 'bg-blue-50 text-blue-700 hover:bg-blue-100'}`}>
                            <BedDouble size={20}/> حجز جديد
                        </button>
                        <button onClick={() => navigate('requests')} className={`p-3 rounded-xl font-bold text-xs transition flex flex-col items-center gap-2 ${quickActionClass || 'bg-purple-50 text-purple-700 hover:bg-purple-100'}`}>
                            <MessageSquare size={20}/> طلبات الضيوف
                        </button>
                        <button onClick={() => navigate('invoices')} className={`p-3 rounded-xl font-bold text-xs transition flex flex-col items-center gap-2 ${quickActionClass || 'bg-green-50 text-green-700 hover:bg-green-100'}`}>
                            <DollarSign size={20}/> الفواتير
                        </button>
                    </>
                )}
                {myDept === 'food_beverage' && (
                    <>
                        <button onClick={() => navigate('restaurant')} className={`p-3 rounded-xl font-bold text-xs transition flex flex-col items-center gap-2 ${quickActionClass || 'bg-orange-50 text-orange-700 hover:bg-orange-100'}`}>
                            <Utensils size={20}/> طلب جديد
                        </button>
                        <button onClick={() => navigate('cafe')} className={`p-3 rounded-xl font-bold text-xs transition flex flex-col items-center gap-2 ${quickActionClass || 'bg-amber-50 text-amber-700 hover:bg-amber-100'}`}>
                            <ShoppingBag size={20}/> طلبات المقهى
                        </button>
                    </>
                )}
                {myDept === 'housekeeping' && (
                    <>
                        <button onClick={() => navigate('operations')} className={`p-3 rounded-xl font-bold text-xs transition flex flex-col items-center gap-2 ${quickActionClass || 'bg-cyan-50 text-cyan-700 hover:bg-cyan-100'}`}>
                            <CheckCircle size={20}/> غرفي (للتنظيف)
                        </button>
                        <button onClick={() => navigate('operations')} className={`p-3 rounded-xl font-bold text-xs transition flex flex-col items-center gap-2 ${quickActionClass || 'bg-red-50 text-red-700 hover:bg-red-100'}`}>
                            <AlertTriangle size={20}/> الإبلاغ عن عطل
                        </button>
                    </>
                )}
                {myDept === 'maintenance' && (
                    <>
                        <button onClick={() => navigate('operations')} className={`p-3 rounded-xl font-bold text-xs transition flex flex-col items-center gap-2 ${quickActionClass || 'bg-slate-50 text-slate-700 hover:bg-slate-100'}`}>
                            <Briefcase size={20}/> تذاكر الصيانة
                        </button>
                    </>
                )}
                 {myDept === 'management' && (
                    <>
                        <button onClick={() => navigate('accounting')} className={`p-3 rounded-xl font-bold text-xs transition flex flex-col items-center gap-2 ${quickActionClass || 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'}`}>
                            <PieIcon size={20}/> التقارير المالية
                        </button>
                        <button onClick={() => navigate('staff')} className={`p-3 rounded-xl font-bold text-xs transition flex flex-col items-center gap-2 ${quickActionClass || 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100'}`}>
                            <Users size={20}/> شؤون الموظفين
                        </button>
                    </>
                )}
            </div>

            <div className={`flex gap-4 relative z-10 border-t pt-4 ${isZelligeDark ? 'border-[#cca43b]/20' : 'border-gray-100 dark:border-gray-700'}`}>
                {isHead ? (
                    <button onClick={handleTeamBroadcast} className={`flex-1 py-3 rounded-xl font-bold shadow-md transition transform active:scale-95 flex items-center justify-center gap-2 ${ts.button}`}>
                        <Send size={18}/> توجيه للفريق
                    </button>
                ) : (
                    <button onClick={handleReportToHead} className={`flex-1 py-3 rounded-xl font-bold shadow-md transition transform active:scale-95 flex items-center justify-center gap-2 ${ts.button}`}>
                        <MessageSquare size={18}/> تقرير لرئيس القطاع
                    </button>
                )}
                <div className={`flex-1 rounded-xl p-3 flex items-center justify-between border cursor-pointer transition ${isZelligeDark ? 'bg-[#002a2d] border-[#cca43b]/30 hover:bg-[#cca43b]/10' : 'bg-gray-50 dark:bg-gray-700/50 border-gray-100 dark:border-gray-600 hover:bg-gray-100'}`} onClick={() => setShowTeamModal(true)}>
                    <span className={`text-xs font-bold opacity-70 ${ts.subText}`}>فريق العمل</span>
                    <span className={`text-xs font-black flex items-center gap-1 ${isZelligeDark ? 'text-[#cca43b]' : 'text-green-600'}`}><Users size={12}/> عرض</span>
                </div>
            </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {stats.map((stat, i) => (
                <div key={i} className={`p-6 rounded-[2rem] shadow-sm transition-all duration-300 ${ts.card} flex flex-col items-center justify-center text-center group relative overflow-hidden`}>
                    {isZelligeDark && <div className={`absolute inset-0 ${getZelligePatternClass()} opacity-20 pointer-events-none mix-blend-screen`}></div>}
                    <div className={`p-3 rounded-2xl mb-3 transition-transform group-hover:scale-110 relative z-10 ${stat.bg}`}>
                        <stat.icon size={24} className={stat.color} />
                    </div>
                    <span className={`text-3xl font-black mb-1 relative z-10 ${isZelligeDark ? 'text-[#f0c04a]' : ts.text.split(' ')[0]}`}>{stat.value}</span>
                    <span className={`text-xs font-bold uppercase tracking-wider relative z-10 ${isZelligeDark ? 'text-[#cca43b]/80' : 'text-gray-500'}`}>{stat.label}</span>
                </div>
            ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Revenue Chart */}
            <div className={`p-6 rounded-[2.5rem] border shadow-sm ${ts.card} h-80`}>
                <h3 className={`text-lg font-black mb-4 flex items-center gap-2 ${ts.text}`}>
                    <DollarSign size={20} className={isZelligeDark ? 'text-[#cca43b]' : 'text-green-500'}/> الإيرادات (آخر 7 أيام)
                </h3>
                <ResponsiveContainer width="100%" height="85%">
                    <BarChart data={revenueData}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={isZelligeDark ? '#cca43b30' : '#e5e7eb'} />
                        <XAxis dataKey="name" tick={{ fontSize: 10, fill: isZelligeDark ? '#cca43b' : '#666' }} axisLine={false} tickLine={false} />
                        <YAxis tick={{ fontSize: 10, fill: isZelligeDark ? '#cca43b' : '#666' }} axisLine={false} tickLine={false} />
                        <Tooltip 
                            contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)', backgroundColor: isZelligeDark ? '#002a2d' : '#fff', color: isZelligeDark ? '#cca43b' : '#000' }}
                            cursor={{ fill: isZelligeDark ? 'rgba(204,164,59,0.1)' : 'rgba(0,0,0,0.05)' }}
                        />
                        <Bar dataKey="amount" fill={ts.chartBar} radius={[4, 4, 0, 0]} barSize={30} />
                    </BarChart>
                </ResponsiveContainer>
            </div>

            {/* Occupancy Pie Chart */}
            <div className={`p-6 rounded-[2.5rem] border shadow-sm ${ts.card} h-80`}>
                <h3 className={`text-lg font-black mb-4 flex items-center gap-2 ${ts.text}`}>
                    <PieIcon size={20} className={isZelligeDark ? 'text-[#cca43b]' : 'text-blue-500'}/> توزيع حالة الغرف
                </h3>
                <div className="flex items-center justify-center h-[85%]">
                    <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                            <Pie
                                data={roomStatusData}
                                cx="50%"
                                cy="50%"
                                innerRadius={60}
                                outerRadius={80}
                                paddingAngle={5}
                                dataKey="value"
                            >
                                {roomStatusData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={entry.color} />
                                ))}
                            </Pie>
                            <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', backgroundColor: isZelligeDark ? '#002a2d' : '#fff', color: isZelligeDark ? '#cca43b' : '#000' }} />
                            <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ color: isZelligeDark ? '#cca43b' : '#000' }} />
                        </PieChart>
                    </ResponsiveContainer>
                </div>
            </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Services Pulse (New) */}
            <div className={`p-6 rounded-[2.5rem] border shadow-sm ${ts.card}`}>
                <h3 className={`text-lg font-black mb-4 flex items-center gap-2 ${ts.text}`}>
                    <Utensils size={20} className={isZelligeDark ? 'text-[#f0c04a]' : 'text-orange-500'}/> نبض الخدمات
                </h3>
                <div className="space-y-4">
                    <div className={`flex items-center justify-between p-3 rounded-xl ${isZelligeDark ? 'bg-[#002a2d] border border-[#cca43b]/30' : 'bg-orange-50 dark:bg-orange-900/20'}`}>
                        <div className="flex items-center gap-3">
                            <div className={`p-2 rounded-full shadow-sm ${isZelligeDark ? 'bg-[#cca43b]/10 text-[#f0c04a]' : 'bg-white text-orange-600'}`}><Utensils size={16}/></div>
                            <span className={`text-sm font-bold opacity-80 ${isZelligeDark ? 'text-[#cca43b]' : ''}`}>طلبات المطعم</span>
                        </div>
                        <span className={`text-xl font-black ${isZelligeDark ? 'text-[#f0c04a]' : 'text-orange-600'}`}>{activeRestaurantOrders}</span>
                    </div>
                    <div className={`flex items-center justify-between p-3 rounded-xl ${isZelligeDark ? 'bg-[#002a2d] border border-[#cca43b]/30' : 'bg-purple-50 dark:bg-purple-900/20'}`}>
                        <div className="flex items-center gap-3">
                            <div className={`p-2 rounded-full shadow-sm ${isZelligeDark ? 'bg-[#cca43b]/10 text-[#f0c04a]' : 'bg-white text-purple-600'}`}><Truck size={16}/></div>
                            <span className={`text-sm font-bold opacity-80 ${isZelligeDark ? 'text-[#cca43b]' : ''}`}>توصيل خارجي</span>
                        </div>
                        <span className={`text-xl font-black ${isZelligeDark ? 'text-[#f0c04a]' : 'text-purple-600'}`}>{deliveryOrders}</span>
                    </div>
                    <div className={`flex items-center justify-between p-3 rounded-xl ${isZelligeDark ? 'bg-[#002a2d] border border-[#cca43b]/30' : 'bg-blue-50 dark:bg-blue-900/20'}`}>
                        <div className="flex items-center gap-3">
                            <div className={`p-2 rounded-full shadow-sm ${isZelligeDark ? 'bg-[#cca43b]/10 text-[#f0c04a]' : 'bg-white text-blue-600'}`}><ShoppingBag size={16}/></div>
                            <span className={`text-sm font-bold opacity-80 ${isZelligeDark ? 'text-[#cca43b]' : ''}`}>خدمات أخرى</span>
                        </div>
                        <span className={`text-xl font-black ${isZelligeDark ? 'text-[#f0c04a]' : 'text-blue-600'}`}>{activeExternalOrders}</span>
                    </div>
                </div>
                {canAccessExternal && (
                    <button onClick={() => navigate('external_services')} className={`w-full mt-4 py-3 rounded-xl font-bold text-sm transition ${isZelligeDark ? 'bg-[#cca43b]/10 text-[#f0c04a] hover:bg-[#cca43b]/20' : 'bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600'}`}>
                        إدارة الخدمات الخارجية
                    </button>
                )}
            </div>

            {/* Quick Overview Panel */}
            <div className={`p-6 rounded-[2.5rem] border shadow-sm ${ts.card}`}>
                <h3 className={`text-lg font-black mb-4 flex items-center gap-2 ${ts.text}`}>
                    <Clock size={20} className={isZelligeDark ? 'text-[#f0c04a]' : 'text-gray-400'}/> حالة الغرف الآن
                </h3>
                <div className="flex gap-2 mb-4">
                    <div className={`flex-1 rounded-xl p-4 text-center ${isZelligeDark ? 'bg-[#002a2d] border border-[#cca43b]/30' : 'bg-green-100 dark:bg-green-900/20'}`}>
                        <span className={`block text-2xl font-black ${isZelligeDark ? 'text-[#f0c04a]' : 'text-green-600'}`}>{rooms.filter(r => r.status === 'available').length}</span>
                        <span className={`text-xs font-bold ${isZelligeDark ? 'text-[#cca43b]' : 'text-green-700'}`}>متاحة</span>
                    </div>
                    <div className={`flex-1 rounded-xl p-4 text-center ${isZelligeDark ? 'bg-[#002a2d] border border-[#cca43b]/30' : 'bg-red-100 dark:bg-red-900/20'}`}>
                        <span className={`block text-2xl font-black ${isZelligeDark ? 'text-[#f0c04a]' : 'text-red-600'}`}>{rooms.filter(r => r.status === 'dirty').length}</span>
                        <span className={`text-xs font-bold ${isZelligeDark ? 'text-[#cca43b]' : 'text-red-700'}`}>للتنظيف</span>
                    </div>
                </div>
                {canAccessAccommodation && (
                    <button onClick={() => navigate('accommodation')} className={`w-full py-3 rounded-xl font-bold text-sm transition ${isZelligeDark ? 'bg-[#cca43b]/10 text-[#f0c04a] hover:bg-[#cca43b]/20' : 'bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600'}`}>
                        إدارة الإقامة والغرف
                    </button>
                )}
            </div>

            {/* Maintenance & Incidents Summary */}
            <div className={`p-6 rounded-[2.5rem] border shadow-sm ${ts.card}`}>
                <h3 className={`text-lg font-black mb-4 flex items-center gap-2 ${ts.text}`}>
                    <AlertTriangle size={20} className={isZelligeDark ? 'text-[#cca43b]' : 'text-gray-400'}/> العمليات والطوارئ
                </h3>
                {maintenanceTickets.filter(t => t.status !== 'resolved').length === 0 && incidentReports.filter(i=>i.status==='reported').length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-6 text-gray-400">
                        <CheckCircle size={48} className="mb-2 opacity-20"/>
                        <p className="text-sm font-bold">كل شيء تحت السيطرة</p>
                    </div>
                ) : (
                    <div className="space-y-3">
                        {incidentReports.filter(i => i.status === 'reported').slice(0, 2).map(inc => (
                            <div key={inc.id} className={`flex justify-between items-center p-3 rounded-xl border ${isZelligeDark ? 'bg-[#3d0b0b] border-red-900/50' : 'bg-red-50 border-red-100'}`}>
                                <div>
                                    <span className="text-xs font-black block text-red-600">{inc.title}</span>
                                    <span className="text-[10px] text-red-500">{inc.location}</span>
                                </div>
                                <span className="bg-red-200 text-red-800 px-2 py-1 rounded text-[10px] font-bold">مخالفة</span>
                            </div>
                        ))}
                        {maintenanceTickets.filter(t => t.status !== 'resolved').slice(0, 2).map(ticket => (
                            <div key={ticket.id} className={`flex justify-between items-center p-3 rounded-xl border ${isZelligeDark ? 'bg-[#002a2d] border-[#cca43b]/30' : 'bg-gray-50 dark:bg-gray-900/50 border-gray-100 dark:border-gray-700'}`}>
                                <div>
                                    <span className={`text-xs font-black block ${isZelligeDark ? 'text-[#cca43b]' : ''}`}>غرفة {rooms.find(r => r.id === ticket.roomId)?.number}</span>
                                    <span className={`text-[10px] ${isZelligeDark ? 'text-[#cca43b]/70' : 'text-gray-500'}`}>{ticket.description}</span>
                                </div>
                                <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${ticket.priority === 'critical' ? 'bg-red-100 text-red-600' : 'bg-orange-100 text-orange-600'}`}>
                                    {ticket.priority}
                                </span>
                            </div>
                        ))}
                    </div>
                )}
                {canAccessOperations && (
                    <button onClick={() => navigate('operations')} className={`w-full mt-4 py-3 rounded-xl font-bold text-sm transition ${isZelligeDark ? 'bg-[#cca43b]/10 text-[#f0c04a] hover:bg-[#cca43b]/20' : 'bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600'}`}>
                        مركز العمليات
                    </button>
                )}
            </div>
        </div>
        {/* Team Modal */}
        <Modal
            isOpen={showTeamModal}
            onClose={() => setShowTeamModal(false)}
            title={`فريق ${myDept === 'food_beverage' ? 'المطعم' : myDept === 'reception' ? 'الاستقبال' : myDept === 'housekeeping' ? 'التنظيف' : myDept === 'maintenance' ? 'الصيانة' : 'الإدارة'}`}
            icon={Users}
        >
            <div className="space-y-4">
                {users.filter(u => u.department === myDept || (myDept === 'management' && u.role === 'manager')).map(member => (
                    <div key={member.id} className={`flex items-center justify-between p-4 rounded-2xl border ${settings.darkMode && settings.theme === 'zellige' ? 'bg-[#001e21] border-[#cca43b]/20' : settings.theme === 'zellige' ? 'bg-[#fbf8f1] border-[#cca43b]/20' : 'bg-gray-50 dark:bg-gray-700/50 border-gray-100 dark:border-gray-600'}`}>
                        <div className="flex items-center gap-3">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-white ${member.isHeadOfDepartment ? 'bg-yellow-500' : 'bg-gray-400'}`}>
                                {member.name.charAt(0)}
                            </div>
                            <div>
                                <h4 className="font-bold">{member.name}</h4>
                                <p className="text-xs opacity-60">{member.role === 'manager' ? 'مدير' : member.role}</p>
                            </div>
                        </div>
                        <div className="flex gap-2">
                            <button className={`p-2 rounded-lg transition ${settings.darkMode && settings.theme === 'zellige' ? 'bg-[#cca43b]/10 text-[#cca43b] hover:bg-[#cca43b]/20' : 'bg-green-100 text-green-600 hover:bg-green-200'}`} title="اتصال"><Phone size={16}/></button>
                            <button className={`p-2 rounded-lg transition ${settings.darkMode && settings.theme === 'zellige' ? 'bg-[#cca43b]/10 text-[#cca43b] hover:bg-[#cca43b]/20' : 'bg-blue-100 text-blue-600 hover:bg-blue-200'}`} title="رسالة"><MessageSquare size={16}/></button>
                        </div>
                    </div>
                ))}
                {users.filter(u => u.department === myDept).length === 0 && (
                    <p className="text-center text-gray-400 py-8">لا يوجد أعضاء آخرين في هذا القسم حالياً.</p>
                )}
            </div>
        </Modal>

        {/* Message Modal */}
        <Modal
            isOpen={messageModal.isOpen}
            onClose={() => setMessageModal({ isOpen: false, type: null })}
            title={messageModal.type === 'broadcast' ? 'توجيه للفريق' : 'تقرير لرئيس القسم'}
            size="sm"
        >
            <div className="space-y-4">
                <p className="text-sm opacity-70">
                    {messageModal.type === 'broadcast' 
                        ? 'أرسل رسالة فورية لجميع أعضاء فريقك. ستظهر كإشعار هام.' 
                        : 'أرسل تقريراً سريعاً أو ملاحظة لرئيس القسم والإدارة.'}
                </p>
                <textarea
                    className={`w-full p-4 rounded-xl border-2 outline-none min-h-[120px] ${ts.input}`}
                    placeholder="اكتب رسالتك هنا..."
                    value={messageText}
                    onChange={e => setMessageText(e.target.value)}
                    autoFocus
                />
                <div className="flex justify-end gap-2">
                    <button 
                        onClick={() => setMessageModal({ isOpen: false, type: null })}
                        className={`px-4 py-2 rounded-xl font-bold opacity-70 hover:opacity-100 ${isZelligeDark ? 'text-[#cca43b]' : 'text-gray-500'}`}
                    >
                        إلغاء
                    </button>
                    <button 
                        onClick={handleSendMessage}
                        disabled={!messageText.trim()}
                        className={`px-6 py-2 rounded-xl font-bold shadow-lg flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed ${ts.button}`}
                    >
                        <Send size={16}/> إرسال
                    </button>
                </div>
            </div>
        </Modal>
    </div>
  );
};
