import React, { useState } from 'react';
import { useHotel } from '../context/HotelContext';
import { PageHeader } from '../components/PageHeader';
import { Shield, Check, Save, Users } from 'lucide-react';
import { Role } from '../types';

const PERMISSIONS_LIST = [
    { key: 'canManageRooms', label: 'إدارة الغرف' },
    { key: 'canManageBookings', label: 'إدارة الحجوزات' },
    { key: 'canViewSecurityLink', label: 'الرابط الأمني' },
    { key: 'canManageInvoices', label: 'إدارة الفواتير' },
    { key: 'canViewAccounting', label: 'عرض المحاسبة' },
    { key: 'canManageFinance', label: 'إدارة المالية' },
    { key: 'canManageStaff', label: 'إدارة الموظفين' },
    { key: 'canManageSettings', label: 'إعدادات النظام' },
    { key: 'canManageMenu', label: 'إدارة القائمة' },
    { key: 'canManageServices', label: 'إدارة الخدمات' },
    { key: 'canUseChat', label: 'استخدام المحادثة' },
    { key: 'canBroadcast', label: 'إرسال تعاميم' },
    { key: 'canCustomizeTitles', label: 'تخصيص العناوين' },
    { key: 'canClearSettlements', label: 'تصفية الحسابات' },
];

const ROLES: { id: Role; label: string; level: number }[] = [
    { id: 'manager', label: 'المدير العام', level: 1 },
    { id: 'assistant_manager', label: 'مساعد المدير', level: 2 },
    { id: 'operations_manager', label: 'مدير العمليات', level: 2 },
    { id: 'reception_manager', label: 'مدير الاستقبال', level: 3 },
    { id: 'restaurant_manager', label: 'مدير المطعم', level: 3 },
    { id: 'cafe_manager', label: 'مدير المقهى', level: 3 },
    { id: 'housekeeping_manager', label: 'مدير التدبير المنزلي', level: 3 },
    { id: 'maintenance_manager', label: 'مدير الصيانة', level: 3 },
    { id: 'security_manager', label: 'مدير الأمن', level: 3 },
    { id: 'hr_manager', label: 'مدير الموارد البشرية', level: 3 },
    { id: 'accountant', label: 'المحاسب', level: 3 },
    { id: 'marketing_specialist', label: 'مسؤول التسويق', level: 3 },
    { id: 'it_specialist', label: 'مسؤول IT', level: 3 },
    { id: 'head_chef', label: 'كبير الطهاة', level: 3 },
    { id: 'receptionist', label: 'موظف استقبال', level: 4 },
    { id: 'concierge', label: 'كونسيرج', level: 4 },
    { id: 'chef', label: 'طاهي', level: 4 },
    { id: 'waiter', label: 'نادل', level: 4 },
    { id: 'barista', label: 'باريستا', level: 4 },
    { id: 'housekeeping_staff', label: 'عامل نظافة', level: 4 },
    { id: 'maintenance_staff', label: 'فني صيانة', level: 4 },
    { id: 'security_guard', label: 'حارس أمن', level: 4 },
    { id: 'bellboy', label: 'حامل الحقائب', level: 4 },
    { id: 'driver', label: 'سائق', level: 4 },
    { id: 'staff', label: 'موظف عام', level: 4 },
];

export const PermissionsPage: React.FC = () => {
    const { currentUser, addNotification, settings } = useHotel();
    
    // Initialize permissions for all roles
    const [rolePermissions, setRolePermissions] = useState<Record<Role, string[]>>(() => {
        const initial: any = {};
        ROLES.forEach(role => {
            if (role.id === 'manager') initial[role.id] = PERMISSIONS_LIST.map(p => p.key);
            else if (role.level === 2) initial[role.id] = PERMISSIONS_LIST.map(p => p.key).filter(k => k !== 'canManageSettings');
            else if (role.level === 3) initial[role.id] = ['canManageStaff', 'canUseChat', 'canBroadcast']; // Basic manager perms
            else initial[role.id] = ['canUseChat']; // Basic staff perms
        });
        
        // Specific overrides
        initial['reception_manager'] = [...initial['reception_manager'], 'canManageRooms', 'canManageBookings', 'canViewSecurityLink', 'canManageInvoices'];
        initial['receptionist'] = ['canManageRooms', 'canManageBookings', 'canUseChat', 'canViewSecurityLink'];
        initial['restaurant_manager'] = [...initial['restaurant_manager'], 'canManageMenu', 'canManageServices'];
        initial['cafe_manager'] = [...initial['cafe_manager'], 'canManageMenu', 'canManageServices'];
        initial['head_chef'] = ['canManageMenu'];
        initial['accountant'] = ['canViewAccounting', 'canManageFinance', 'canManageInvoices', 'canClearSettlements'];
        initial['it_specialist'] = ['canManageSettings', 'canUseChat'];
        
        return initial;
    });

    const getThemeStyles = () => {
        switch (settings.theme) {
            case 'zellige': return {
                card: 'bg-[#FDFBF7] border-[#cca43b]',
                headerText: 'text-[#006269]',
                button: 'bg-[#006269] text-[#cca43b] hover:bg-[#004d53]',
                tableHeader: 'bg-[#FDFBF7] text-[#006269] border-[#cca43b]/20',
                tableRowEven: 'bg-[#FDFBF7]',
                tableRowOdd: 'bg-[#fbf8f1]',
                checkboxActive: 'bg-[#006269] border-[#006269]',
                checkboxInactive: 'border-[#cca43b]/40',
                level1: 'bg-[#006269] text-[#cca43b] border-[#cca43b]',
                level2: 'bg-[#004d53] text-[#cca43b]',
                level3: 'bg-[#cca43b] text-[#006269]',
                level4: 'bg-[#fbf8f1] text-[#006269] border-[#cca43b]/20',
            };
            default: return {
                card: 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700',
                headerText: 'text-blue-600',
                button: 'bg-blue-600 text-white hover:bg-blue-700',
                tableHeader: 'bg-gray-50 dark:bg-gray-800 text-gray-500',
                tableRowEven: 'bg-white dark:bg-gray-800',
                tableRowOdd: 'bg-gray-50/30 dark:bg-gray-800/30',
                checkboxActive: 'bg-blue-600 border-blue-600',
                checkboxInactive: 'border-gray-300 dark:border-gray-500',
                level1: 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white border-white dark:border-gray-700',
                level2: 'bg-blue-600 text-white',
                level3: 'bg-teal-500 text-white',
                level4: 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 border-gray-200 dark:border-gray-600',
            };
        }
    };
    const ts = getThemeStyles();

    const togglePermission = (role: Role, permKey: string) => {
        setRolePermissions(prev => {
            const currentPerms = prev[role] || [];
            if (currentPerms.includes(permKey)) {
                return { ...prev, [role]: currentPerms.filter(k => k !== permKey) };
            } else {
                return { ...prev, [role]: [...currentPerms, permKey] };
            }
        });
    };

    const handleSave = () => {
        // In a real app, this would save to backend/context
        addNotification('تم تحديث صلاحيات الأدوار بنجاح', 'success');
    };

    if (currentUser?.role !== 'manager') {
        return <div className="p-10 text-center font-bold text-red-500">عذراً، هذه الصفحة مخصصة للمدير العام فقط.</div>;
    }

    return (
        <div className="space-y-6 pb-20 animate-fade-in">
            <PageHeader pageKey="permissions" defaultTitle="إدارة الصلاحيات والأدوار" icon={Shield} />

            <div className={`rounded-[2.5rem] p-6 shadow-sm border overflow-hidden mb-8 ${ts.card}`}>
                <h3 className={`font-black text-xl flex items-center gap-2 mb-6 ${ts.headerText}`}>
                    <Users size={24}/> الهرم الوظيفي (Organizational Chart)
                </h3>
                <div className="flex flex-col items-center gap-8 py-8 overflow-x-auto">
                    {/* Level 1 */}
                    <div className="flex justify-center w-full">
                        {ROLES.filter(r => r.level === 1).map(role => (
                            <div key={role.id} className={`px-8 py-4 rounded-2xl text-center shadow-lg font-black text-lg transform hover:scale-105 transition cursor-pointer border-4 ${ts.level1}`}>
                                {role.label}
                            </div>
                        ))}
                    </div>
                    
                    <div className="h-8 w-0.5 bg-gray-300"></div>
                    
                    {/* Level 2 */}
                    <div className="flex gap-6 justify-center w-full flex-wrap">
                        {ROLES.filter(r => r.level === 2).map(role => (
                            <div key={role.id} className={`px-6 py-3 rounded-xl text-center shadow-md font-bold transform hover:scale-105 transition cursor-pointer min-w-[140px] ${ts.level2}`}>
                                {role.label}
                            </div>
                        ))}
                    </div>

                    <div className="h-8 w-0.5 bg-gray-300"></div>

                    {/* Level 3 */}
                    <div className="flex gap-4 justify-center w-full flex-wrap max-w-5xl">
                        {ROLES.filter(r => r.level === 3).map(role => (
                            <div key={role.id} className={`px-4 py-2 rounded-lg text-center shadow-sm font-bold text-sm transform hover:scale-105 transition cursor-pointer min-w-[120px] ${ts.level3}`}>
                                {role.label}
                            </div>
                        ))}
                    </div>

                    <div className="h-8 w-0.5 bg-gray-300"></div>

                    {/* Level 4 */}
                    <div className="flex gap-3 justify-center w-full flex-wrap max-w-6xl">
                        {ROLES.filter(r => r.level === 4).map(role => (
                            <div key={role.id} className={`px-3 py-1.5 rounded-lg text-center border font-bold text-xs hover:opacity-80 transition cursor-pointer ${ts.level4}`}>
                                {role.label}
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            <div className={`rounded-[2.5rem] p-6 shadow-sm border overflow-hidden ${ts.card}`}>
                <div className="flex items-center justify-between mb-6">
                    <h3 className={`font-black text-xl flex items-center gap-2 ${ts.headerText}`}>
                        <Users size={24}/> جدول الصلاحيات
                    </h3>
                    <button onClick={handleSave} className={`px-6 py-3 rounded-xl font-bold flex items-center gap-2 transition ${ts.button}`}>
                        <Save size={18}/> حفظ التغييرات
                    </button>
                </div>

                <div className="overflow-x-auto custom-scrollbar pb-4">
                    <table className="w-full min-w-[1200px]">
                        <thead>
                            <tr className={`border-b ${ts.tableHeader}`}>
                                <th className={`p-4 text-right font-black text-sm sticky right-0 z-10 min-w-[200px] ${ts.tableHeader}`}>الصلاحية / الدور</th>
                                {ROLES.map(role => (
                                    <th key={role.id} className="p-4 text-center font-bold text-xs whitespace-nowrap min-w-[100px] vertical-text">
                                        <div className="writing-mode-vertical transform rotate-180 h-32 flex items-center justify-center w-full">
                                            {role.label}
                                        </div>
                                    </th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {PERMISSIONS_LIST.map((perm, idx) => (
                                <tr key={perm.key} className={`border-b hover:opacity-90 transition ${idx % 2 === 0 ? ts.tableRowEven : ts.tableRowOdd}`}>
                                    <td className={`p-4 font-bold text-sm sticky right-0 z-10 border-l ${idx % 2 === 0 ? ts.tableRowEven : ts.tableRowOdd}`}>
                                        {perm.label}
                                    </td>
                                    {ROLES.map(role => {
                                        const isChecked = rolePermissions[role]?.includes(perm.key);
                                        return (
                                            <td key={role.id} className="p-2 text-center">
                                                <label className="inline-flex items-center justify-center cursor-pointer p-1 rounded-lg hover:bg-black/5 transition">
                                                    <input 
                                                        type="checkbox" 
                                                        className="hidden" 
                                                        checked={isChecked} 
                                                        onChange={() => togglePermission(role.id, perm.key)}
                                                    />
                                                    <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center transition-all duration-200 ${isChecked ? `${ts.checkboxActive} text-white` : `${ts.checkboxInactive} text-transparent`}`}>
                                                        <Check size={12} strokeWidth={4} />
                                                    </div>
                                                </label>
                                            </td>
                                        );
                                    })}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};
