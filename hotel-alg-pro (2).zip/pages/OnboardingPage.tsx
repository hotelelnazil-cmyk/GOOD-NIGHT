import React, { useState } from 'react';
import { useHotel } from '../context/HotelContext';
import { User, Role, Department, AppSettings } from '../types';
import { Building2, UserPlus, Settings, CheckCircle, ArrowLeft, ArrowRight } from 'lucide-react';

const OnboardingPage: React.FC = () => {
    const { addStaff, updateSettings, settings, login } = useHotel();
    const [step, setStep] = useState(1);
    const [formData, setFormData] = useState({
        hotelName: '',
        hotelAddress: '',
        totalRooms: 50,
        adminName: '',
        adminPassword: '',
        currency: 'DZD'
    });

    const handleNext = () => setStep(prev => prev + 1);
    const handleBack = () => setStep(prev => prev - 1);

    const handleFinish = async () => {
        // 1. Update Settings
        updateSettings({
            appName: formData.hotelName,
            hotelAddress: formData.hotelAddress,
            totalRooms: formData.totalRooms,
            currency: formData.currency
        });

        // 2. Create Admin User
        const adminId = `admin-${Date.now()}`;
        // Note: addStaff generates ID internally, but we need to log in.
        // We'll use a slightly modified approach or just assume the first user created is admin.
        // The addStaff function in context: addStaff(name, role, department, isHead, salary, accessCode)
        
        addStaff(
            formData.adminName,
            'manager',
            'administration',
            true,
            100000,
            formData.adminPassword
        );

        // We need to find the user we just created to log them in. 
        // Since state updates are async, we might need to wait or rely on a different flow.
        // For now, let's show a success message and ask them to login.
        // Or better, we can't easily get the ID back from addStaff as it's void.
        // Let's just redirect to login page (which will now show users).
        
        window.location.reload(); // Reload to trigger the "User Exists" state in App.tsx
    };

    return (
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center p-4" dir="rtl">
            <div className="max-w-2xl w-full bg-white dark:bg-gray-800 rounded-3xl shadow-xl overflow-hidden">
                <div className="bg-primary/10 p-8 text-center">
                    <h1 className="text-3xl font-bold text-primary mb-2">مرحباً بك في منصة التسيير الفندقي</h1>
                    <p className="text-gray-600 dark:text-gray-400">دعنا نقم بإعداد مساحة العمل الخاصة بك في خطوات بسيطة</p>
                </div>

                <div className="p-8">
                    {/* Progress Steps */}
                    <div className="flex justify-between mb-8 relative">
                        <div className="absolute top-1/2 left-0 right-0 h-1 bg-gray-200 dark:bg-gray-700 -z-10 transform -translate-y-1/2"></div>
                        {[1, 2, 3].map(i => (
                            <div key={i} className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-colors ${step >= i ? 'bg-primary text-white' : 'bg-gray-200 dark:bg-gray-700 text-gray-500'}`}>
                                {i}
                            </div>
                        ))}
                    </div>

                    {step === 1 && (
                        <div className="space-y-6 animate-fadeIn">
                            <div className="text-center mb-6">
                                <Building2 size={48} className="mx-auto text-primary mb-4" />
                                <h2 className="text-xl font-bold">بيانات المؤسسة</h2>
                            </div>
                            
                            <div>
                                <label className="block text-sm font-medium mb-2">اسم الفندق / المؤسسة</label>
                                <input 
                                    type="text" 
                                    value={formData.hotelName}
                                    onChange={e => setFormData({...formData, hotelName: e.target.value})}
                                    className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 focus:ring-2 focus:ring-primary/20 outline-none"
                                    placeholder="مثال: فندق الجزائر الكبير"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium mb-2">العنوان</label>
                                <input 
                                    type="text" 
                                    value={formData.hotelAddress}
                                    onChange={e => setFormData({...formData, hotelAddress: e.target.value})}
                                    className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 focus:ring-2 focus:ring-primary/20 outline-none"
                                    placeholder="الجزائر العاصمة، الجزائر"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium mb-2">عدد الغرف / الوحدات</label>
                                <input 
                                    type="number" 
                                    value={formData.totalRooms}
                                    onChange={e => setFormData({...formData, totalRooms: parseInt(e.target.value)})}
                                    className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 focus:ring-2 focus:ring-primary/20 outline-none"
                                />
                            </div>
                        </div>
                    )}

                    {step === 2 && (
                        <div className="space-y-6 animate-fadeIn">
                            <div className="text-center mb-6">
                                <UserPlus size={48} className="mx-auto text-primary mb-4" />
                                <h2 className="text-xl font-bold">حساب المدير العام</h2>
                            </div>

                            <div>
                                <label className="block text-sm font-medium mb-2">الاسم الكامل</label>
                                <input 
                                    type="text" 
                                    value={formData.adminName}
                                    onChange={e => setFormData({...formData, adminName: e.target.value})}
                                    className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 focus:ring-2 focus:ring-primary/20 outline-none"
                                    placeholder="الاسم واللقب"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium mb-2">رمز الدخول (PIN)</label>
                                <input 
                                    type="password" 
                                    value={formData.adminPassword}
                                    onChange={e => setFormData({...formData, adminPassword: e.target.value})}
                                    className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 focus:ring-2 focus:ring-primary/20 outline-none"
                                    placeholder="****"
                                />
                                <p className="text-xs text-gray-500 mt-1">سيتم استخدام هذا الرمز لتسجيل الدخول.</p>
                            </div>
                        </div>
                    )}

                    {step === 3 && (
                        <div className="space-y-6 animate-fadeIn text-center">
                            <CheckCircle size={64} className="mx-auto text-green-500 mb-4" />
                            <h2 className="text-2xl font-bold">جاهز للانطلاق!</h2>
                            <p className="text-gray-600 dark:text-gray-400">
                                تم حفظ البيانات بنجاح. يمكنك الآن البدء في استخدام المنصة وإضافة باقي الموظفين والخدمات من لوحة التحكم.
                            </p>
                            
                            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-xl text-sm text-blue-800 dark:text-blue-200 mt-4">
                                <strong>تلميح:</strong> يمكنك دائماً تغيير هذه الإعدادات لاحقاً من صفحة الإعدادات.
                            </div>
                        </div>
                    )}

                    {/* Actions */}
                    <div className="flex justify-between mt-8 pt-6 border-t border-gray-100 dark:border-gray-700">
                        {step > 1 && (
                            <button 
                                onClick={handleBack}
                                className="px-6 py-2 rounded-xl border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors flex items-center gap-2"
                            >
                                <ArrowRight size={18} />
                                السابق
                            </button>
                        )}
                        
                        {step < 3 ? (
                            <button 
                                onClick={handleNext}
                                disabled={step === 1 ? !formData.hotelName : !formData.adminName || !formData.adminPassword}
                                className="px-6 py-2 rounded-xl bg-primary text-white hover:bg-primary/90 transition-colors flex items-center gap-2 mr-auto disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                التالي
                                <ArrowLeft size={18} />
                            </button>
                        ) : (
                            <button 
                                onClick={handleFinish}
                                className="px-8 py-3 rounded-xl bg-green-600 text-white hover:bg-green-700 transition-colors font-bold shadow-lg shadow-green-600/20 mr-auto"
                            >
                                بدء الاستخدام
                            </button>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default OnboardingPage;
