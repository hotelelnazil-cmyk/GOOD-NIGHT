
import React, { useState, useEffect, useRef } from 'react';
import { useHotel } from '../context/HotelContext';
import { MenuItem } from '../types';
import { parseSecureToken, QRPayload } from '../utils/qrCrypto';
import { 
    Bell, Coffee, Car, Shirt, Sparkles, Utensils, Wifi, CheckCircle, Globe, Send, MessageCircle, Clock, Zap, 
    Menu, ShoppingBag, MapPin, Phone, LogOut, ChevronRight, Star, Heart, CreditCard, Info, Waves, Crown, Plus, Home, PartyPopper, Music, Lightbulb, Settings2, DollarSign, Thermometer, Wind, Flower2, Moon, Sun, Volume2, Power, User, Umbrella, GlassWater, ShieldCheck, Gem, LayoutGrid
} from 'lucide-react';

interface GuestServicesPageProps {
    previewData?: {
        type: 'room' | 'restaurant_table' | 'pool_chair' | 'vip_area' | 'hall';
        id: string;
        name?: string;
    };
}

export const GuestServicesPage: React.FC<GuestServicesPageProps> = ({ previewData }) => {
    const { guestServices, requestService, sendGuestMessage, messages, settings, serviceRequests, menuItems, bookings, hallBookings, toggleGuestPresence, addNotification } = useHotel();
    const [tokenData, setTokenData] = useState<any>(null);
    const [isExpired, setIsExpired] = useState(false);
    const [activeRequest, setActiveRequest] = useState<string | null>(null);
    const [view, setView] = useState<'home' | 'chat' | 'menu' | 'services' | 'controls'>('home');
    const [chatInput, setChatInput] = useState('');
    const [selectedServiceCategory, setSelectedServiceCategory] = useState<'all' | 'housekeeping' | 'food_beverage' | 'spa_wellness' | 'reception'>('all');
    
    // Smart Room State
    const [roomState, setRoomState] = useState({
        dnd: false, // Do Not Disturb
        clean: false, // Make Up Room
        lights: 80, // Dimmer
        temp: 22,
        ac: true
    });

    const inputRef = useRef<HTMLInputElement>(null);

    // --- Cart State ---
    const [cart, setCart] = useState<{ item: MenuItem, quantity: number }[]>([]);
    const [isOrderSubmitting, setIsOrderSubmitting] = useState(false);

    const addToCart = (item: MenuItem) => {
        setCart(prev => {
            const existing = prev.find(i => i.item.id === item.id);
            if (existing) return prev.map(i => i.item.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
            return [...prev, { item, quantity: 1 }];
        });
        triggerHaptic();
    };

    const removeFromCart = (itemId: string) => {
        setCart(prev => prev.filter(i => i.item.id !== itemId));
        triggerHaptic();
    };

    const handlePlaceOrder = () => {
        if (!tokenData || cart.length === 0) return;
        setIsOrderSubmitting(true);
        
        // Create Order Object
        const totalAmount = cart.reduce((acc, curr) => acc + (curr.item.price * curr.quantity), 0);
        const orderType = tokenData.type === 'room' ? 'room_service' : 
                          tokenData.type === 'pool_chair' ? 'pool_side' : 'dine_in';
        
        const newOrder: any = {
            id: `ord-${Date.now()}`,
            items: cart,
            totalAmount,
            status: 'pending',
            type: orderType,
            source: 'restaurant', // Default to restaurant for now, regardless of guest location
            timestamp: new Date().toISOString(),
            notes: `Digital Order via Guest App (${tokenData.type})`,
            // Specific fields based on type
            tableId: tokenData.type === 'restaurant_table' ? tokenData.id : undefined,
            roomNumber: tokenData.type === 'room' ? tokenData.id : undefined,
            customerName: tokenData.name || 'Guest',
        };

        if (tokenData.type === 'pool_chair') {
            newOrder.notes += ` - Location: Pool Chair ${tokenData.id}`;
        }

        // Dispatch Event for HotelContext to pick up
        window.dispatchEvent(new CustomEvent('guest-order-placed', { detail: newOrder }));

        setTimeout(() => {
            setIsOrderSubmitting(false);
            setCart([]);
            addNotification('تم استلام طلبك بنجاح! سيصلك قريباً.', "success");
            setView('home');
        }, 1500);
    };

    const getThemeStyles = () => {
        // Radical Fix: Dark mode overrides all themes for consistency but respects theme identity
        if (settings.darkMode) {
            if (settings.theme === 'zellige') {
                return {
                    container: 'bg-[#001e21]',
                    card: 'bg-[#002a2d] border-[#cca43b]/40',
                    textPrimary: 'text-[#f0c04a] drop-shadow-sm',
                    textSecondary: 'text-[#cca43b]/80',
                    buttonActive: 'bg-[#cca43b] text-[#001e21] border-[#cca43b]',
                    buttonInactive: 'bg-[#002a2d] text-[#cca43b]/60 border-[#cca43b]/20',
                    iconBg: 'bg-[#001012] text-[#f0c04a]',
                    bottomNav: 'bg-[#002a2d]/90 border-[#cca43b]/20',
                    navIconActive: 'text-[#f0c04a]',
                    navIconInactive: 'text-[#cca43b]/40'
                };
            }
            if (settings.theme === 'algerian-military') {
                return {
                    container: 'bg-[#0f140f]',
                    card: 'bg-[#1a211a] border-[#D4AF37]/40',
                    textPrimary: 'text-[#D4AF37]',
                    textSecondary: 'text-[#D4AF37]/70',
                    buttonActive: 'bg-[#D4AF37] text-[#1a211a] border-[#D4AF37]',
                    buttonInactive: 'bg-[#1a211a] text-[#D4AF37]/60 border-[#D4AF37]/30',
                    iconBg: 'bg-[#0f140f] text-[#D4AF37]',
                    bottomNav: 'bg-[#1a211a]/90 border-[#D4AF37]/20',
                    navIconActive: 'text-[#D4AF37]',
                    navIconInactive: 'text-[#D4AF37]/40'
                };
            }
            if (settings.theme === 'modern-ornate') {
                return {
                    container: 'bg-[#1a0524]',
                    card: 'bg-[#2d0b3d] border-[#ffd700]/40',
                    textPrimary: 'text-[#ffd700]',
                    textSecondary: 'text-[#ffd700]/70',
                    buttonActive: 'bg-[#ffd700] text-[#2d0b3d] border-[#ffd700]',
                    buttonInactive: 'bg-[#2d0b3d] text-[#ffd700]/60 border-[#ffd700]/30',
                    iconBg: 'bg-[#1a0524] text-[#ffd700]',
                    bottomNav: 'bg-[#2d0b3d]/90 border-[#ffd700]/20',
                    navIconActive: 'text-[#ffd700]',
                    navIconInactive: 'text-[#ffd700]/40'
                };
            }
            return {
                container: 'bg-gray-900',
                card: 'bg-gray-800 border-gray-700',
                textPrimary: 'text-white',
                textSecondary: 'text-gray-400',
                buttonActive: 'bg-white text-black border-white',
                buttonInactive: 'bg-gray-800 text-gray-500 border-gray-700',
                iconBg: 'bg-gray-700 text-gray-300',
                bottomNav: 'bg-gray-800/90 border-gray-700',
                navIconActive: 'text-white',
                navIconInactive: 'text-gray-500'
            };
        }

        switch (settings.theme) {
            case 'zellige': return {
                container: 'bg-[#FDFBF7]',
                card: 'bg-white border-[#cca43b]/40',
                textPrimary: 'text-[#006269]',
                textSecondary: 'text-[#006269]/70',
                buttonActive: 'bg-[#006269] text-[#cca43b] border-[#cca43b]',
                buttonInactive: 'bg-white text-[#006269] border-[#cca43b]/20',
                iconBg: 'bg-[#fbf8f1] text-[#006269]',
                bottomNav: 'bg-white/90 border-[#cca43b]/20',
                navIconActive: 'text-[#006269]',
                navIconInactive: 'text-[#006269]/40'
            };
            case 'algerian-military': return {
                container: 'bg-[#F0EFEA]',
                card: 'bg-[#E5E5E0] border-[#D4AF37]/40',
                textPrimary: 'text-[#2F3E2E]',
                textSecondary: 'text-[#2F3E2E]/70',
                buttonActive: 'bg-[#2F3E2E] text-[#D4AF37] border-[#D4AF37]',
                buttonInactive: 'bg-[#E5E5E0] text-[#2F3E2E] border-[#D4AF37]/30',
                iconBg: 'bg-[#F0EFEA] text-[#2F3E2E]',
                bottomNav: 'bg-[#E5E5E0]/90 border-[#D4AF37]/20',
                navIconActive: 'text-[#2F3E2E]',
                navIconInactive: 'text-[#2F3E2E]/40'
            };
            case 'modern-ornate': return {
                container: 'bg-[#f3e5f5]',
                card: 'bg-white border-[#ffd700]/40',
                textPrimary: 'text-[#4a148c]',
                textSecondary: 'text-[#4a148c]/70',
                buttonActive: 'bg-[#4a148c] text-[#ffd700] border-[#ffd700]',
                buttonInactive: 'bg-white text-[#4a148c] border-[#ffd700]/30',
                iconBg: 'bg-[#f3e5f5] text-[#4a148c]',
                bottomNav: 'bg-white/90 border-[#ffd700]/20',
                navIconActive: 'text-[#4a148c]',
                navIconInactive: 'text-[#4a148c]/40'
            };
            default: return {
                container: 'bg-gray-50',
                card: 'bg-white border-gray-100',
                textPrimary: 'text-gray-800',
                textSecondary: 'text-gray-500',
                buttonActive: 'bg-black text-white border-black',
                buttonInactive: 'bg-white text-gray-500 border-gray-200',
                iconBg: 'bg-gray-50 text-gray-600',
                bottomNav: 'bg-white/90 border-gray-200',
                navIconActive: 'text-black',
                navIconInactive: 'text-gray-400'
            };
        }
    };
    const ts = getThemeStyles();

    // --- Initialization ---
    useEffect(() => {
        if (previewData) {
            setTokenData(previewData);
            if (previewData.type === 'room') setView('home'); 
        } else {
            const params = new URLSearchParams(window.location.search);
            const token = params.get('token');
            if (token) {
                try {
                    const payload = parseSecureToken(token);
                    if (payload) {
                        if (payload.x && Date.now() > payload.x) {
                            setIsExpired(true);
                        } else {
                            // Map QR Payload to Guest Portal State
                            const mapType = (t: string) => {
                                switch(t) {
                                    case 'ROOM_KEY': return 'room';
                                    case 'TABLE_ORDER': return 'restaurant_table';
                                    case 'POOL_ACCESS': return 'pool_chair';
                                    case 'HALL_EVENT': return 'hall';
                                    case 'VIP_ACCESS': return 'vip_area';
                                    default: return 'room';
                                }
                            };
                            
                            setTokenData({
                                type: mapType(payload.t),
                                id: payload.i,
                                name: payload.n,
                                expiry: payload.x
                            });
                        }
                    } else {
                        // Fallback for legacy tokens if any
                        const decoded = JSON.parse(decodeURIComponent(escape(atob(token))));
                        if (decoded && decoded.type && decoded.id) {
                            setTokenData(decoded);
                        }
                    }
                } catch (e) { console.error("Invalid Token", e); }
            }
        }
    }, [previewData]);

    // --- Interactions ---
    const triggerHaptic = () => {
        if (navigator.vibrate) navigator.vibrate(15);
    };

    const handleRoomControl = (key: keyof typeof roomState, value: any) => {
        triggerHaptic();
        setRoomState(prev => ({ ...prev, [key]: value }));
        // In real app, send to BMS (Building Management System)
    };

    const handleRequest = (serviceId: string, label: string) => {
        if (!tokenData) return;
        triggerHaptic();
        requestService(serviceId, tokenData.type, tokenData.id, previewData ? `(محاكاة)` : `Digital Request`);
        setActiveRequest(serviceId);
        setTimeout(() => setActiveRequest(null), 3000);
        addNotification(`تم إرسال طلب "${label}" إلى الفريق المختص.`, "success");
    };

    const handleSendMessage = (e: React.FormEvent) => {
        e.preventDefault();
        if (!chatInput.trim() || !tokenData) return;
        triggerHaptic();
        const chatTokenId = `GUEST_${tokenData.type}_${tokenData.id}`;
        sendGuestMessage(chatTokenId, chatInput);
        setChatInput('');
    };

    // --- Helpers ---
    const chatTokenId = tokenData ? `GUEST_${tokenData.type}_${tokenData.id}` : '';
    const myMessages = messages.filter(m => m.senderId === chatTokenId || m.receiverId === chatTokenId);

    const getContextConfig = () => {
        if (!tokenData) return { bg: 'bg-gray-900', title: 'مرحباً', subtitle: 'الخدمات الذكية' };
        switch(tokenData.type) {
            case 'room': return { 
                bg: 'bg-gradient-to-br from-[#0f172a] to-[#334155]', 
                accent: 'text-blue-400',
                title: 'غرفتي الذكية', 
                subtitle: `غرفة ${tokenData.id} • ${tokenData.name || 'النزيل'}`,
                icon: Home
            };
            case 'restaurant_table': return { 
                bg: 'bg-gradient-to-br from-[#451a03] to-[#78350f]', 
                accent: 'text-orange-400',
                title: 'رفيق الطعام', 
                subtitle: `طاولة ${tokenData.id} • المطعم الرئيسي`,
                icon: Utensils
            };
            case 'pool_chair': return { 
                bg: 'bg-gradient-to-br from-[#0e7490] to-[#155e75]', 
                accent: 'text-cyan-300',
                title: 'استجمام', 
                subtitle: `المسبح • ${tokenData.name || 'منطقة الاسترخاء'}`,
                icon: Waves
            };
            case 'vip_area': return { 
                bg: 'bg-gradient-to-br from-[#1c1917] to-[#78350f]', 
                accent: 'text-yellow-500',
                title: 'VIP LOUNGE', 
                subtitle: `الدخول الحصري • ${tokenData.id}`,
                icon: Crown
            };
            case 'hall': return { 
                bg: 'bg-gradient-to-br from-[#4c1d95] to-[#7c3aed]', 
                accent: 'text-purple-300',
                title: 'مركز الحدث', 
                subtitle: `القاعة الملكية • ${tokenData.name || 'مؤتمر'}`,
                icon: PartyPopper
            };
            default: return { bg: 'bg-gray-800', accent: 'text-white', title: 'Authentic Guest', subtitle: 'Welcome', icon: Star };
        }
    };
    const ctx = getContextConfig();

    const getIconComponent = (name: string) => {
        const icons: any = { Bell, Coffee, Car, Shirt, Sparkles, Utensils, Wifi };
        const Icon = icons[name] || Bell;
        return <Icon size={20} />;
    };

    if (isExpired) return <div className="h-full flex flex-col items-center justify-center bg-gray-50 text-gray-400 p-8 text-center"><LogOut size={48} className="mb-4 text-red-400"/><h2 className="text-xl font-bold text-gray-800">انتهت الجلسة</h2></div>;
    if (!tokenData) return <div className="h-full flex flex-col items-center justify-center bg-gray-50"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div></div>;

    const filteredServices = guestServices.filter(s => 
        s.isActive && 
        (selectedServiceCategory === 'all' || s.targetDepartment === selectedServiceCategory) &&
        (s.allowedLocations.includes('all') || s.allowedLocations.includes(tokenData.type))
    );

    return (
        <div className={`h-full flex flex-col font-sans relative overflow-hidden ${ts.container}`} dir="rtl">
            
            {/* --- HEADER (Context Aware) --- */}
            <div className={`relative px-6 pt-12 pb-24 rounded-b-[3rem] shadow-2xl shrink-0 ${ctx.bg} text-white transition-all duration-500`}>
                {(settings.theme === 'zellige' || settings.theme === 'zellige-v2') ? (
                    <div className={`absolute inset-0 opacity-20 bg-zellige-pattern ${settings.darkMode ? 'mix-blend-screen' : 'mix-blend-multiply'}`}></div>
                ) : (
                    <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] mix-blend-overlay"></div>
                )}
                <div className="relative z-10 flex justify-between items-start">
                    <div>
                        <div className={`flex items-center gap-2 mb-2 ${ctx.accent}`}>
                            <ctx.icon size={20} />
                            <span className="text-xs font-bold uppercase tracking-widest">{ctx.title}</span>
                        </div>
                        <h1 className="text-2xl font-black leading-tight">{ctx.subtitle}</h1>
                    </div>
                    {/* Status Badge */}
                    <div className="flex flex-col items-end gap-2">
                        <span className="bg-white/10 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-bold border border-white/10 flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse"></span> متصل
                        </span>
                        {tokenData.type === 'room' && (
                            <div className="flex gap-1">
                                {roomState.dnd && <span className="bg-red-500/20 text-red-200 px-2 py-1 rounded text-[9px] font-bold border border-red-500/30">⛔ عدم الإزعاج</span>}
                                {roomState.clean && <span className="bg-blue-500/20 text-blue-200 px-2 py-1 rounded text-[9px] font-bold border border-blue-500/30">🧹 تنظيف</span>}
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* --- MAIN INTERFACE --- */}
            <div className="flex-1 flex flex-col -mt-16 relative z-20 px-4 pb-4 overflow-hidden">
                
                {/* 1. SMART ROOM DASHBOARD */}
                {tokenData.type === 'room' && view === 'home' && (
                    <div className="flex-1 overflow-y-auto custom-scrollbar space-y-4 pb-20">
                        {/* Quick Actions Grid */}
                        <div className="grid grid-cols-2 gap-3">
                            <button 
                                onClick={() => handleRoomControl('dnd', !roomState.dnd)}
                                className={`p-4 rounded-[2rem] flex flex-col items-center justify-center gap-2 transition-all duration-300 border-2 ${roomState.dnd ? 'bg-red-500 text-white border-red-500 shadow-lg shadow-red-500/30' : `${ts.card} ${ts.textSecondary}`}`}
                            >
                                <Moon size={28} className={roomState.dnd ? 'fill-current' : ''} />
                                <span className="text-xs font-bold">عدم الإزعاج</span>
                            </button>
                            <button 
                                onClick={() => handleRoomControl('clean', !roomState.clean)}
                                className={`p-4 rounded-[2rem] flex flex-col items-center justify-center gap-2 transition-all duration-300 border-2 ${roomState.clean ? 'bg-blue-500 text-white border-blue-500 shadow-lg shadow-blue-500/30' : `${ts.card} ${ts.textSecondary}`}`}
                            >
                                <Sparkles size={28} className={roomState.clean ? 'fill-current' : ''} />
                                <span className="text-xs font-bold">طلب تنظيف</span>
                            </button>
                        </div>

                        {/* AC & Lighting Control */}
                        <div className={`p-6 rounded-[2.5rem] shadow-sm border ${ts.card}`}>
                            <div className="flex justify-between items-center mb-6">
                                <h3 className={`font-black flex items-center gap-2 ${ts.textPrimary}`}><Thermometer size={18}/> الجو والإضاءة</h3>
                                <button onClick={() => handleRoomControl('ac', !roomState.ac)} className={`w-10 h-6 rounded-full transition-colors flex items-center px-1 ${roomState.ac ? 'bg-green-500' : 'bg-gray-300'}`}>
                                    <div className={`w-4 h-4 bg-white rounded-full shadow-sm transition-transform ${roomState.ac ? '-translate-x-4' : ''}`}></div>
                                </button>
                            </div>
                            
                            <div className="flex items-center justify-between mb-6">
                                <button onClick={() => handleRoomControl('temp', roomState.temp - 1)} className={`w-10 h-10 rounded-xl flex items-center justify-center hover:opacity-80 ${ts.iconBg}`}>-</button>
                                <span className={`text-4xl font-black ${ts.textPrimary}`}>{roomState.temp}°c</span>
                                <button onClick={() => handleRoomControl('temp', roomState.temp + 1)} className={`w-10 h-10 rounded-xl flex items-center justify-center hover:opacity-80 ${ts.iconBg}`}>+</button>
                            </div>

                            <div className="space-y-2">
                                <div className={`flex justify-between text-xs font-bold ${ts.textSecondary}`}>
                                    <span>الإضاءة</span>
                                    <span>{roomState.lights}%</span>
                                </div>
                                <input 
                                    type="range" 
                                    min="0" max="100" 
                                    value={roomState.lights} 
                                    onChange={(e) => setRoomState({...roomState, lights: parseInt(e.target.value)})}
                                    className="w-full h-3 bg-gray-100 rounded-full appearance-none cursor-pointer accent-yellow-400" 
                                />
                            </div>
                        </div>

                        {/* Recent Services */}
                        <div className="space-y-2">
                            {guestServices.filter(s => s.allowedLocations.includes('room') || s.allowedLocations.includes('all')).slice(0,3).map(service => (
                                <button 
                                    key={service.id} 
                                    onClick={() => handleRequest(service.id, service.labelAr)}
                                    className={`w-full p-4 rounded-2xl flex items-center gap-4 shadow-sm border active:scale-95 transition ${ts.card}`}
                                >
                                    <div className={`p-3 rounded-xl ${ts.iconBg}`}><Bell size={20}/></div>
                                    <div className="text-right flex-1">
                                        <h4 className={`font-bold text-sm ${ts.textPrimary}`}>{service.labelAr}</h4>
                                        <p className={`text-[10px] ${ts.textSecondary}`}>{service.description}</p>
                                    </div>
                                    <ChevronRight size={16} className={`rtl:rotate-180 ${ts.textSecondary}`} />
                                </button>
                            ))}
                            <button onClick={() => setView('services')} className={`w-full py-3 text-center text-xs font-bold hover:opacity-80 ${ts.textSecondary}`}>عرض جميع الخدمات</button>
                        </div>
                    </div>
                )}

                {/* 2. DINING MODE */}
                {tokenData.type === 'restaurant_table' && view === 'home' && (
                    <div className="flex-1 overflow-y-auto custom-scrollbar space-y-4 pb-20">
                        <div className="grid grid-cols-2 gap-3">
                            <button onClick={() => handleRequest('waiter', 'استدعاء نادل')} className={`p-5 rounded-[2rem] shadow-sm border flex flex-col items-center gap-2 active:bg-orange-50 transition ${ts.card}`}>
                                <div className="bg-orange-100 text-orange-600 p-3 rounded-full"><User size={24}/></div>
                                <span className={`font-bold text-sm ${ts.textPrimary}`}>نداء النادل</span>
                            </button>
                            <button onClick={() => handleRequest('bill', 'طلب الفاتورة')} className={`p-5 rounded-[2rem] shadow-sm border flex flex-col items-center gap-2 active:bg-green-50 transition ${ts.card}`}>
                                <div className="bg-green-100 text-green-600 p-3 rounded-full"><DollarSign size={24}/></div>
                                <span className={`font-bold text-sm ${ts.textPrimary}`}>الفاتورة</span>
                            </button>
                        </div>
                        
                        <div className={`p-6 rounded-[2rem] shadow-sm border ${ts.card}`}>
                            <h3 className={`font-black text-lg mb-4 flex items-center gap-2 ${ts.textPrimary}`}><Star className="text-yellow-400" fill="currentColor"/> توصيات الشيف</h3>
                            <div className="space-y-3">
                                {menuItems.slice(0, 3).map(item => (
                                    <div key={item.id} className="flex items-center gap-3 border-b border-gray-50 pb-3 last:border-0">
                                        <div className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center text-xl">🥘</div>
                                        <div className="flex-1">
                                            <h4 className={`font-bold text-sm ${ts.textPrimary}`}>{item.name}</h4>
                                            <p className={`text-[10px] line-clamp-1 ${ts.textSecondary}`}>{item.description}</p>
                                        </div>
                                        <span className="font-black text-orange-600 text-sm">{item.price}</span>
                                    </div>
                                ))}
                            </div>
                            <button onClick={() => setView('menu')} className="w-full mt-4 py-3 bg-gray-900 text-white rounded-xl text-xs font-bold">عرض القائمة الكاملة</button>
                        </div>
                    </div>
                )}

                {/* 3. POOL MODE */}
                {tokenData.type === 'pool_chair' && view === 'home' && (
                    <div className="flex-1 overflow-y-auto custom-scrollbar space-y-4 pb-20">
                        <div className="bg-cyan-50 p-6 rounded-[2rem] shadow-sm border border-cyan-100">
                            <h2 className="text-lg font-black text-cyan-800 mb-2">استرخاء تام</h2>
                            <p className="text-xs text-cyan-600 font-bold leading-relaxed">
                                استمتع بوقتك تحت الشمس. نحن هنا لخدمتك بلمسة زر واحدة.
                            </p>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                            <button onClick={() => handleRequest('towel', 'منشفة إضافية')} className={`p-4 rounded-2xl shadow-sm flex flex-col items-center gap-2 active:scale-95 transition border ${ts.card}`}>
                                <Umbrella className="text-cyan-500" size={24}/>
                                <span className={`font-bold text-sm ${ts.textPrimary}`}>طلب منشفة</span>
                            </button>
                            <button onClick={() => setView('menu')} className={`p-4 rounded-2xl shadow-sm flex flex-col items-center gap-2 active:scale-95 transition border ${ts.card}`}>
                                <GlassWater className="text-orange-500" size={24}/>
                                <span className={`font-bold text-sm ${ts.textPrimary}`}>مشروبات باردة</span>
                            </button>
                            <button onClick={() => handleRequest('attendant', 'مشرف المسبح')} className={`p-4 rounded-2xl shadow-sm flex flex-col items-center gap-2 active:scale-95 transition border col-span-2 ${ts.card}`}>
                                <User className="text-blue-500" size={24}/>
                                <span className={`font-bold text-sm ${ts.textPrimary}`}>نداء المشرف</span>
                            </button>
                        </div>
                    </div>
                )}

                {/* 4. VIP AREA MODE */}
                {tokenData.type === 'vip_area' && view === 'home' && (
                    <div className="flex-1 overflow-y-auto custom-scrollbar space-y-4 pb-20">
                        <div className="bg-gray-900 p-6 rounded-[2rem] shadow-xl border border-yellow-500/30 relative overflow-hidden text-center">
                            <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-500/10 rounded-full blur-2xl"></div>
                            <Crown className="text-yellow-400 mx-auto mb-2" size={32}/>
                            <h2 className="text-xl font-black text-white mb-1">VIP Access</h2>
                            <p className="text-xs text-yellow-500 font-bold uppercase tracking-widest">Premium Service</p>
                        </div>
                        <div className="space-y-2">
                            <button onClick={() => setView('chat')} className={`w-full p-5 rounded-2xl shadow-sm border flex items-center gap-4 ${ts.card}`}>
                                <div className="bg-yellow-50 p-3 rounded-xl text-yellow-600"><Gem size={20}/></div>
                                <div className="text-right">
                                    <h4 className={`font-bold ${ts.textPrimary}`}>المساعد الشخصي (Concierge)</h4>
                                    <p className={`text-[10px] ${ts.textSecondary}`}>تواصل مباشر لتلبية كافة طلباتك</p>
                                </div>
                            </button>
                            <button onClick={() => handleRequest('limo', 'طلب ليموزين')} className={`w-full p-5 rounded-2xl shadow-sm border flex items-center gap-4 ${ts.card}`}>
                                <div className="bg-gray-50 p-3 rounded-xl text-gray-600"><Car size={20}/></div>
                                <div className="text-right">
                                    <h4 className={`font-bold ${ts.textPrimary}`}>خدمة النقل الفاخر</h4>
                                    <p className={`text-[10px] ${ts.textSecondary}`}>حجز سيارة بسائق خاص</p>
                                </div>
                            </button>
                        </div>
                    </div>
                )}

                {/* 5. EVENT MODE */}
                {tokenData.type === 'hall' && view === 'home' && (
                    <div className="flex-1 overflow-y-auto custom-scrollbar space-y-4 pb-20">
                        <div className={`p-6 rounded-[2rem] shadow-sm border text-center ${ts.card}`}>
                            <h2 className={`text-xl font-black mb-2 ${ts.textPrimary}`}>كلمة الافتتاح</h2>
                            <p className={`text-sm leading-relaxed ${ts.textSecondary}`}>أهلاً بكم في فعالياتنا المميزة. يرجى الاطلاع على جدول الأعمال واستخدام كود الواي فاي أدناه.</p>
                            <div className="mt-6 bg-gray-50 p-4 rounded-xl inline-block border border-dashed border-gray-300">
                                <p className="text-[10px] uppercase font-bold text-gray-400 mb-1">Event Wi-Fi</p>
                                <p className="font-mono font-black text-lg tracking-wider text-black">EVENT_2024</p>
                            </div>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                            <button onClick={() => handleRequest('coffee', 'طلب قهوة')} className={`p-4 rounded-2xl shadow-sm flex items-center gap-3 active:scale-95 transition ${ts.card}`}>
                                <Coffee className="text-purple-600"/> <span className={`font-bold text-sm ${ts.textPrimary}`}>ضيافة</span>
                            </button>
                            <button onClick={() => handleRequest('tech', 'دعم فني')} className={`p-4 rounded-2xl shadow-sm flex items-center gap-3 active:scale-95 transition ${ts.card}`}>
                                <Zap className="text-yellow-500"/> <span className={`font-bold text-sm ${ts.textPrimary}`}>دعم فني</span>
                            </button>
                        </div>
                    </div>
                )}

                {/* NEW: SERVICES CATALOG VIEW */}
                {view === 'services' && (
                    <div className="flex-1 overflow-y-auto custom-scrollbar pb-24 animate-fade-in">
                        <div className={`p-6 rounded-[2.5rem] mb-6 shadow-sm border ${ts.card}`}>
                            <h3 className={`font-black text-lg mb-2 flex items-center gap-2 ${ts.textPrimary}`}>
                                <LayoutGrid size={20}/> دليل الخدمات الشامل
                            </h3>
                            <p className={`text-xs ${ts.textSecondary}`}>اختر الخدمة المطلوبة وسيقوم فريقنا بتلبيتها فوراً.</p>
                        </div>

                        {/* Categories */}
                        <div className="flex overflow-x-auto gap-2 mb-4 pb-2 scrollbar-hide">
                            {[
                                { id: 'all', label: 'الكل' },
                                { id: 'housekeeping', label: 'التنظيف' },
                                { id: 'food_beverage', label: 'الطعام' },
                                { id: 'reception', label: 'الاستقبال' },
                                { id: 'spa_wellness', label: 'السبا' }
                            ].map(cat => (
                                <button
                                    key={cat.id}
                                    onClick={() => setSelectedServiceCategory(cat.id as any)}
                                    className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition border ${
                                        selectedServiceCategory === cat.id 
                                        ? ts.buttonActive
                                        : ts.buttonInactive
                                    }`}
                                >
                                    {cat.label}
                                </button>
                            ))}
                        </div>

                        {/* Services Grid */}
                        <div className="grid grid-cols-2 gap-3">
                            {filteredServices.map(service => (
                                <button
                                    key={service.id}
                                    onClick={() => handleRequest(service.id, service.labelAr)}
                                    className={`p-4 rounded-2xl flex flex-col items-center text-center gap-3 border transition active:scale-95 ${ts.card} hover:shadow-md`}
                                >
                                    <div className={`p-3 rounded-full ${ts.iconBg}`}>
                                        {getIconComponent(service.icon)}
                                    </div>
                                    <div>
                                        <h4 className={`font-bold text-xs ${ts.textPrimary}`}>{service.labelAr}</h4>
                                        <span className={`text-[9px] font-bold mt-1 block ${service.price ? 'text-green-600' : ts.textSecondary}`}>
                                            {service.price ? `${service.price} د.ج` : 'مجاني'}
                                        </span>
                                    </div>
                                </button>
                            ))}
                        </div>
                    </div>
                )}



    // ... (rest of the component)

                {/* GENERIC MENU VIEW (UPDATED) */}
                {view === 'menu' && (
                    <div className={`flex-1 flex flex-col overflow-hidden animate-fade-in ${ts.container}`}>
                        {/* Menu Header */}
                        <div className={`p-4 shadow-sm z-10 sticky top-0 ${ts.card}`}>
                            <div className="flex justify-between items-center mb-3">
                                <h3 className={`font-black text-lg flex items-center gap-2 ${ts.textPrimary}`}>
                                    <Utensils size={20} className="text-orange-500"/> قائمة الطعام
                                </h3>
                                {tokenData.type === 'room' && (
                                    <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-[10px] font-bold flex items-center gap-1">
                                        <Clock size={12}/> توصيل للغرفة (20-30 دقيقة)
                                    </span>
                                )}
                            </div>
                            <div className="flex gap-2 mt-3 overflow-x-auto scrollbar-hide pb-1">
                                {['all', 'meal', 'breakfast', 'hot_drink', 'cold_drink', 'dessert'].map(cat => (
                                    <button 
                                        key={cat}
                                        onClick={() => setSelectedServiceCategory(cat as any)} // Reusing state for category
                                        className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap border ${selectedServiceCategory === cat ? ts.buttonActive : ts.buttonInactive}`}
                                    >
                                        {cat === 'all' ? 'الكل' : cat}
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* Menu Grid */}
                        <div className="flex-1 overflow-y-auto p-4 custom-scrollbar space-y-3 pb-32">
                            {menuItems
                                .filter(item => (selectedServiceCategory === 'all' || item.category === selectedServiceCategory))
                                .map(item => (
                                <div key={item.id} className={`p-3 rounded-2xl shadow-sm flex items-center gap-3 border group transition ${!item.isAvailable ? 'opacity-60 grayscale' : 'active:scale-[0.98]'} ${ts.card}`}>
                                    <div className={`w-20 h-20 rounded-xl flex items-center justify-center text-2xl shadow-inner relative overflow-hidden ${ts.iconBg}`}>
                                        {item.category === 'hot_drink' ? '☕' : item.category === 'cold_drink' ? '🥤' : item.category === 'dessert' ? '🍰' : '🥘'}
                                        {!item.isAvailable && (
                                            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                                                <span className="text-[10px] font-bold text-white bg-red-500 px-2 py-1 rounded-full transform -rotate-12">نفذت الكمية</span>
                                            </div>
                                        )}
                                    </div>
                                    <div className="flex-1">
                                        <h4 className={`font-bold text-sm ${ts.textPrimary}`}>{item.name}</h4>
                                        <p className={`text-[10px] line-clamp-1 mb-2 ${ts.textSecondary}`}>{item.description}</p>
                                        <div className="flex justify-between items-center">
                                            <span className={`font-black text-sm ${ts.textPrimary}`}>{item.price} <span className={`text-[10px] ${ts.textSecondary}`}>د.ج</span></span>
                                            <button 
                                                onClick={() => item.isAvailable && addToCart(item)}
                                                disabled={!item.isAvailable}
                                                className={`w-8 h-8 rounded-full flex items-center justify-center shadow-lg transition ${!item.isAvailable ? 'bg-gray-300 cursor-not-allowed' : 'bg-black text-white hover:bg-orange-600'}`}
                                            >
                                                <Plus size={16}/>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>

                        {/* Cart Summary (Floating) */}
                        {cart.length > 0 && (
                            <div className={`absolute bottom-20 left-4 right-4 p-4 rounded-[2rem] shadow-[0_10px_40px_rgba(0,0,0,0.15)] z-30 border animate-fade-in-up ${ts.card}`}>
                                <div className="flex justify-between items-center mb-3">
                                    <div className="flex items-center gap-2">
                                        <div className="bg-orange-100 text-orange-600 p-2 rounded-full"><ShoppingBag size={18}/></div>
                                        <span className={`text-xs font-bold ${ts.textSecondary}`}>{cart.length} عناصر</span>
                                    </div>
                                    <span className={`font-black text-xl ${ts.textPrimary}`}>{cart.reduce((a, c) => a + (c.item.price * c.quantity), 0)} <span className={`text-xs ${ts.textSecondary}`}>د.ج</span></span>
                                </div>
                                <button 
                                    onClick={handlePlaceOrder}
                                    disabled={isOrderSubmitting}
                                    className={`w-full py-3.5 rounded-xl font-bold shadow-lg flex items-center justify-center gap-2 active:scale-95 transition ${ts.buttonActive}`}
                                >
                                    {isOrderSubmitting ? 'جاري الإرسال...' : <><CheckCircle size={18}/> تأكيد الطلب {tokenData.type === 'room' ? '(توصيل)' : ''}</>}
                                </button>
                            </div>
                        )}
                    </div>
                )}

                {/* CHAT VIEW */}
                {view === 'chat' && (
                    <div className={`flex-1 flex flex-col rounded-[2rem] shadow-sm overflow-hidden border relative ${ts.card}`}>
                        <div className={`flex-1 overflow-y-auto p-4 space-y-3 ${ts.container}`}>
                            {myMessages.length === 0 && (
                                <div className="h-full flex flex-col items-center justify-center text-gray-300">
                                    <MessageCircle size={32} className="mb-2"/>
                                    <p className="text-xs font-bold">ابدأ المحادثة مع الاستقبال</p>
                                </div>
                            )}
                            {myMessages.map(msg => {
                                const isMe = msg.senderId === chatTokenId;
                                return (
                                    <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'} animate-fade-in-up`}>
                                        <div className={`max-w-[85%] p-3 rounded-2xl text-xs font-bold shadow-sm ${isMe ? 'bg-black text-white rounded-br-none' : `${ts.card} ${ts.textPrimary} rounded-bl-none`}`}>
                                            {msg.content}
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                        <form onSubmit={handleSendMessage} className={`p-2 border-t flex gap-2 ${ts.card}`}>
                            <input ref={inputRef} type="text" value={chatInput} onChange={e => setChatInput(e.target.value)} placeholder="اكتب رسالة..." className={`flex-1 rounded-full px-4 py-3 text-xs font-bold outline-none ${ts.iconBg} ${ts.textPrimary}`}/>
                            <button type="submit" className={`p-3 rounded-full shadow-lg active:scale-90 transition ${ts.buttonActive}`}><Send size={16}/></button>
                        </form>
                    </div>
                )}

            </div>

            {/* --- BOTTOM NAV --- */}
            <div className={`backdrop-blur-xl border-t fixed bottom-0 w-full p-4 pb-6 z-50 flex justify-around items-center rounded-t-[2rem] shadow-[0_-5px_20px_rgba(0,0,0,0.05)] ${ts.bottomNav}`}>
                <button onClick={() => setView('home')} className={`flex flex-col items-center gap-1 transition ${view === 'home' ? `${ts.navIconActive} scale-110` : ts.navIconInactive}`}>
                    <Home size={24} strokeWidth={view === 'home' ? 2.5 : 2}/>
                </button>
                {/* Services Button */}
                {(tokenData.type === 'room' || tokenData.type === 'suite') && (
                    <button onClick={() => setView('services')} className={`flex flex-col items-center gap-1 transition ${view === 'services' ? `${ts.navIconActive} scale-110` : ts.navIconInactive}`}>
                        <LayoutGrid size={24} strokeWidth={view === 'services' ? 2.5 : 2}/>
                    </button>
                )}
                {(tokenData.type === 'restaurant_table' || tokenData.type === 'room' || tokenData.type === 'pool_chair') && (
                    <button onClick={() => setView('menu')} className={`flex flex-col items-center gap-1 transition ${view === 'menu' ? `${ts.navIconActive} scale-110` : ts.navIconInactive}`}>
                        <Menu size={24} strokeWidth={view === 'menu' ? 2.5 : 2}/>
                    </button>
                )}
                <button onClick={() => setView('chat')} className={`flex flex-col items-center gap-1 transition ${view === 'chat' ? `${ts.navIconActive} scale-110` : ts.navIconInactive}`}>
                    <MessageCircle size={24} strokeWidth={view === 'chat' ? 2.5 : 2}/>
                    {myMessages.length > 0 && <span className="absolute top-3 right-1/3 w-2 h-2 bg-red-500 rounded-full border border-white"></span>}
                </button>
            </div>

        </div>
    );
};
