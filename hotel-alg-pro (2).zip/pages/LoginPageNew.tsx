
import React, { useState, useEffect } from 'react';
import { useHotel } from '../context/HotelContext';
import { User } from '../types';
import { Building2, UserCircle, KeyRound, LogIn, ShieldCheck, ChevronDown, ChevronUp } from 'lucide-react';

const LoginPage: React.FC = () => {
  const { users, login, settings } = useHotel();
  const [manualId, setManualId] = useState('');
  const [error, setError] = useState('');
  const [showQuickSelect, setShowQuickSelect] = useState(false);
  const [selectedDept, setSelectedDept] = useState<string | null>(null);

  const handleLogin = (userId: string) => {
    try {
      login(userId);
    } catch (err) {
      setError('فشل تسجيل الدخول. يرجى التحقق من البيانات.');
    }
  };

  const handleManualLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualId.trim()) return;
    
    const user = users.find(u => u.id === manualId || u.accessCode === manualId);
    if (user) {
      handleLogin(user.id);
    } else {
      setError('المستخدم غير موجود. يرجى التحقق من المعرف أو الرمز.');
    }
  };

  // Group users by department
  const groupedUsers = users.reduce((acc, user) => {
    const dept = user.department || 'Other';
    if (!acc[dept]) {
      acc[dept] = [];
    }
    acc[dept].push(user);
    return acc;
  }, {} as Record<string, User[]>);

  // Zellij Theme Classes
  const isZellij = settings.theme === 'zellige' || settings.theme === 'zellige-v2';
  const isDarkZellige = isZellij && settings.darkMode;

  const themeClasses = {
      bg: isDarkZellige ? 'bg-[#001e21]' : (isZellij ? 'bg-[#fdfbf7]' : 'bg-slate-900'),
      pattern: isZellij ? 'bg-zellige-pattern opacity-10' : "bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5",
      card: isDarkZellige 
          ? 'bg-[#002a2d]/90 border-[#cca43b]/30 text-[#cca43b]' 
          : (isZellij ? 'bg-white/90 border-[#cca43b]/30 text-[#006269]' : 'bg-slate-800/80 border-slate-700/50 text-white'),
      accent: isZellij ? 'text-[#cca43b]' : 'text-emerald-400',
      button: isDarkZellige
          ? 'bg-[#cca43b] hover:bg-[#b08d30] text-[#001e21] font-bold'
          : (isZellij ? 'bg-[#006269] hover:bg-[#004d53] text-[#cca43b]' : 'bg-emerald-600 hover:bg-emerald-500 text-white'),
      input: isDarkZellige
          ? 'bg-[#001517] border-[#cca43b]/40 text-[#cca43b] placeholder-[#cca43b]/40 focus:border-[#cca43b]'
          : (isZellij ? 'bg-[#fbf8f1] border-[#cca43b]/40 text-[#006269] placeholder-[#006269]/50 focus:border-[#006269]' : 'bg-slate-900/50 border-slate-700 text-white placeholder-slate-500 focus:border-emerald-500'),
      userCard: isDarkZellige
          ? 'bg-[#002a2d] hover:bg-[#cca43b]/10 border-[#cca43b]/20'
          : (isZellij ? 'bg-[#fbf8f1] hover:bg-[#cca43b]/10 border-[#cca43b]/20' : 'bg-slate-700/30 hover:bg-slate-700 border-transparent'),
      userText: isDarkZellige ? 'text-[#cca43b]' : (isZellij ? 'text-[#006269]' : 'text-slate-200'),
      userSubText: isDarkZellige ? 'text-[#cca43b]/70' : (isZellij ? 'text-[#006269]/70' : 'text-slate-400'),
  };

  return (
    <div className={`min-h-screen flex items-center justify-center p-4 relative overflow-y-auto transition-colors duration-500 ${themeClasses.bg}`} dir="rtl">
      {/* Background Pattern */}
      <div className={`fixed inset-0 pointer-events-none ${themeClasses.pattern}`}></div>
      
      {/* Overlay Gradient */}
      {!isZellij && <div className="fixed inset-0 opacity-10 pointer-events-none bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-emerald-900 via-slate-900 to-slate-900"></div>}

      <div className="max-w-6xl w-full flex justify-center relative z-10 my-8">
        
        {/* Right Side: Branding & Manual Login */}
        <div className="flex flex-col justify-center space-y-8 animate-fade-in-up w-full max-w-md mx-auto">
          <div className="text-center space-y-4">
            <div className={`flex flex-col items-center justify-center gap-4 mb-6 ${themeClasses.accent}`}>
              <div className={`p-4 rounded-2xl border shadow-lg ${isZellij ? 'bg-[#006269] border-[#cca43b]' : 'bg-emerald-500/10 border-emerald-500/20'}`}>
                <Building2 className={`w-12 h-12 ${isZellij ? 'text-[#cca43b]' : 'text-emerald-400'}`} />
              </div>
              <div className="text-center">
                <h1 className={`text-4xl font-black tracking-tighter ${isZellij ? 'text-[#006269]' : 'text-white'}`}>
                  فندق <span className={themeClasses.accent}>الجزائر</span>
                </h1>
                <p className={`text-sm font-bold tracking-widest uppercase mt-1 ${isZellij ? 'text-[#006269]/70' : 'text-slate-400'}`}>نظام الإدارة الفندقية المتكامل</p>
              </div>
            </div>
          </div>

          <div className={`backdrop-blur-md border rounded-[2.5rem] p-8 shadow-2xl relative overflow-hidden group ${themeClasses.card}`}>
            {isZellij && <div className="absolute top-0 right-0 w-full h-2 bg-gradient-to-r from-[#cca43b] via-[#006269] to-[#cca43b]"></div>}
            
            <h2 className={`text-2xl font-bold mb-6 flex items-center gap-3 ${isZellij ? 'text-[#006269]' : 'text-white'}`}>
              <div className={`p-2 rounded-lg ${isZellij ? 'bg-[#cca43b]/20' : 'bg-slate-700/50'}`}>
                <KeyRound className={`w-6 h-6 ${themeClasses.accent}`} />
              </div>
              تسجيل الدخول الآمن
            </h2>
            
            <form onSubmit={handleManualLogin} className="space-y-6">
              <div>
                <label className={`block text-sm font-bold mb-2 uppercase tracking-wide ${isZellij ? 'text-[#006269]/80' : 'text-slate-400'}`}>
                  معرف المستخدم / رمز الدخول
                </label>
                <input
                  type="text"
                  value={manualId}
                  onChange={(e) => {
                    setManualId(e.target.value);
                    setError('');
                  }}
                  placeholder="أدخل المعرف الخاص بك..."
                  className={`w-full border-2 rounded-2xl px-5 py-4 outline-none transition-all text-lg font-mono text-center tracking-widest ${themeClasses.input}`}
                />
              </div>
              
              {error && (
                <div className="text-red-500 text-sm font-bold bg-red-500/10 p-4 rounded-xl border border-red-500/20 flex items-center gap-2 animate-shake">
                  <ShieldCheck className="w-5 h-5 shrink-0" />
                  {error}
                </div>
              )}

              <button
                type="submit"
                className={`w-full font-bold text-lg py-4 rounded-xl transition-all transform active:scale-95 shadow-lg flex items-center justify-center gap-3 ${themeClasses.button}`}
              >
                <LogIn className="w-6 h-6" />
                تسجيل الدخول
              </button>
            </form>
          </div>
        </div>

      </div>
    </div>
  );
};

export default LoginPage;
