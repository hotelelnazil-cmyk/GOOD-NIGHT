
import React, { useState, useMemo, useEffect } from 'react';
import { useHotel } from '../context/HotelContext';
import { PageHeader } from '../components/PageHeader';
import { 
    User, Shield, ShieldOff, Check, X, Lock, Unlock, Plus, Trash2, 
    Briefcase, Crown, UserPlus, Users, Brush, 
    Wrench, Siren, Monitor, Calculator,
    BadgeCheck, ChefHat, Coffee, ConciergeBell, Megaphone, Wifi, Flower2,
    IdCard, ScanBarcode, ArrowRight, Share2, Copy, Edit, FileText, Banknote,
    CheckCircle2, XCircle, LayoutGrid, Key, FileSpreadsheet, ShieldCheck,
    Calendar, Plane, Thermometer, AlertCircle, Clock, Fingerprint, LogIn, LogOut, Timer, Save
} from 'lucide-react';
import { Role, Department, User as UserType, UserPermissions, LeaveRequest, LeaveType, AttendanceRecord } from '../types';
import { 
    MANAGER_PERMISSIONS, 
    ASSISTANT_MANAGER_PERMISSIONS, 
    RECEPTIONIST_PERMISSIONS, 
    FB_MANAGER_PERMISSIONS, 
    STAFF_PERMISSIONS 
} from '../constants';

import { StaffCard } from '../components/StaffCard';

export const StaffPage: React.FC = () => {
  const { users, currentUser, updateUser, addStaff, removeStaff, settings, attendanceRecords, recordAttendance, updateAttendanceRecord, leaveRequests, addLeaveRequest, updateLeaveStatus, setActiveProfile, addNotification } = useHotel();
  const [activeTab, setActiveTab] = useState<'directory' | 'leaves' | 'attendance'>('directory');
  
  // --- Modals State ---
  const [showAddModal, setShowAddModal] = useState(false);
  const [showLeaveModal, setShowLeaveModal] = useState(false);
  const [showAttendanceEditModal, setShowAttendanceEditModal] = useState<AttendanceRecord | null>(null);
  const [showManualAttendanceModal, setShowManualAttendanceModal] = useState(false);
  
  // New Staff Form State
  const [newStaffName, setNewStaffName] = useState('');
  const [newStaffDept, setNewStaffDept] = useState<Department>('reception');
  const [selectedJobTitle, setSelectedJobTitle] = useState(''); 
  const [newStaffSystemRole, setNewStaffSystemRole] = useState<Role>('receptionist');
  const [newStaffSalary, setNewStaffSalary] = useState('');
  const [newStaffPin, setNewStaffPin] = useState('');
  const [isHeadOfDept, setIsHeadOfDept] = useState(false);

  // Manual Attendance State
  const [manualAttUser, setManualAttUser] = useState('');
  const [manualAttTime, setManualAttTime] = useState('');

  // Edit Attendance State
  const [editAttTimeIn, setEditAttTimeIn] = useState('');
  const [editAttTimeOut, setEditAttTimeOut] = useState('');

  // Leave Form State
  const [newLeave, setNewLeave] = useState({
      type: 'annual' as LeaveType,
      startDate: '',
      endDate: '',
      reason: ''
  });

  const [activeDept, setActiveDept] = useState<Department | 'all'>('all');

  const canManage = currentUser?.permissions.canManageStaff;
  const isManager = currentUser?.role === 'manager' || currentUser?.role === 'assistant_manager';

  // --- Departments Config ---
  const departments: { id: Department; label: string; icon: any; color: string; bg: string; border: string }[] = [
      { id: 'administration', label: 'الإدارة العليا', icon: Briefcase, color: 'text-purple-600', bg: 'bg-purple-50', border: 'border-purple-200' },
      { id: 'reception', label: 'الاستقبال (Front Office)', icon: Monitor, color: 'text-blue-600', bg: 'bg-blue-50', border: 'border-blue-200' },
      { id: 'guest_services', label: 'الخدمات الفندقية', icon: ConciergeBell, color: 'text-indigo-600', bg: 'bg-indigo-50', border: 'border-indigo-200' },
      { id: 'food_beverage', label: 'التغذية (F&B)', icon: ChefHat, color: 'text-orange-600', bg: 'bg-orange-50', border: 'border-orange-200' },
      { id: 'housekeeping', label: 'التدبير المنزلي', icon: Brush, color: 'text-cyan-600', bg: 'bg-cyan-50', border: 'border-cyan-200' },
      { id: 'maintenance', label: 'الصيانة والهندسة', icon: Wrench, color: 'text-red-600', bg: 'bg-red-50', border: 'border-red-200' },
      { id: 'security', label: 'الأمن والسلامة', icon: Siren, color: 'text-slate-600', bg: 'bg-slate-50', border: 'border-slate-200' },
      { id: 'finance', label: 'المالية والمحاسبة', icon: Calculator, color: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-200' },
      { id: 'hr', label: 'الموارد البشرية', icon: Users, color: 'text-pink-600', bg: 'bg-pink-50', border: 'border-pink-200' },
      { id: 'sales_marketing', label: 'المبيعات والتسويق', icon: Megaphone, color: 'text-violet-600', bg: 'bg-violet-50', border: 'border-violet-200' },
      { id: 'it', label: 'تكنولوجيا المعلومات', icon: Wifi, color: 'text-gray-600', bg: 'bg-gray-50', border: 'border-gray-200' },
      { id: 'spa_wellness', label: 'السبا والرفاهية', icon: Flower2, color: 'text-teal-600', bg: 'bg-teal-50', border: 'border-teal-200' },
  ];

  const getDeptInfo = (deptId: Department) => {
      return departments.find(d => d.id === deptId) || { label: deptId, icon: User, color: 'text-gray-500', bg: 'bg-gray-50', border: 'border-gray-200' };
  };

  // --- Dynamic Job Titles & Role Mapping ---
  const getJobTitlesForDepartment = (dept: Department): { title: string, systemRole: Role }[] => {
      // Simplified for brevity, use full list in real app
      return [{ title: 'رئيس قسم', systemRole: 'assistant_manager' }, { title: 'موظف', systemRole: 'staff' }];
  };

  // --- Attendance Helpers ---
  const today = new Date().toISOString().split('T')[0];
  
  const getTodayRecord = (userId: string) => attendanceRecords.find(r => r.userId === userId && r.date === today);

  const handleManualCheckIn = (userId: string) => recordAttendance(userId, 'in');
  const handleManualCheckOut = (userId: string) => recordAttendance(userId, 'out');

  const handleManualEntrySubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (!manualAttUser || !manualAttTime) return;
      
      const timeISO = `${today}T${manualAttTime}:00`;
      recordAttendance(manualAttUser, 'in', timeISO);
      setShowManualAttendanceModal(false);
      setManualAttUser('');
      setManualAttTime('');
  };

  const openEditAttendance = (record: AttendanceRecord) => {
      setShowAttendanceEditModal(record);
      setEditAttTimeIn(record.checkInTime ? new Date(record.checkInTime).toTimeString().slice(0, 5) : '');
      setEditAttTimeOut(record.checkOutTime ? new Date(record.checkOutTime).toTimeString().slice(0, 5) : '');
  };

  const handleSaveAttendanceEdit = () => {
      if (!showAttendanceEditModal) return;
      
      const updates: any = {};
      if (editAttTimeIn) {
          updates.checkInTime = `${showAttendanceEditModal.date}T${editAttTimeIn}:00`;
      }
      if (editAttTimeOut) {
          updates.checkOutTime = `${showAttendanceEditModal.date}T${editAttTimeOut}:00`;
      }

      updateAttendanceRecord(showAttendanceEditModal.id, updates);
      setShowAttendanceEditModal(null);
  };

  // --- Leave Helpers ---
  const getDaysDifference = (start: string, end: string) => {
      const d1 = new Date(start);
      const d2 = new Date(end);
      const diffTime = Math.abs(d2.getTime() - d1.getTime());
      return Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1; 
  };

  const handleLeaveSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (!newLeave.startDate || !newLeave.endDate || !newLeave.reason) return;
      
      const days = getDaysDifference(newLeave.startDate, newLeave.endDate);
      
      addLeaveRequest({
          userId: currentUser?.id || '',
          userName: currentUser?.name || '',
          userRole: currentUser?.role || 'staff',
          type: newLeave.type,
          startDate: newLeave.startDate,
          endDate: newLeave.endDate,
          daysCount: days,
          reason: newLeave.reason
      });
      
      setShowLeaveModal(false);
      setNewLeave({ type: 'annual', startDate: '', endDate: '', reason: '' });
  };

  const getLeaveIcon = (type: LeaveType) => {
      switch(type) {
          case 'annual': return <Plane className="text-blue-500" />;
          case 'sick': return <Thermometer className="text-red-500" />;
          case 'unpaid': return <AlertCircle className="text-orange-500" />;
          default: return <Clock className="text-gray-500" />;
      }
  };

  // --- Theme Logic ---
  const getThemeStyles = () => {
      if (settings.darkMode) {
          if (settings.theme === 'zellige') {
              return {
                  card: 'bg-[#001e21] border border-[#cca43b]/30 hover:border-[#cca43b] relative overflow-hidden shadow-lg',
                  accentText: 'text-[#cca43b] drop-shadow-sm',
                  button: 'bg-[#cca43b] text-[#002a2d] hover:bg-[#b08d30] font-bold border border-[#cca43b]',
                  modalBg: 'bg-[#002a2d] text-[#cca43b] border border-[#cca43b]/30 relative overflow-hidden',
                  badgePattern: 'bg-zellige-pattern opacity-10 mix-blend-screen',
                  modalHeader: 'bg-[#001e21] text-[#cca43b] border-b border-[#cca43b]/20 relative overflow-hidden',
                  modalInput: 'border-[#cca43b]/40 focus:border-[#cca43b] bg-[#002a2d] text-[#cca43b] placeholder-[#cca43b]/40',
                  inputLabel: 'text-[#cca43b]',
                  sectionCard: 'bg-[#001e21] border-[#cca43b]/30 shadow-none relative overflow-hidden',
                  activeTab: 'bg-[#cca43b] text-[#002a2d] shadow-md border-[#cca43b]',
                  textPrimary: 'text-[#cca43b]',
                  textSecondary: 'text-[#cca43b]/70',
                  iconBg: 'bg-[#002a2d] text-[#cca43b]',
                  tabInactive: 'text-[#cca43b]/60 hover:bg-[#cca43b]/10'
              };
          }
          return {
              card: 'bg-gray-800 border border-gray-700 hover:border-blue-400',
              accentText: 'text-blue-400',
              button: 'bg-blue-600 text-white hover:bg-blue-700',
              modalBg: 'bg-gray-900 text-white',
              badgePattern: '',
              modalHeader: 'bg-gray-800 text-white border-b border-gray-700',
              modalInput: 'border-gray-700 focus:border-blue-500 bg-gray-800 text-white placeholder-gray-500',
              inputLabel: 'text-gray-400',
              sectionCard: 'bg-gray-800 border-gray-700 shadow-sm',
              activeTab: 'bg-blue-600 text-white shadow-md',
              textPrimary: 'text-white',
              textSecondary: 'text-gray-400',
              iconBg: 'bg-gray-700 text-gray-300',
              tabInactive: 'text-gray-400 hover:bg-gray-700'
          };
      }

      switch(settings.theme) {
          case 'zellige': return {
              card: 'bg-[#fdfbf7] border border-[#cca43b]/40 hover:border-[#006269] relative overflow-hidden shadow-sm',
              accentText: 'text-[#006269]',
              button: 'bg-[#006269] text-[#cca43b] hover:bg-[#004d53]',
              modalBg: 'bg-[#fdfbf7] relative overflow-hidden',
              badgePattern: 'bg-zellige-pattern opacity-10 mix-blend-multiply',
              modalHeader: 'bg-[#006269] text-[#cca43b] border-b border-[#cca43b]/20', 
              modalInput: 'border-[#cca43b]/30 focus:border-[#006269] focus:ring-[#006269]/20 bg-[#fbf8f1] text-[#006269] placeholder-[#cca43b]/50',
              inputLabel: 'text-[#006269]',
              sectionCard: 'bg-white border-[#cca43b]/30 shadow-sm relative overflow-hidden',
              activeTab: 'bg-[#006269] text-[#cca43b] shadow-md border-[#cca43b]',
              textPrimary: 'text-[#006269]',
              textSecondary: 'text-[#006269]/70',
              iconBg: 'bg-[#fbf8f1] text-[#006269]',
              tabInactive: 'text-[#006269]/70 hover:bg-[#cca43b]/10'
          };
          default: return {
              card: 'bg-white border border-gray-200 hover:border-blue-400 shadow-sm',
              accentText: 'text-blue-600',
              button: 'bg-blue-600 text-white hover:bg-blue-700',
              modalBg: 'bg-white',
              badgePattern: '',
              modalHeader: 'bg-slate-900 text-white border-b border-gray-700',
              modalInput: 'border-gray-200 focus:border-blue-500 bg-white text-gray-900',
              inputLabel: 'text-gray-500',
              sectionCard: 'bg-gray-50 border-gray-200 shadow-sm',
              activeTab: 'bg-blue-600 text-white shadow-md',
              textPrimary: 'text-gray-800',
              textSecondary: 'text-gray-500',
              iconBg: 'bg-gray-50 text-gray-600',
              tabInactive: 'text-gray-600 hover:bg-gray-100'
          };
      }
  };
  const ts = getThemeStyles();
  const isZellige = settings.theme === 'zellige';

  // Helper to get department styles that respect dark mode
  const getDeptStyle = (dept: any) => {
      if (settings.darkMode && settings.theme === 'zellige') {
          return {
              bg: 'bg-[#002a2d]',
              color: 'text-[#cca43b]',
              border: 'border-[#cca43b]/30'
          };
      }
      return dept;
  };

  if (!canManage) {
    return <div className="flex flex-col items-center justify-center py-20 text-gray-500"><ShieldOff size={48} className="mb-4 text-red-400" /><h2 className="text-xl font-bold">وصول مرفوض</h2></div>;
  }

  const handleAddStaff = (e: React.FormEvent) => {
      e.preventDefault();
      if (!newStaffName.trim()) return;
      
      let isHead = isHeadOfDept;
      if (newStaffSystemRole === 'restaurant_manager' || newStaffSystemRole === 'cafe_manager') isHead = true; 

      const finalName = `${newStaffName} (${selectedJobTitle})`;
      addStaff(finalName, newStaffSystemRole, newStaffDept, isHead, Number(newStaffSalary) || 0, newStaffPin);
      setShowAddModal(false);
  };

  const filteredUsers = activeDept === 'all' ? users : users.filter(u => u.department === activeDept);

  const canViewSensitiveInfo = currentUser?.role === 'manager' || currentUser?.role === 'hr_manager' || currentUser?.role === 'assistant_manager';

  return (
    <div className="space-y-8 pb-10">
        <div className="flex flex-col md:flex-row justify-between items-end gap-4">
            <div className="flex-1 w-full"><PageHeader pageKey="staff" defaultTitle="إدارة الموارد البشرية" icon={Users} /></div>
            {activeTab === 'directory' && <button onClick={() => setShowAddModal(true)} className={`px-8 py-4 rounded-2xl font-black shadow-lg flex items-center gap-2 ${ts.button}`}><UserPlus size={20}/> تسجيل جديد</button>}
            {activeTab === 'leaves' && <button onClick={() => setShowLeaveModal(true)} className={`px-8 py-4 rounded-2xl font-black shadow-lg flex items-center gap-2 ${ts.button}`}><Plane size={20}/> طلب إجازة</button>}
            {activeTab === 'attendance' && isManager && (
                <button onClick={() => setShowManualAttendanceModal(true)} className={`px-8 py-4 rounded-2xl font-black shadow-lg flex items-center gap-2 ${ts.button}`}>
                    <Clock size={20}/> تسجيل يدوي
                </button>
            )}
        </div>

        <div className="flex justify-center mb-6">
            <div className={`p-1.5 rounded-2xl flex items-center gap-2 border ${ts.sectionCard}`}>
                <button onClick={() => setActiveTab('directory')} className={`px-6 py-2.5 rounded-xl font-bold flex items-center gap-2 transition-all ${activeTab === 'directory' ? ts.activeTab : ts.tabInactive}`}><Users size={18}/> دليل الموظفين</button>
                <button onClick={() => setActiveTab('attendance')} className={`px-6 py-2.5 rounded-xl font-bold flex items-center gap-2 transition-all ${activeTab === 'attendance' ? ts.activeTab : ts.tabInactive}`}><Fingerprint size={18}/> الحضور والانصراف</button>
                <button onClick={() => setActiveTab('leaves')} className={`px-6 py-2.5 rounded-xl font-bold flex items-center gap-2 transition-all ${activeTab === 'leaves' ? ts.activeTab : ts.tabInactive}`}><Plane size={18}/> الإجازات والعطل</button>
            </div>
        </div>

        {/* --- DIRECTORY TAB --- */}
        {activeTab === 'directory' && (
            <>
                {/* ... Dept Filters ... */}
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                    {filteredUsers.map(user => {
                        const deptInfo = getDeptInfo(user.department);
                        return (
                            <StaffCard 
                                key={user.id} 
                                user={user} 
                                deptInfo={deptInfo} 
                                settings={settings} 
                                onClick={() => setActiveProfile(user)} 
                            />
                        );
                    })}
                </div>
            </>
        )}

        {/* --- ATTENDANCE TAB (NEW) --- */}
        {activeTab === 'attendance' && (
            <div className="animate-fade-in space-y-6">
                
                {/* Stats */}
                <div className="grid grid-cols-3 gap-4">
                    <div className={`p-6 rounded-[2rem] border shadow-sm text-center ${ts.sectionCard}`}>
                        <span className="block text-4xl font-black text-blue-600 mb-1">{users.length}</span>
                        <span className={`text-xs font-bold uppercase ${ts.textSecondary}`}>إجمالي الموظفين</span>
                    </div>
                    <div className={`p-6 rounded-[2rem] border shadow-sm text-center ${ts.sectionCard}`}>
                        <span className="block text-4xl font-black text-green-600 mb-1">{attendanceRecords.filter(r => r.date === today && r.status === 'present').length}</span>
                        <span className={`text-xs font-bold uppercase ${ts.textSecondary}`}>حضور اليوم</span>
                    </div>
                    <div className={`p-6 rounded-[2rem] border shadow-sm text-center ${ts.sectionCard}`}>
                        <span className="block text-4xl font-black text-red-600 mb-1">{attendanceRecords.filter(r => r.date === today && r.status === 'late').length}</span>
                        <span className={`text-xs font-bold uppercase ${ts.textSecondary}`}>تأخرات</span>
                    </div>
                </div>

                {/* Attendance List */}
                <div className={`rounded-[2.5rem] shadow-sm border p-6 ${ts.sectionCard}`}>
                    <h3 className={`font-black text-lg mb-6 flex items-center gap-2 ${ts.textPrimary}`}><Fingerprint className="text-blue-500"/> سجل الحضور اليومي ({today})</h3>
                    <div className="space-y-3">
                        {users.map(user => {
                            const record = getTodayRecord(user.id);
                            const deptInfo = getDeptInfo(user.department);
                            const style = getDeptStyle(deptInfo);
                            return (
                                <div key={user.id} className={`flex items-center justify-between p-3 rounded-2xl border hover:shadow-sm transition ${ts.card}`}>
                                    <div className="flex items-center gap-3">
                                        <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${style.color.replace('text-', 'bg-')} ${settings.theme === 'zellige' ? 'text-[#001e21]' : 'text-white'}`}>
                                            {user.name.charAt(0)}
                                        </div>
                                        <div>
                                            <h4 className={`font-bold text-sm ${ts.textPrimary}`}>{user.name}</h4>
                                            <p className={`text-[10px] ${ts.textSecondary}`}>{deptInfo.label}</p>
                                        </div>
                                    </div>
                                    
                                    <div className="flex items-center gap-3">
                                        {record ? (
                                            <>
                                                <div className={`px-3 py-1 rounded-lg text-xs font-bold flex items-center gap-1 ${record.status === 'late' ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
                                                    {record.status === 'late' ? <><AlertCircle size={12}/> متأخر ({record.lateDurationMinutes}د)</> : <><CheckCircle2 size={12}/> حاضر</>}
                                                </div>
                                                <div className={`text-[10px] font-mono ${ts.textSecondary}`}>
                                                    <div>In: {new Date(record.checkInTime!).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</div>
                                                    {record.checkOutTime && <div>Out: {new Date(record.checkOutTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</div>}
                                                </div>
                                                
                                                {/* Actions */}
                                                {!record.checkOutTime && (
                                                    <button onClick={() => handleManualCheckOut(user.id)} className="p-2 bg-red-50 text-red-500 rounded-lg hover:bg-red-100" title="تسجيل خروج يدوي"><LogOut size={16}/></button>
                                                )}
                                                {isManager && (
                                                    <button onClick={() => openEditAttendance(record)} className="p-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200" title="تعديل السجل"><Edit size={16}/></button>
                                                )}
                                            </>
                                        ) : (
                                            <button onClick={() => handleManualCheckIn(user.id)} className="px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold shadow-md hover:bg-blue-700 flex items-center gap-2">
                                                <LogIn size={14}/> تسجيل دخول
                                            </button>
                                        )}
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </div>
        )}

        {/* --- LEAVES TAB --- */}
        {activeTab === 'leaves' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fade-in">
                {leaveRequests.map(req => (
                    <div key={req.id} className={`p-5 rounded-[2rem] shadow-sm border border-gray-100 ${ts.card}`}>
                        <div className="flex justify-between items-start mb-3">
                            <span className={`px-3 py-1 rounded-full text-[10px] font-bold ${req.status === 'approved' ? 'bg-green-100 text-green-700' : req.status === 'rejected' ? 'bg-red-100 text-red-700' : 'bg-orange-100 text-orange-700'}`}>{req.status}</span>
                            <span className={`text-xs font-bold ${ts.textSecondary}`}>{new Date(req.createdAt).toLocaleDateString()}</span>
                        </div>
                        <h4 className={`font-black mb-1 ${ts.textPrimary}`}>{req.userName}</h4>
                        <div className={`text-xs font-bold mb-4 flex items-center gap-2 ${ts.textSecondary}`}>
                            {req.type === 'sick' ? <Thermometer size={14} className="text-red-500"/> : <Plane size={14} className="text-blue-500"/>}
                            {req.type} • {req.daysCount} أيام
                        </div>
                        {req.status === 'pending' && isManager && (
                            <div className="flex gap-2">
                                <button onClick={() => updateLeaveStatus(req.id, 'approved')} className="flex-1 py-2 bg-green-500 text-white rounded-xl text-xs font-bold">قبول</button>
                                <button onClick={() => updateLeaveStatus(req.id, 'rejected', 'إداري')} className="flex-1 py-2 bg-red-100 text-red-600 rounded-xl text-xs font-bold">رفض</button>
                            </div>
                        )}
                    </div>
                ))}
            </div>
        )}

        {/* Add Staff Modal */}
        {showAddModal && (
            <div className="fixed inset-0 bg-black/60 z-[100] flex items-center justify-center p-4">
                <div className={`w-full max-w-lg rounded-[2.5rem] p-6 ${ts.modalBg} relative overflow-hidden`}>
                    {(isZellige || (settings.darkMode && settings.theme === 'zellige')) && <div className={`absolute inset-0 pointer-events-none ${ts.badgePattern}`}></div>}
                    <div className={`flex justify-between items-center mb-6 relative z-10 ${ts.modalHeader} p-4 -mx-6 -mt-6`}>
                        <h3 className="font-black text-xl">إضافة موظف</h3>
                        <button onClick={() => setShowAddModal(false)}><X/></button>
                    </div>
                    {/* ... Form inputs omitted for brevity, same as previous ... */}
                    <div className="space-y-4">
                        <input type="text" placeholder="الاسم" value={newStaffName} onChange={e => setNewStaffName(e.target.value)} className={`w-full p-3 rounded-xl border-2 ${ts.modalInput}`} />
                        <select value={newStaffDept} onChange={e => setNewStaffDept(e.target.value as any)} className={`w-full p-3 rounded-xl border-2 ${ts.modalInput}`}>
                            {departments.map(d => <option key={d.id} value={d.id}>{d.label}</option>)}
                        </select>
                        <select value={newStaffSystemRole} onChange={e => setNewStaffSystemRole(e.target.value as any)} className={`w-full p-3 rounded-xl border-2 ${ts.modalInput}`}>
                            <option value="manager">المدير العام</option>
                            <option value="assistant_manager">مساعد المدير</option>
                            <option value="operations_manager">مدير العمليات</option>
                            <option value="reception_manager">مدير الاستقبال</option>
                            <option value="receptionist">موظف استقبال</option>
                            <option value="restaurant_manager">مدير المطعم</option>
                            <option value="head_chef">كبير الطهاة</option>
                            <option value="chef">طاهي</option>
                            <option value="waiter">نادل</option>
                            <option value="cafe_manager">مدير المقهى</option>
                            <option value="barista">باريستا</option>
                            <option value="housekeeping_manager">مدير التدبير المنزلي</option>
                            <option value="housekeeping_staff">عامل نظافة</option>
                            <option value="maintenance_manager">مدير الصيانة</option>
                            <option value="maintenance_staff">فني صيانة</option>
                            <option value="security_manager">مدير الأمن</option>
                            <option value="security_guard">حارس أمن</option>
                            <option value="hr_manager">مدير الموارد البشرية</option>
                            <option value="accountant">محاسب</option>
                            <option value="marketing_specialist">مسؤول تسويق</option>
                            <option value="it_specialist">مسؤول IT</option>
                            <option value="concierge">كونسيرج</option>
                            <option value="bellboy">حامل الحقائب</option>
                            <option value="driver">سائق</option>
                            <option value="staff">موظف عام</option>
                        </select>
                        <input type="number" placeholder="الراتب" value={newStaffSalary} onChange={e => setNewStaffSalary(e.target.value)} className={`w-full p-3 rounded-xl border-2 ${ts.modalInput}`} />
                    </div>
                    <button onClick={handleAddStaff} className={`w-full py-4 rounded-xl font-bold text-white mt-6 ${ts.button}`}>حفظ</button>
                </div>
            </div>
        )}

        {/* Manual Attendance Modal */}
        {showManualAttendanceModal && (
            <div className="fixed inset-0 bg-black/60 z-[100] flex items-center justify-center p-4 backdrop-blur-sm">
                <div className={`w-full max-w-md rounded-[2.5rem] p-6 shadow-2xl ${ts.modalBg}`}>
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="font-black text-xl flex items-center gap-2"><Clock size={20}/> تسجيل حضور يدوي</h3>
                        <button onClick={() => setShowManualAttendanceModal(false)}><X/></button>
                    </div>
                    <form onSubmit={handleManualEntrySubmit} className="space-y-4">
                        <div>
                            <label className={`block text-xs font-bold mb-2 ${ts.inputLabel}`}>الموظف</label>
                            <select 
                                value={manualAttUser} 
                                onChange={e => setManualAttUser(e.target.value)}
                                className={`w-full p-3 rounded-xl border-2 outline-none font-bold ${ts.modalInput}`}
                                required
                            >
                                <option value="">-- اختر الموظف --</option>
                                {users.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                            </select>
                        </div>
                        <div>
                            <label className={`block text-xs font-bold mb-2 ${ts.inputLabel}`}>وقت الدخول</label>
                            <input 
                                type="time" 
                                value={manualAttTime}
                                onChange={e => setManualAttTime(e.target.value)}
                                className={`w-full p-3 rounded-xl border-2 outline-none font-bold ${ts.modalInput}`}
                                required
                            />
                        </div>
                        <button type="submit" className={`w-full py-3 rounded-xl font-bold text-white mt-4 ${ts.button}`}>
                            تأكيد التسجيل
                        </button>
                    </form>
                </div>
            </div>
        )}

        {/* Edit Attendance Record Modal */}
        {showAttendanceEditModal && (
            <div className="fixed inset-0 bg-black/60 z-[100] flex items-center justify-center p-4 backdrop-blur-sm">
                <div className={`w-full max-w-md rounded-[2.5rem] p-6 shadow-2xl ${ts.modalBg}`}>
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="font-black text-xl flex items-center gap-2"><Edit size={20}/> تعديل سجل الحضور</h3>
                        <button onClick={() => setShowAttendanceEditModal(null)}><X/></button>
                    </div>
                    <div className="space-y-4">
                        <div className="text-center mb-4">
                            <h4 className={`font-bold text-lg ${ts.textPrimary}`}>{showAttendanceEditModal.userName}</h4>
                            <p className={`text-xs ${ts.textSecondary}`}>{showAttendanceEditModal.date}</p>
                        </div>
                        <div>
                            <label className={`block text-xs font-bold mb-2 ${ts.inputLabel}`}>وقت الدخول</label>
                            <input 
                                type="time" 
                                value={editAttTimeIn}
                                onChange={e => setEditAttTimeIn(e.target.value)}
                                className={`w-full p-3 rounded-xl border-2 outline-none font-bold ${ts.modalInput}`}
                            />
                        </div>
                        <div>
                            <label className={`block text-xs font-bold mb-2 ${ts.inputLabel}`}>وقت الخروج</label>
                            <input 
                                type="time" 
                                value={editAttTimeOut}
                                onChange={e => setEditAttTimeOut(e.target.value)}
                                className={`w-full p-3 rounded-xl border-2 outline-none font-bold ${ts.modalInput}`}
                            />
                        </div>
                        <div className={`p-3 rounded-xl text-xs border ${settings.darkMode && settings.theme === 'zellige' ? 'bg-[#cca43b]/10 text-[#cca43b] border-[#cca43b]/30' : (isZellige ? 'bg-[#cca43b]/10 text-[#006269] border-[#cca43b]/30' : 'bg-yellow-50 text-yellow-800 border-yellow-200')}`}>
                            تنبيه: تعديل وقت الدخول سيؤدي تلقائياً إلى إعادة حساب التأخير والخصم المالي في النظام المحاسبي.
                        </div>
                        <button onClick={handleSaveAttendanceEdit} className={`w-full py-3 rounded-xl font-bold text-white mt-4 ${ts.button}`}>
                            حفظ التغييرات
                        </button>
                    </div>
                </div>
            </div>
        )}

        {/* --- LEAVE REQUEST MODAL --- */}
        {showLeaveModal && (
            <div className="fixed inset-0 bg-black/60 z-[100] flex items-center justify-center p-4 backdrop-blur-sm">
                <div className={`w-full max-w-lg rounded-[2.5rem] p-6 ${ts.modalBg}`}>
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="font-black text-xl flex items-center gap-2"><Plane/> طلب إجازة</h3>
                        <button onClick={() => setShowLeaveModal(false)}><X/></button>
                    </div>
                    <form onSubmit={handleLeaveSubmit} className="space-y-4">
                        <div>
                            <label className={`block text-xs font-bold mb-2 ${ts.inputLabel}`}>نوع الإجازة</label>
                            <select value={newLeave.type} onChange={e => setNewLeave({...newLeave, type: e.target.value as LeaveType})} className={`w-full p-3 rounded-xl border-2 font-bold outline-none ${ts.modalInput}`}>
                                <option value="annual">سنوية (Annual)</option>
                                <option value="sick">مرضية (Sick)</option>
                                <option value="unpaid">بدون راتب (Unpaid)</option>
                                <option value="recovery">تعويضية (Recovery)</option>
                                <option value="emergency">طارئة (Emergency)</option>
                            </select>
                        </div>
                        <div className="flex gap-4">
                            <div className="flex-1">
                                <label className={`block text-xs font-bold mb-2 ${ts.inputLabel}`}>من</label>
                                <input type="date" required value={newLeave.startDate} onChange={e => setNewLeave({...newLeave, startDate: e.target.value})} className={`w-full p-3 rounded-xl border-2 font-bold outline-none ${ts.modalInput}`} />
                            </div>
                            <div className="flex-1">
                                <label className={`block text-xs font-bold mb-2 ${ts.inputLabel}`}>إلى غاية</label>
                                <input type="date" required value={newLeave.endDate} onChange={e => setNewLeave({...newLeave, endDate: e.target.value})} className={`w-full p-3 rounded-xl border-2 font-bold outline-none ${ts.modalInput}`} />
                            </div>
                        </div>
                        <div>
                            <label className={`block text-xs font-bold mb-2 ${ts.inputLabel}`}>السبب / ملاحظات</label>
                            <textarea required value={newLeave.reason} onChange={e => setNewLeave({...newLeave, reason: e.target.value})} className={`w-full p-3 rounded-xl border-2 font-bold outline-none h-24 resize-none ${ts.modalInput}`} placeholder="سبب الغياب..." />
                        </div>
                        <div className="pt-4 flex gap-3">
                            <button type="button" onClick={() => setShowLeaveModal(false)} className="flex-1 py-3 bg-gray-200 rounded-xl font-bold text-gray-600">إلغاء</button>
                            <button type="submit" className={`flex-[2] py-3 rounded-xl font-bold shadow-lg ${ts.button}`}>إرسال الطلب</button>
                        </div>
                    </form>
                </div>
            </div>
        )}
    </div>
  );
};
