
import React, { useState, useRef } from 'react';
import { useHotel } from '../context/HotelContext';
import { PageHeader } from '../components/PageHeader';
import { Settings, Save, Moon, Sun, Type, Palette, Wifi, Server, Globe, Key, Printer, Monitor, Shield, ExternalLink, Network, LayoutGrid, Database, Upload, Download, AlertTriangle } from 'lucide-react';
import { AppTheme } from '../types';
import { downloadBackup, importDatabase } from '../utils/backup';

export const SettingsPage: React.FC = () => {
  const { settings, updateSettings, toggleDarkMode, addNotification } = useHotel();
  const [formData, setFormData] = useState(settings);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleBackup = async () => {
      await downloadBackup();
      addNotification('تم تحميل النسخة الاحتياطية بنجاح', "success");
  };

  const handleRestore = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      if (!window.confirm('تحذير: استعادة النسخة الاحتياطية ستقوم بحذف جميع البيانات الحالية واستبدالها. هل أنت متأكد؟')) {
          return;
      }

      const success = await importDatabase(file);
      if (success) {
          addNotification('تمت استعادة البيانات بنجاح. سيتم إعادة تحميل التطبيق.', "success");
          window.location.reload();
      } else {
          addNotification('فشل في استعادة البيانات. تأكد من صحة الملف.', "error");
      }
  };

  const getThemeStyles = () => {
      // Radical Fix: Dark mode overrides all themes for consistency but respects theme identity
      if (settings.darkMode) {
          if (settings.theme === 'zellige') {
              return {
                  button: 'bg-[#cca43b] text-[#002a2d] hover:bg-[#b08d30] font-bold',
                  card: 'bg-[#002a2d] border border-[#cca43b]/40 text-[#f0c04a]',
                  input: 'border-[#cca43b]/40 focus:border-[#f0c04a] bg-[#001e21] text-[#f0c04a] placeholder-[#cca43b]/40',
                  activeItem: 'border-[#cca43b] bg-[#cca43b]/10 text-[#f0c04a]',
                  itemBg: 'bg-[#001e21] text-[#f0c04a] border border-[#cca43b]/10 hover:bg-[#cca43b]/5',
                  marketingCard: 'bg-gradient-to-br from-[#002a2d] to-[#001e21] text-[#f0c04a] border-[#cca43b]',
                  integrationsCard: 'bg-[#002a2d]/50 border-[#cca43b]/20'
              };
          }
          if (settings.theme === 'algerian-military') {
              return {
                  button: 'bg-[#D4AF37] text-[#1a211a] hover:bg-[#b08d30] border border-[#D4AF37]',
                  card: 'bg-[#0f140f] border border-[#D4AF37]/40 text-[#D4AF37]',
                  input: 'border-[#D4AF37]/40 focus:border-[#D4AF37] bg-[#0f140f] text-[#D4AF37] placeholder-[#D4AF37]/40',
                  activeItem: 'border-[#D4AF37] bg-[#D4AF37]/10 text-[#D4AF37]',
                  itemBg: 'bg-[#1a211a] text-[#D4AF37] border border-[#D4AF37]/10 hover:bg-[#D4AF37]/5',
                  marketingCard: 'bg-gradient-to-br from-[#1a211a] to-[#0f140f] text-[#D4AF37] border-[#D4AF37]',
                  integrationsCard: 'bg-[#1a211a]/50 border-[#D4AF37]/20'
              };
          }
          if (settings.theme === 'zellige-algiers') {
              return {
                  button: 'bg-[#1e3a8a] text-[#f8fafc] hover:bg-[#172554] border border-[#f8fafc]/20',
                  card: 'bg-[#0f172a] border border-[#1e3a8a]/40 text-[#f8fafc]',
                  input: 'border-[#1e3a8a]/40 focus:border-[#1e3a8a] bg-[#1e293b] text-[#f8fafc] placeholder-[#1e3a8a]/40',
                  activeItem: 'border-[#1e3a8a] bg-[#1e3a8a]/20 text-[#f8fafc]',
                  itemBg: 'bg-[#1e293b] text-[#f8fafc] border border-[#1e3a8a]/20 hover:bg-[#1e3a8a]/10',
                  marketingCard: 'bg-gradient-to-br from-[#0f172a] to-[#1e293b] text-[#f8fafc] border-[#1e3a8a]',
                  integrationsCard: 'bg-[#0f172a]/50 border-[#1e3a8a]/20'
              };
          }
          if (settings.theme === 'zellige-tlemcen') {
              return {
                  button: 'bg-[#b45309] text-[#fffbeb] hover:bg-[#92400e] border border-[#064e3b]/20',
                  card: 'bg-[#271c19] border border-[#b45309]/40 text-[#fffbeb]',
                  input: 'border-[#b45309]/40 focus:border-[#b45309] bg-[#3f2e25] text-[#fffbeb] placeholder-[#b45309]/40',
                  activeItem: 'border-[#b45309] bg-[#b45309]/20 text-[#fffbeb]',
                  itemBg: 'bg-[#3f2e25] text-[#fffbeb] border border-[#b45309]/20 hover:bg-[#b45309]/10',
                  marketingCard: 'bg-gradient-to-br from-[#271c19] to-[#3f2e25] text-[#fffbeb] border-[#b45309]',
                  integrationsCard: 'bg-[#271c19]/50 border-[#b45309]/20'
              };
          }
          if (settings.theme === 'zellige-sahara') {
              return {
                  button: 'bg-[#d97706] text-[#fff7ed] hover:bg-[#b45309] border border-[#1e40af]/20',
                  card: 'bg-[#2a1b12] border border-[#d97706]/40 text-[#fff7ed]',
                  input: 'border-[#d97706]/40 focus:border-[#d97706] bg-[#432c1c] text-[#fff7ed] placeholder-[#d97706]/40',
                  activeItem: 'border-[#d97706] bg-[#d97706]/20 text-[#fff7ed]',
                  itemBg: 'bg-[#432c1c] text-[#fff7ed] border border-[#d97706]/20 hover:bg-[#d97706]/10',
                  marketingCard: 'bg-gradient-to-br from-[#2a1b12] to-[#432c1c] text-[#fff7ed] border-[#d97706]',
                  integrationsCard: 'bg-[#2a1b12]/50 border-[#d97706]/20'
              };
          }
          if (settings.theme === 'zellige-chaoui') {
              return {
                  button: 'bg-[#8b4513] text-[#fff8dc] hover:bg-[#d2691e] border border-[#ffd700]/20',
                  card: 'bg-[#2f1b0c] border border-[#8b4513]/40 text-[#ffd700]',
                  input: 'border-[#8b4513]/40 focus:border-[#8b4513] bg-[#3e2b1f] text-[#ffd700] placeholder-[#8b4513]/40',
                  activeItem: 'border-[#8b4513] bg-[#8b4513]/20 text-[#ffd700]',
                  itemBg: 'bg-[#3e2b1f] text-[#ffd700] border border-[#8b4513]/20 hover:bg-[#8b4513]/10',
                  marketingCard: 'bg-gradient-to-br from-[#2f1b0c] to-[#3e2b1f] text-[#ffd700] border-[#8b4513]',
                  integrationsCard: 'bg-[#2f1b0c]/50 border-[#8b4513]/20'
              };
          }
          if (settings.theme === 'zellige-tergui') {
              return {
                  button: 'bg-[#4b0082] text-[#c0c0c0] hover:bg-[#191970] border border-[#c0c0c0]/20',
                  card: 'bg-[#0a0a2a] border border-[#4b0082]/40 text-[#c0c0c0]',
                  input: 'border-[#4b0082]/40 focus:border-[#4b0082] bg-[#151535] text-[#c0c0c0] placeholder-[#4b0082]/40',
                  activeItem: 'border-[#4b0082] bg-[#4b0082]/20 text-[#c0c0c0]',
                  itemBg: 'bg-[#151535] text-[#c0c0c0] border border-[#4b0082]/20 hover:bg-[#4b0082]/10',
                  marketingCard: 'bg-gradient-to-br from-[#0a0a2a] to-[#151535] text-[#c0c0c0] border-[#4b0082]',
                  integrationsCard: 'bg-[#0a0a2a]/50 border-[#4b0082]/20'
              };
          }
          if (settings.theme === 'zellige-mozabite') {
              return {
                  button: 'bg-[#a0522d] text-[#f5deb3] hover:bg-[#8b4513] border border-[#f5deb3]/20',
                  card: 'bg-[#1c1c1c] border border-[#a0522d]/40 text-[#f5deb3]',
                  input: 'border-[#a0522d]/40 focus:border-[#a0522d] bg-[#2a2a2a] text-[#f5deb3] placeholder-[#a0522d]/40',
                  activeItem: 'border-[#a0522d] bg-[#a0522d]/20 text-[#f5deb3]',
                  itemBg: 'bg-[#2a2a2a] text-[#f5deb3] border border-[#a0522d]/20 hover:bg-[#a0522d]/10',
                  marketingCard: 'bg-gradient-to-br from-[#1c1c1c] to-[#2a2a2a] text-[#f5deb3] border-[#a0522d]',
                  integrationsCard: 'bg-[#1c1c1c]/50 border-[#a0522d]/20'
              };
          }
          return {
              button: 'bg-blue-600 text-white hover:bg-blue-700',
              card: 'bg-gray-800 border border-gray-700 text-white',
              input: 'border-gray-600 bg-gray-800 text-white',
              activeItem: 'border-blue-500 bg-blue-900/20',
              itemBg: 'bg-gray-700 text-white border border-gray-600 hover:bg-gray-600',
              marketingCard: 'bg-gradient-to-br from-gray-900 to-black text-white border-gray-700',
              integrationsCard: 'bg-gray-900/50 border-gray-700'
          };
      }

      switch (settings.theme) {
          case 'zellige': return {
              button: 'bg-[#006269] text-[#cca43b] hover:bg-[#004d53]',
              card: 'bg-[#fdfbf7] border border-[#cca43b]/40 text-[#006269]',
              input: 'border-[#cca43b]/40 focus:border-[#006269] bg-[#fbf8f1] text-[#006269]',
              activeItem: 'border-[#006269] bg-[#006269]/10',
              itemBg: 'bg-[#fbf8f1] text-[#006269] border border-[#cca43b]/20 hover:bg-[#cca43b]/10',
              marketingCard: 'bg-gradient-to-br from-[#006269] to-[#004d53] text-white border-[#cca43b]',
              integrationsCard: 'bg-[#006269]/5 border-[#006269]/20'
          };
          case 'algerian-military': return {
              button: 'bg-[#2F3E2E] text-[#D4AF37] hover:bg-[#4B5320] border border-[#D4AF37]',
              card: 'bg-[#F0EFEA] border border-[#D4AF37]/40 text-[#2F3E2E]',
              input: 'border-[#D4AF37]/40 focus:border-[#2F3E2E] bg-[#F0EFEA] text-[#2F3E2E]',
              activeItem: 'border-[#2F3E2E] bg-[#2F3E2E]/10',
              itemBg: 'bg-[#E5E5E0] text-[#2F3E2E] border border-[#D4AF37]/20 hover:bg-[#D4AF37]/10',
              marketingCard: 'bg-gradient-to-br from-[#2F3E2E] to-[#1a211a] text-[#D4AF37] border-[#D4AF37]',
              integrationsCard: 'bg-[#2F3E2E]/5 border-[#D4AF37]/20'
          };
          case 'zellige-algiers': return {
              button: 'bg-[#1e3a8a] text-[#f8fafc] hover:bg-[#172554] border border-[#f8fafc]/20',
              card: 'bg-[#eff6ff] border border-[#1e3a8a]/20 text-[#1e3a8a]',
              input: 'border-[#1e3a8a]/20 focus:border-[#1e3a8a] bg-white text-[#1e3a8a]',
              activeItem: 'border-[#1e3a8a] bg-[#1e3a8a]/10',
              itemBg: 'bg-white text-[#1e3a8a] border border-[#1e3a8a]/10 hover:bg-[#eff6ff]',
              marketingCard: 'bg-gradient-to-br from-[#1e3a8a] to-[#172554] text-white border-[#f8fafc]/20',
              integrationsCard: 'bg-[#1e3a8a]/5 border-[#1e3a8a]/20'
          };
          case 'zellige-tlemcen': return {
              button: 'bg-[#b45309] text-[#fffbeb] hover:bg-[#92400e] border border-[#064e3b]/20',
              card: 'bg-[#fffbeb] border border-[#b45309]/20 text-[#064e3b]',
              input: 'border-[#b45309]/20 focus:border-[#b45309] bg-white text-[#064e3b]',
              activeItem: 'border-[#b45309] bg-[#b45309]/10',
              itemBg: 'bg-white text-[#064e3b] border border-[#b45309]/10 hover:bg-[#fffbeb]',
              marketingCard: 'bg-gradient-to-br from-[#b45309] to-[#92400e] text-white border-[#064e3b]/20',
              integrationsCard: 'bg-[#b45309]/5 border-[#b45309]/20'
          };
          case 'zellige-sahara': return {
              button: 'bg-[#d97706] text-[#fff7ed] hover:bg-[#b45309] border border-[#1e40af]/20',
              card: 'bg-[#fff7ed] border border-[#d97706]/20 text-[#1e40af]',
              input: 'border-[#d97706]/20 focus:border-[#d97706] bg-white text-[#1e40af]',
              activeItem: 'border-[#d97706] bg-[#d97706]/10',
              itemBg: 'bg-white text-[#1e40af] border border-[#d97706]/10 hover:bg-[#fff7ed]',
              marketingCard: 'bg-gradient-to-br from-[#d97706] to-[#b45309] text-white border-[#1e40af]/20',
              integrationsCard: 'bg-[#d97706]/5 border-[#d97706]/20'
          };
          case 'zellige-constantine': return {
              button: 'bg-[#5d4037] text-[#fafaf9] hover:bg-[#443029] border border-[#a8a29e]/20',
              card: 'bg-[#fafaf9] border border-[#5d4037]/20 text-[#1c1917]',
              input: 'border-[#5d4037]/20 focus:border-[#5d4037] bg-white text-[#1c1917]',
              activeItem: 'border-[#5d4037] bg-[#5d4037]/10',
              itemBg: 'bg-white text-[#1c1917] border border-[#5d4037]/10 hover:bg-[#fafaf9]',
              marketingCard: 'bg-gradient-to-br from-[#5d4037] to-[#443029] text-white border-[#a8a29e]/20',
              integrationsCard: 'bg-[#5d4037]/5 border-[#5d4037]/20'
          };
          case 'zellige-ghardaia': return {
              button: 'bg-[#ea580c] text-[#fff7ed] hover:bg-[#c2410c] border border-[#9a3412]/20',
              card: 'bg-[#fff7ed] border border-[#ea580c]/20 text-[#9a3412]',
              input: 'border-[#ea580c]/20 focus:border-[#ea580c] bg-white text-[#9a3412]',
              activeItem: 'border-[#ea580c] bg-[#ea580c]/10',
              itemBg: 'bg-white text-[#9a3412] border border-[#ea580c]/10 hover:bg-[#fff7ed]',
              marketingCard: 'bg-gradient-to-br from-[#ea580c] to-[#c2410c] text-white border-[#9a3412]/20',
              integrationsCard: 'bg-[#ea580c]/5 border-[#ea580c]/20'
          };
          case 'zellige-kabylie': return {
              button: 'bg-[#dc2626] text-[#fef2f2] hover:bg-[#b91c1c] border border-[#facc15]/20',
              card: 'bg-[#fef2f2] border border-[#dc2626]/20 text-[#16a34a]',
              input: 'border-[#dc2626]/20 focus:border-[#dc2626] bg-white text-[#16a34a]',
              activeItem: 'border-[#dc2626] bg-[#dc2626]/10',
              itemBg: 'bg-white text-[#16a34a] border border-[#dc2626]/10 hover:bg-[#fef2f2]',
              marketingCard: 'bg-gradient-to-br from-[#dc2626] to-[#b91c1c] text-white border-[#facc15]/20',
              integrationsCard: 'bg-[#dc2626]/5 border-[#dc2626]/20'
          };
          case 'zellige-chaoui': return {
              button: 'bg-[#8b4513] text-[#fff8dc] hover:bg-[#d2691e] border border-[#ffd700]/20',
              card: 'bg-[#fff8dc] border border-[#8b4513]/20 text-[#8b4513]',
              input: 'border-[#8b4513]/20 focus:border-[#8b4513] bg-white text-[#8b4513]',
              activeItem: 'border-[#8b4513] bg-[#8b4513]/10',
              itemBg: 'bg-white text-[#8b4513] border border-[#8b4513]/10 hover:bg-[#fff8dc]',
              marketingCard: 'bg-gradient-to-br from-[#8b4513] to-[#d2691e] text-white border-[#ffd700]/20',
              integrationsCard: 'bg-[#8b4513]/5 border-[#8b4513]/20'
          };
          case 'zellige-tergui': return {
              button: 'bg-[#191970] text-[#f0f8ff] hover:bg-[#4b0082] border border-[#c0c0c0]/20',
              card: 'bg-[#f0f8ff] border border-[#4b0082]/20 text-[#191970]',
              input: 'border-[#4b0082]/20 focus:border-[#4b0082] bg-white text-[#191970]',
              activeItem: 'border-[#4b0082] bg-[#4b0082]/10',
              itemBg: 'bg-white text-[#191970] border border-[#4b0082]/10 hover:bg-[#f0f8ff]',
              marketingCard: 'bg-gradient-to-br from-[#191970] to-[#4b0082] text-white border-[#c0c0c0]/20',
              integrationsCard: 'bg-[#191970]/5 border-[#191970]/20'
          };
          case 'zellige-mozabite': return {
              button: 'bg-[#a0522d] text-[#fffaf0] hover:bg-[#8b4513] border border-[#f5deb3]/20',
              card: 'bg-[#fffaf0] border border-[#a0522d]/20 text-[#a0522d]',
              input: 'border-[#a0522d]/20 focus:border-[#a0522d] bg-white text-[#a0522d]',
              activeItem: 'border-[#a0522d] bg-[#a0522d]/10',
              itemBg: 'bg-white text-[#a0522d] border border-[#a0522d]/10 hover:bg-[#fffaf0]',
              marketingCard: 'bg-gradient-to-br from-[#a0522d] to-[#8b4513] text-white border-[#f5deb3]/20',
              integrationsCard: 'bg-[#a0522d]/5 border-[#a0522d]/20'
          };
          case 'modern-ornate': return {
              button: 'bg-[#4a148c] text-[#ffd700] hover:bg-[#380d6b] border border-[#ffd700] shadow-md',
              card: 'bg-[#f3e5f5] border border-[#ffd700]/40 shadow-sm text-[#4a148c]',
              input: 'border-[#ffd700]/40 focus:border-[#4a148c] bg-white text-[#4a148c] placeholder-purple-300',
              activeItem: 'border-[#ffd700] bg-[#4a148c]/10 text-[#4a148c]',
              itemBg: 'bg-white text-[#4a148c] border border-[#ffd700]/20 hover:bg-[#f3e5f5]',
              marketingCard: 'bg-gradient-to-br from-[#4a148c] to-[#7c43bd] text-[#ffd700] border-[#ffd700]',
              integrationsCard: 'bg-[#4a148c]/5 border-[#4a148c]/20'
          };
          default: return {
              button: 'bg-blue-600 text-white hover:bg-blue-700',
              card: 'bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white',
              input: 'border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white',
              activeItem: 'border-blue-600 bg-blue-50 dark:bg-blue-900/20',
              itemBg: 'bg-gray-50 dark:bg-gray-700/50 border border-gray-200 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700',
              marketingCard: 'bg-gradient-to-br from-gray-900 to-black text-white border-gray-700',
              integrationsCard: 'bg-gray-50 dark:bg-gray-900/50 border-gray-200'
          };
      }
  };
  const ts = getThemeStyles();

  const handleSave = () => {
      updateSettings(formData);
      addNotification('تم حفظ الإعدادات بنجاح', "success");
  };

  const themes: { id: AppTheme; label: string; color: string }[] = [
      { id: 'default', label: 'الافتراضي (أزرق)', color: '#2563eb' },
      { id: 'zellige', label: 'زليج (أصيل)', color: '#006269' },
      { id: 'zellige-v2', label: 'زليج (أخضر)', color: '#024d38' },
      { id: 'zellige-algiers', label: 'زليج (البهجة)', color: '#1e3a8a' },
      { id: 'zellige-tlemcen', label: 'زليج (تلمسان)', color: '#b45309' },
      { id: 'zellige-sahara', label: 'زليج (الصحراء)', color: '#d97706' },
      { id: 'zellige-constantine', label: 'زليج (قسنطينة)', color: '#5d4037' },
      { id: 'zellige-ghardaia', label: 'زليج (غرداية)', color: '#ea580c' },
      { id: 'zellige-kabylie', label: 'زليج (القبائل)', color: '#dc2626' },
      { id: 'zellige-chaoui', label: 'زليج (الشاوي)', color: '#8b4513' },
      { id: 'zellige-tergui', label: 'زليج (الترقي)', color: '#191970' },
      { id: 'zellige-mozabite', label: 'زليج (المزابي)', color: '#a0522d' },
      { id: 'instagram', label: 'عصري (Instagram)', color: '#E1306C' },
      { id: 'modern-ornate', label: 'زخرفي عصري (بنفسجي)', color: '#4a148c' },
      { id: 'real-madrid', label: 'ملكي', color: '#00529F' },
  ];

  return (
    <div className="space-y-6 pb-20 animate-fade-in">
        <PageHeader pageKey="settings" defaultTitle="إعدادات النظام" icon={Settings} />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* System Administration */}
            <div className={`p-6 rounded-[2.5rem] shadow-sm ${ts.card} lg:col-span-2`}>
                <h3 className="font-black text-lg mb-6 flex items-center gap-2"><Shield size={20}/> إدارة النظام والصلاحيات</h3>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <button onClick={() => window.dispatchEvent(new CustomEvent('navigate-to', { detail: 'permissions' }))} className={`p-4 rounded-2xl border-2 flex items-center gap-4 transition hover:scale-[1.02] ${ts.activeItem}`}>
                        <div className="p-3 bg-white/20 rounded-xl"><Key size={24}/></div>
                        <div className="text-right">
                            <h4 className="font-bold text-sm">صلاحيات الموظفين</h4>
                            <p className="text-[10px] opacity-70">تحديد الأدوار والوصول</p>
                        </div>
                    </button>
                    <button onClick={() => window.dispatchEvent(new CustomEvent('navigate-to', { detail: 'venues' }))} className={`p-4 rounded-2xl border-2 flex items-center gap-4 transition hover:scale-[1.02] ${ts.activeItem}`}>
                        <div className="p-3 bg-white/20 rounded-xl"><LayoutGrid size={24}/></div>
                        <div className="text-right">
                            <h4 className="font-bold text-sm">إدارة الصالات والطاولات</h4>
                            <p className="text-[10px] opacity-70">تخطيط المطعم والقاعات</p>
                        </div>
                    </button>
                    <button onClick={() => window.dispatchEvent(new CustomEvent('navigate-to', { detail: 'print_settings' }))} className={`p-4 rounded-2xl border-2 flex items-center gap-4 transition hover:scale-[1.02] ${ts.activeItem}`}>
                        <div className="p-3 bg-white/20 rounded-xl"><Printer size={24}/></div>
                        <div className="text-right">
                            <h4 className="font-bold text-sm">استوديو الطباعة</h4>
                            <p className="text-[10px] opacity-70">تخصيص البطاقات والفواتير</p>
                        </div>
                    </button>
                    
                    {/* Backup & Restore */}
                    <div className={`p-4 rounded-2xl border-2 flex flex-col gap-2 ${ts.activeItem}`}>
                        <h4 className="font-bold text-sm flex items-center gap-2"><Database size={16}/> النسخ الاحتياطي</h4>
                        <div className="flex gap-2 mt-1">
                            <button onClick={handleBackup} className={`flex-1 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1 transition ${settings.darkMode && settings.theme === 'zellige' ? 'bg-[#002a2d] text-[#cca43b] border border-[#cca43b]/30 hover:bg-[#cca43b]/10' : 'bg-green-600 text-white hover:bg-green-700'}`}>
                                <Download size={12}/> حفظ
                            </button>
                            <button onClick={() => fileInputRef.current?.click()} className={`flex-1 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1 transition ${settings.darkMode && settings.theme === 'zellige' ? 'bg-[#002a2d] text-[#cca43b] border border-[#cca43b]/30 hover:bg-[#cca43b]/10' : 'bg-orange-600 text-white hover:bg-orange-700'}`}>
                                <Upload size={12}/> استعادة
                            </button>
                            <input type="file" ref={fileInputRef} onChange={handleRestore} accept=".xlsx" className="hidden" />
                        </div>
                    </div>
                </div>
            </div>

            {/* Room Configuration */}
            <div className={`p-6 rounded-[2.5rem] shadow-sm ${ts.card} lg:col-span-2`}>
                <h3 className="font-black text-lg mb-6 flex items-center gap-2"><LayoutGrid size={20}/> إعدادات الغرف والمباني</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* Room Numbering Config */}
                    <div className="space-y-4">
                        <h4 className="text-sm font-bold opacity-80 border-b pb-2">تكوين الترقيم</h4>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-xs font-bold mb-2 opacity-70">إجمالي الغرف</label>
                                <input 
                                    type="number" 
                                    className={`w-full p-3 rounded-xl border-2 font-bold outline-none ${ts.input}`} 
                                    value={formData.totalRooms} 
                                    onChange={e => setFormData({...formData, totalRooms: parseInt(e.target.value) || 0})} 
                                />
                            </div>
                            <div>
                                <label className="block text-xs font-bold mb-2 opacity-70">رقم البداية</label>
                                <input 
                                    type="number" 
                                    className={`w-full p-3 rounded-xl border-2 font-bold outline-none ${ts.input}`} 
                                    value={formData.roomConfig?.startingNumber || 101} 
                                    onChange={e => setFormData({...formData, roomConfig: { ...formData.roomConfig, startingNumber: parseInt(e.target.value) || 101 }})} 
                                />
                            </div>
                            <div>
                                <label className="block text-xs font-bold mb-2 opacity-70">بادئة الغرفة (مثال: A-)</label>
                                <input 
                                    type="text" 
                                    className={`w-full p-3 rounded-xl border-2 font-bold outline-none ${ts.input}`} 
                                    value={formData.roomConfig?.prefix || ''} 
                                    onChange={e => setFormData({...formData, roomConfig: { ...formData.roomConfig, prefix: e.target.value }})} 
                                    dir="ltr"
                                />
                            </div>
                            <div>
                                <label className="block text-xs font-bold mb-2 opacity-70">عدد الطوابق</label>
                                <input 
                                    type="number" 
                                    className={`w-full p-3 rounded-xl border-2 font-bold outline-none ${ts.input}`} 
                                    value={formData.roomConfig?.floorCount || 1} 
                                    onChange={e => setFormData({...formData, roomConfig: { ...formData.roomConfig, floorCount: parseInt(e.target.value) || 1 }})} 
                                />
                            </div>
                        </div>
                        <div className="text-[10px] opacity-60 flex items-center gap-1 text-orange-500">
                            <AlertTriangle size={12} />
                            تغيير هذه الإعدادات قد يتطلب إعادة تعيين الغرف يدوياً أو تلقائياً.
                        </div>
                    </div>

                    {/* Building Management */}
                    <div className="space-y-4">
                        <h4 className="text-sm font-bold opacity-80 border-b pb-2 flex justify-between items-center">
                            <span>إدارة المباني والفروع</span>
                            <button 
                                onClick={() => {
                                    const newBuilding = { id: `b-${Date.now()}`, name: 'مبنى جديد', address: '', roomCount: 0, isActive: true };
                                    setFormData({ ...formData, buildings: [...(formData.buildings || []), newBuilding] });
                                }}
                                className="text-xs bg-blue-500/10 text-blue-500 px-2 py-1 rounded-lg hover:bg-blue-500/20 transition"
                            >
                                + إضافة مبنى
                            </button>
                        </h4>
                        
                        <div className="space-y-3 max-h-60 overflow-y-auto custom-scrollbar pr-2">
                            {(formData.buildings || []).map((building, index) => (
                                <div key={building.id} className={`p-3 rounded-xl border flex flex-col gap-2 ${ts.itemBg}`}>
                                    <div className="flex justify-between items-start">
                                        <input 
                                            type="text" 
                                            value={building.name}
                                            onChange={(e) => {
                                                const newBuildings = [...(formData.buildings || [])];
                                                newBuildings[index] = { ...building, name: e.target.value };
                                                setFormData({ ...formData, buildings: newBuildings });
                                            }}
                                            className="bg-transparent font-bold text-sm outline-none w-full"
                                            placeholder="اسم المبنى"
                                        />
                                        <button 
                                            onClick={() => {
                                                const newBuildings = (formData.buildings || []).filter(b => b.id !== building.id);
                                                setFormData({ ...formData, buildings: newBuildings });
                                            }}
                                            className="text-red-400 hover:text-red-500"
                                        >
                                            <AlertTriangle size={14} />
                                        </button>
                                    </div>
                                    <input 
                                        type="text" 
                                        value={building.address}
                                        onChange={(e) => {
                                            const newBuildings = [...(formData.buildings || [])];
                                            newBuildings[index] = { ...building, address: e.target.value };
                                            setFormData({ ...formData, buildings: newBuildings });
                                        }}
                                        className="bg-transparent text-xs opacity-70 outline-none w-full"
                                        placeholder="العنوان"
                                    />
                                    <div className="flex items-center gap-2 text-xs opacity-60">
                                        <span>عدد الغرف:</span>
                                        <input 
                                            type="number" 
                                            value={building.roomCount}
                                            onChange={(e) => {
                                                const newBuildings = [...(formData.buildings || [])];
                                                newBuildings[index] = { ...building, roomCount: parseInt(e.target.value) || 0 };
                                                setFormData({ ...formData, buildings: newBuildings });
                                            }}
                                            className="bg-transparent w-12 outline-none border-b border-gray-500/20 text-center"
                                        />
                                    </div>
                                </div>
                            ))}
                            {(formData.buildings || []).length === 0 && (
                                <div className="text-center py-4 opacity-50 text-xs">لا يوجد مباني إضافية</div>
                            )}
                        </div>
                    </div>
                </div>
            </div>

            {/* General Info */}
            <div className={`p-6 rounded-[2.5rem] shadow-sm ${ts.card}`}>
                <h3 className="font-black text-lg mb-6 flex items-center gap-2"><Type size={20}/> معلومات الفندق</h3>
                <div className="space-y-4">
                    <div>
                        <label className="block text-xs font-bold mb-2 opacity-70">اسم الفندق</label>
                        <input type="text" className={`w-full p-4 rounded-2xl border-2 font-bold outline-none ${ts.input}`} value={formData.appName} onChange={e => setFormData({...formData, appName: e.target.value})} />
                    </div>
                    <div>
                        <label className="block text-xs font-bold mb-2 opacity-70">العنوان</label>
                        <input type="text" className={`w-full p-4 rounded-2xl border-2 font-bold outline-none ${ts.input}`} value={formData.hotelAddress} onChange={e => setFormData({...formData, hotelAddress: e.target.value})} />
                    </div>
                    <div>
                        <label className="block text-xs font-bold mb-2 opacity-70">الهاتف</label>
                        <input type="text" className={`w-full p-4 rounded-2xl border-2 font-bold outline-none ${ts.input}`} value={formData.hotelPhone} onChange={e => setFormData({...formData, hotelPhone: e.target.value})} />
                    </div>
                </div>
            </div>

            {/* Appearance */}
            <div className={`p-6 rounded-[2.5rem] shadow-sm ${ts.card}`}>
                <h3 className="font-black text-lg mb-6 flex items-center gap-2"><Palette size={20}/> المظهر والسمات</h3>
                
                <div className="mb-6">
                    <label className="block text-xs font-bold mb-3 opacity-70">الوضع الليلي</label>
                    <button onClick={toggleDarkMode} className={`flex items-center gap-3 p-3 rounded-2xl w-full transition ${ts.itemBg}`}>
                        {settings.darkMode ? <Moon size={20}/> : <Sun size={20}/>}
                        <span className="font-bold text-sm">{settings.darkMode ? 'مفعل (داكن)' : 'معطل (فاتح)'}</span>
                    </button>
                </div>

                <div className="mb-6">
                    <label className="block text-xs font-bold mb-3 opacity-70">السمة اللونية (Theme)</label>
                    <div className="grid grid-cols-2 gap-3">
                        {themes.map(theme => (
                            <button 
                                key={theme.id}
                                onClick={() => setFormData({...formData, theme: theme.id})}
                                className={`p-3 rounded-xl border-2 text-right transition flex items-center justify-between ${formData.theme === theme.id ? ts.activeItem : ts.itemBg}`}
                            >
                                <span className="text-xs font-bold">{theme.label}</span>
                                <div className="w-4 h-4 rounded-full" style={{backgroundColor: theme.color}}></div>
                            </button>
                        ))}
                    </div>
                </div>

                <div>
                    <label className="block text-xs font-bold mb-3 opacity-70">كثافة العرض</label>
                    <div className="flex gap-2">
                        {['compact', 'comfortable', 'spacious'].map((d: any) => (
                            <button 
                                key={d}
                                onClick={() => setFormData({...formData, gridDensity: d})}
                                className={`flex-1 py-2 rounded-xl text-xs font-bold capitalize transition border-2 ${formData.gridDensity === d ? ts.activeItem : ts.itemBg}`}
                            >
                                {d}
                            </button>
                        ))}
                    </div>
                </div>
            </div>
        </div>

        {/* --- SYSTEM & INTEGRATION HUB (ENHANCED) --- */}
        <div className={`p-8 rounded-[2.5rem] shadow-sm border ${ts.integrationsCard}`}>
            <h3 className="text-2xl font-black mb-8 flex items-center gap-3 border-b pb-4 border-gray-200 dark:border-gray-700">
                <Network size={28} className="text-blue-500" /> مركز الربط والأنظمة (Integration Hub)
            </h3>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                
                {/* 1. Network & Connectivity */}
                <div className="space-y-4">
                    <h4 className="text-sm font-bold flex items-center gap-2 opacity-80"><Wifi size={16}/> إعدادات الشبكة (Wi-Fi)</h4>
                    <div className={`p-5 rounded-2xl border ${ts.card}`}>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className="block text-xs font-bold mb-1 opacity-70">اسم شبكة النزلاء (SSID)</label>
                                <input 
                                    type="text" 
                                    className={`w-full p-3 rounded-xl border-2 font-bold outline-none ${ts.input}`}
                                    value={formData.systemIntegrations?.guestWifiSsid || ''}
                                    onChange={e => setFormData({...formData, systemIntegrations: { ...formData.systemIntegrations, guestWifiSsid: e.target.value }})}
                                    dir="ltr"
                                />
                            </div>
                            <div>
                                <label className="block text-xs font-bold mb-1 opacity-70">كلمة المرور</label>
                                <div className="relative">
                                    <input 
                                        type="text" 
                                        className={`w-full p-3 rounded-xl border-2 font-bold outline-none ${ts.input}`}
                                        value={formData.systemIntegrations?.guestWifiPass || ''}
                                        onChange={e => setFormData({...formData, systemIntegrations: { ...formData.systemIntegrations, guestWifiPass: e.target.value }})}
                                        dir="ltr"
                                    />
                                    <Key size={14} className="absolute left-3 top-1/2 -translate-y-1/2 opacity-30"/>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* 2. Hardware & Devices */}
                <div className="space-y-4">
                    <h4 className="text-sm font-bold flex items-center gap-2 opacity-80"><Server size={16}/> الأجهزة والعتاد (Hardware)</h4>
                    <div className={`p-5 rounded-2xl border ${ts.card}`}>
                        <div className="space-y-3">
                            <div>
                                <label className="block text-xs font-bold mb-1 opacity-70 flex items-center gap-2"><Printer size={12}/> طابعة الشبكة (IP)</label>
                                <input 
                                    type="text" 
                                    placeholder="192.168.1.200"
                                    className={`w-full p-3 rounded-xl border-2 font-mono font-bold outline-none ${ts.input}`}
                                    value={formData.systemIntegrations?.printerIp || ''}
                                    onChange={e => setFormData({...formData, systemIntegrations: { ...formData.systemIntegrations, printerIp: e.target.value }})}
                                    dir="ltr"
                                />
                            </div>
                            <div className="flex items-center justify-between p-2">
                                <label className="text-xs font-bold opacity-70 flex items-center gap-2"><Monitor size={12}/> وضع الكشك (Kiosk Mode)</label>
                                <input 
                                    type="checkbox"
                                    checked={formData.systemIntegrations?.kioskMode || false}
                                    onChange={e => setFormData({...formData, systemIntegrations: { ...formData.systemIntegrations, kioskMode: e.target.checked }})}
                                    className="w-5 h-5 rounded accent-blue-600"
                                />
                            </div>
                        </div>
                    </div>
                </div>

                {/* 3. External Integrations */}
                <div className="space-y-4">
                    <h4 className="text-sm font-bold flex items-center gap-2 opacity-80"><Globe size={16}/> أنظمة الحجز (OTA)</h4>
                    <div className={`p-5 rounded-2xl border ${ts.card}`}>
                        <div className="space-y-3">
                            <div>
                                <label className="block text-xs font-bold mb-1 opacity-70">محرك الحجز (Booking Engine)</label>
                                <input 
                                    type="text" 
                                    className={`w-full p-3 rounded-xl border-2 font-bold outline-none ${ts.input}`}
                                    value={formData.systemIntegrations?.bookingEngineUrl || ''}
                                    onChange={e => setFormData({...formData, systemIntegrations: { ...formData.systemIntegrations, bookingEngineUrl: e.target.value }})}
                                    dir="ltr"
                                />
                            </div>
                            <div>
                                <label className="block text-xs font-bold mb-1 opacity-70">إدارة القنوات (Channel Manager)</label>
                                <input 
                                    type="text" 
                                    className={`w-full p-3 rounded-xl border-2 font-bold outline-none ${ts.input}`}
                                    value={formData.systemIntegrations?.otaManagerUrl || ''}
                                    onChange={e => setFormData({...formData, systemIntegrations: { ...formData.systemIntegrations, otaManagerUrl: e.target.value }})}
                                    dir="ltr"
                                />
                            </div>
                        </div>
                    </div>
                </div>

                {/* 4. Government & Compliance */}
                <div className="space-y-4">
                    <h4 className="text-sm font-bold flex items-center gap-2 opacity-80"><Shield size={16}/> البوابات الحكومية والرسمية</h4>
                    <div className={`p-5 rounded-2xl border ${ts.card}`}>
                        <div className="space-y-3">
                            <div>
                                <label className="block text-xs font-bold mb-1 opacity-70 flex items-center gap-1">بوابة الشرطة (Police des Etrangers) <ExternalLink size={10}/></label>
                                <input 
                                    type="text" 
                                    className={`w-full p-3 rounded-xl border-2 font-bold outline-none ${ts.input}`}
                                    value={formData.systemIntegrations?.policePortalUrl || ''}
                                    onChange={e => setFormData({...formData, systemIntegrations: { ...formData.systemIntegrations, policePortalUrl: e.target.value }})}
                                    dir="ltr"
                                />
                            </div>
                            <div>
                                <label className="block text-xs font-bold mb-1 opacity-70 flex items-center gap-1">وزارة السياحة (الإحصائيات) <ExternalLink size={10}/></label>
                                <input 
                                    type="text" 
                                    className={`w-full p-3 rounded-xl border-2 font-bold outline-none ${ts.input}`}
                                    value={formData.systemIntegrations?.tourismPortalUrl || ''}
                                    onChange={e => setFormData({...formData, systemIntegrations: { ...formData.systemIntegrations, tourismPortalUrl: e.target.value }})}
                                    dir="ltr"
                                />
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div className="flex justify-end pt-4">
            <button onClick={handleSave} className={`px-10 py-4 rounded-2xl font-black shadow-xl flex items-center gap-3 transition transform hover:-translate-y-1 ${ts.button}`}>
                <Save size={20}/> حفظ كافة التغييرات
            </button>
        </div>
    </div>
  );
};
