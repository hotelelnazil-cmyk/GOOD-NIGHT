
import React, { useState } from 'react';
import { useHotel } from '../context/HotelContext';
import { PaymentModal } from '../components/PaymentModal';
import { Printer, MapPin, Phone, Mail, FileText, X, ExternalLink, CreditCard } from 'lucide-react';
import { Booking } from '../types';
import { PrintButton } from '../components/PrintButton';
import { QRCodeSVG } from 'qrcode.react';
import { renderToStaticMarkup } from 'react-dom/server';
import { printDocument } from '../utils/print';

export const InvoicesPage: React.FC = () => {
  const { invoices, settings, currentUser, bookings, rooms, addQRRecord, addNotification, updateInvoice, addTransaction } = useHotel();
  const [showQRModal, setShowQRModal] = useState<{ id: string, name: string, url: string } | null>(null);
  const [paymentModalData, setPaymentModalData] = useState<{ id: string, amount: number, guestName: string } | null>(null);
  const canPrint = settings.allowPrinting && currentUser?.permissions.canManageInvoices;

  // --- Theme Helper ---
  const getThemeStyles = () => {
      // Radical Fix: Dark mode overrides all themes for consistency but respects theme identity
      if (settings.darkMode) {
          if (settings.theme === 'zellige') {
              return {
                  tableHeader: 'bg-[#002a2d] text-[#cca43b] border-b-2 border-[#cca43b]/20',
                  button: 'hover:bg-[#cca43b]/10 text-[#cca43b] border-[#cca43b]/20 bg-[#001e21]'
              };
          }
           if (settings.theme === 'algerian-military') {
              return {
                  tableHeader: 'bg-[#1a211a] text-[#D4AF37] border-b-2 border-[#D4AF37]/30',
                  button: 'hover:bg-[#D4AF37]/10 text-[#D4AF37] border-[#D4AF37]/20 bg-[#0f140f]'
              };
          }
          return {
              tableHeader: 'bg-gray-800 text-gray-300 border-b-2 border-gray-700',
              button: 'hover:bg-gray-700 text-blue-400 border-gray-600'
          };
      }

      switch (settings.theme) {
          case 'zellige': return {
              tableHeader: 'bg-[#006269]/10 text-[#006269] border-b-2 border-[#cca43b]/20',
              button: 'hover:bg-[#cca43b]/10 text-[#006269] border-[#006269]/20'
          };
          case 'zellige-v2': return {
              tableHeader: 'bg-[#024d38]/10 text-[#024d38] border-b-2 border-[#c6e3d8]',
              button: 'hover:bg-[#c6e3d8]/20 text-[#024d38] border-[#024d38]/20'
          };
          case 'algerian-military': return {
              tableHeader: 'bg-[#2F3E2E]/10 text-[#2F3E2E] border-b-2 border-[#D4AF37]',
              button: 'hover:bg-[#D4AF37]/20 text-[#2F3E2E] border-[#2F3E2E]/20'
          };
          case 'instagram': return {
              tableHeader: 'bg-pink-50 text-pink-700 border-b-2 border-pink-100',
              button: 'hover:bg-pink-50 text-pink-600 border-pink-200'
          };
          default: return {
              tableHeader: 'bg-gray-50 dark:bg-gray-700 text-gray-600 dark:text-gray-300',
              button: 'hover:bg-blue-50 text-blue-600 border-blue-200'
          };
      }
  };
  const ts = getThemeStyles();

  const handlePaymentSuccess = (details: { method: 'cash' | 'card' | 'transfer'; cardInfo?: any }) => {
      if (paymentModalData) {
          updateInvoice(paymentModalData.id, { isPaid: true });
          addTransaction({
              amount: paymentModalData.amount,
              type: 'income',
              category: 'booking',
              description: `Invoice Payment #${paymentModalData.id.slice(-6)}`,
              notes: `Guest: ${paymentModalData.guestName}`,
              paymentMethod: details.method,
              cardDetails: details.cardInfo
          });
          addNotification(`تم دفع الفاتورة بنجاح (${details.method === 'card' ? 'بطاقة' : details.method === 'transfer' ? 'تحويل' : 'نقداً'})`, 'success');
          setPaymentModalData(null);
      }
  };

  const handlePrintQR = () => {
    if (!showQRModal) return;
    printDocument({
        title: `Digital Invoice QR - ${showQRModal.name}`,
        content: `
            <div style="text-align: center; padding: 40px; border: 2px solid #000; border-radius: 20px; font-family: sans-serif;">
                <h1 style="font-size: 24px; font-weight: 900; margin-bottom: 10px;">Digital Invoice</h1>
                <h2 style="font-size: 18px; margin-bottom: 20px;">${showQRModal.name}</h2>
                <div style="margin: 20px auto; display: inline-block;">
                    ${renderToStaticMarkup(<QRCodeSVG value={showQRModal.url} size={200} />)}
                </div>
                <p style="margin-top: 20px; font-weight: bold;">Scan to Pay / View Invoice</p>
                <p style="font-size: 12px; color: #555;">${showQRModal.id}</p>
            </div>
        `,
        settings
    });
  };

  const handlePrint = (invoice: any) => {
    if (!canPrint) {
      addNotification("الطباعة غير متاحة", "warning");
      return;
    }
    // Generate QR Record for internal tracking
    addQRRecord({
        type: 'invoice',
        referenceId: invoice.id,
        title: `فاتورة: ${invoice.guestName}`,
        subtitle: `${invoice.amount.toLocaleString()} د.ج`,
        status: 'valid',
        dataPayload: `INV:${invoice.id}`
    });

    // Show Digital Invoice QR for the Guest
    const portalPayload = JSON.stringify({
        type: 'invoice',
        id: invoice.id,
        name: invoice.guestName,
        expiry: new Date(Date.now() + 86400000).toISOString() // 24h link
    });
    // SAFE UNICODE ENCODING
    const url = `https://nuzul-hotel.com/pay?token=${btoa(unescape(encodeURIComponent(portalPayload)))}`;
    
    setShowQRModal({ id: invoice.id, name: invoice.guestName, url });
  };

  const getBookingForInvoice = (bookingId: string) => bookings.find(b => b.id === bookingId);
  const getRoomNumber = (roomId: number) => rooms.find(r => r.id === roomId)?.number || 'Unknown';
  
  const calculateDays = (start: string, end: string) => {
      if (!end || end === 'TBD') return 1;
      const d1 = new Date(start);
      const d2 = new Date(end);
      const diffTime = Math.abs(d2.getTime() - d1.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
      return diffDays > 0 ? diffDays : 1;
  };

  return (
    <div className="space-y-4 pb-10">
        
      {/* Normal Screen View */}
      <div className="print:hidden">
        <div className="flex items-center justify-between mb-4 text-inherit">
             <h2 className="text-xl font-bold flex items-center gap-2"><FileText /> الفواتير المالية</h2>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-[2.5rem] shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden text-gray-900 dark:text-gray-100">
        <div className={`p-6 border-b border-gray-100 dark:border-gray-700 font-bold text-lg ${ts.tableHeader}`}>
            سجل الفواتير الصادرة
        </div>
        <div className="overflow-x-auto">
            <table className="w-full text-sm text-right">
            <thead className="bg-gray-50 dark:bg-gray-700/50 text-gray-500 font-bold">
                <tr>
                <th className="p-5">رقم الفاتورة</th>
                <th className="p-5">النزيل</th>
                <th className="p-5">التاريخ</th>
                <th className="p-5">المبلغ</th>
                <th className="p-5 print:hidden">الإجراء</th>
                </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                {invoices.length === 0 ? (
                <tr><td colSpan={5} className="p-12 text-center opacity-50 font-bold">لا توجد فواتير</td></tr>
                ) : (
                invoices.map(inv => (
                    <tr key={inv.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                    <td className="p-5 font-mono text-xs font-bold text-gray-400">INV-{inv.id.slice(-6).toUpperCase()}</td>
                    <td className="p-5 font-bold text-gray-800 dark:text-gray-200">{inv.guestName}</td>
                    <td className="p-5 font-mono text-gray-500">{new Date(inv.date).toLocaleDateString('ar-SA')}</td>
                    <td className="p-5 font-black text-green-600 text-lg">
                        {inv.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })} د.ج
                    </td>
                    <td className="p-5">
                        <div className="flex items-center gap-2">
                            {!inv.isPaid && (
                                <button
                                    onClick={() => setPaymentModalData({ id: inv.id, amount: inv.amount, guestName: inv.guestName })}
                                    className={`flex items-center gap-2 px-4 py-2 rounded-xl border transition font-bold text-xs ${ts.button}`}
                                >
                                    <CreditCard size={14}/> دفع
                                </button>
                            )}
                            <PrintButton 
                                title={`Invoice #${inv.id}`}
                            label="طباعة"
                            className={`flex items-center gap-2 px-4 py-2 rounded-xl border transition font-bold text-xs ${
                                canPrint 
                                ? ts.button 
                                : 'opacity-50 cursor-not-allowed bg-gray-100'
                            }`}
                            content={
                                <div className="bg-white p-8 max-w-[210mm] mx-auto min-h-[297mm] relative flex flex-col text-black" dir="rtl">
                                    {/* Header */}
                                    <div className="flex justify-between items-start border-b-2 border-gray-800 pb-6 mb-8">
                                        <div>
                                            {settings.invoiceHeaderImage ? (
                                                <img src={settings.invoiceHeaderImage} alt="Logo" className="max-h-24 object-contain mb-2" />
                                            ) : (
                                                <h1 className="text-4xl font-bold text-gray-900 mb-2">{settings.appName}</h1>
                                            )}
                                            <div className="text-sm text-gray-600 space-y-1">
                                                <p className="flex items-center gap-2"><MapPin size={12}/> {settings.hotelAddress}</p>
                                                <p className="flex items-center gap-2"><Phone size={12}/> {settings.hotelPhone}</p>
                                                <p className="flex items-center gap-2"><Mail size={12}/> {settings.hotelEmail}</p>
                                                {settings.taxNumber && <p className="font-mono text-xs mt-2 font-bold">{settings.taxNumber}</p>}
                                            </div>
                                        </div>
                                        <div className="text-left">
                                            <h2 className="text-5xl font-extrabold text-gray-200 tracking-widest">INVOICE</h2>
                                            <p className="text-xl font-bold text-gray-700 mt-2">فاتورة رقم</p>
                                            <p className="font-mono text-lg">#{inv.id.slice(-6).toUpperCase()}</p>
                                            <p className="text-sm text-gray-500 mt-1">التاريخ: {new Date(inv.date).toLocaleDateString('en-GB')}</p>
                                        </div>
                                    </div>

                                    {/* Invoice Details */}
                                    <div className="mb-10 bg-gray-50 p-4 rounded border-r-4 border-gray-800">
                                        <h3 className="text-gray-500 text-xs font-bold uppercase mb-1">بيانات العميل (Bill To)</h3>
                                        <p className="text-xl font-bold text-gray-900">{inv.guestName}</p>
                                        {getBookingForInvoice(inv.bookingId) && (
                                            <p className="text-sm text-gray-600 mt-1">
                                                رقم الغرفة: <span className="font-bold">{getRoomNumber(getBookingForInvoice(inv.bookingId)!.roomId)}</span>
                                            </p>
                                        )}
                                    </div>

                                    <div className="flex-1">
                                        <table className="w-full mb-8">
                                            <thead>
                                                <tr className="border-b-2 border-gray-800">
                                                    <th className="py-3 text-right font-bold text-gray-800 w-1/2">الوصف / Description</th>
                                                    <th className="py-3 text-center font-bold text-gray-800">المدة / الكمية</th>
                                                    <th className="py-3 text-left font-bold text-gray-800">المجموع</th>
                                                </tr>
                                            </thead>
                                            <tbody className="text-gray-700">
                                                <tr className="border-b border-gray-200">
                                                    <td className="py-4">
                                                        <p className="font-bold">إقامة فندقية / Accommodation</p>
                                                    </td>
                                                    <td className="py-4 text-center">
                                                        {inv.details?.days || calculateDays(getBookingForInvoice(inv.bookingId)?.checkInDate || '', getBookingForInvoice(inv.bookingId)?.checkOutDate || '')} ليالي
                                                    </td>
                                                    <td className="py-4 text-left font-mono font-bold">{(inv.details?.roomTotal || inv.amount).toLocaleString('en-US')}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        
                                        <div className="flex justify-end">
                                            <div className="w-64">
                                                <div className="flex justify-between py-4 text-xl font-bold text-black border-t-2 border-black mt-2">
                                                    <span>الإجمالي الكلي:</span>
                                                    <span className="font-mono">{inv.amount.toLocaleString('en-US')} د.ج</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    {/* QR Code Footer for Print */}
                                    <div className="mt-12 pt-8 border-t-2 border-gray-200 flex justify-between items-end">
                                         <div className="text-sm text-gray-500 max-w-md">
                                                <h4 className="font-bold text-gray-800 mb-2">معلومات الدفع</h4>
                                                <p>{settings.invoiceFooterText}</p>
                                         </div>
                                         <div className="text-center">
                                             <div className="w-24 h-24 mb-2 border p-1 bg-white">
                                                 <QRCodeSVG value={`INV:${inv.id}`} size={96} />
                                             </div>
                                             <p className="text-[10px] font-mono">SCAN TO VERIFY</p>
                                         </div>
                                    </div>
                                    
                                    <div className="absolute bottom-0 left-0 right-0 h-4 bg-gray-900"></div>
                                </div>
                            }
                        />
                        </div>
                    </td>
                    </tr>
                ))
                )}
            </tbody>
            </table>
        </div>
        </div>
      </div>

      {/* --- PAYMENT MODAL --- */}
      {paymentModalData && (
          <PaymentModal
              isOpen={!!paymentModalData}
              onClose={() => setPaymentModalData(null)}
              amount={paymentModalData.amount}
              description={`دفع فاتورة النزيل: ${paymentModalData.guestName}`}
              onSuccess={handlePaymentSuccess}
          />
      )}

      {/* --- DIGITAL INVOICE QR MODAL --- */}
      {showQRModal && (
            <div className="fixed inset-0 bg-black/90 z-[150] flex items-center justify-center p-6 backdrop-blur-xl animate-fade-in print:hidden">
                <div className={`w-full max-w-md rounded-[3rem] shadow-2xl relative overflow-hidden flex flex-col items-center p-8 ${settings.darkMode ? (settings.theme === 'zellige' ? 'bg-[#001e21] text-[#cca43b] border border-[#cca43b]/20' : 'bg-gray-900 text-white border border-gray-700') : 'bg-white text-gray-900'}`}>
                    
                    <button onClick={() => setShowQRModal(null)} className={`absolute top-6 right-6 p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition z-20 ${settings.darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                        <X size={24} />
                    </button>

                    <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-4 shadow-inner ${settings.theme === 'zellige' && settings.darkMode ? 'bg-[#cca43b]/10 text-[#cca43b]' : 'bg-blue-100 text-blue-600'}`}>
                        <FileText size={40} />
                    </div>

                    <h3 className="text-2xl font-black mb-1">الفاتورة الرقمية</h3>
                    <p className={`text-sm font-bold mb-8 ${settings.darkMode ? 'text-gray-400' : 'text-gray-500'}`}>امسح الرمز لتحميل الفاتورة أو الدفع</p>
                    
                    <div className={`p-6 rounded-[2.5rem] shadow-2xl mb-6 relative group ${settings.theme === 'zellige' && settings.darkMode ? 'bg-[#002a2d] border border-[#cca43b]/20' : 'bg-gray-900'}`}>
                        <div className="bg-white p-2 rounded-xl">
                            <QRCodeSVG value={showQRModal.url} size={224} />
                        </div>
                        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/60 rounded-[2.5rem]">
                            <a href={showQRModal.url} target="_blank" rel="noreferrer" className="text-white font-bold flex items-center gap-2 hover:underline">
                                <ExternalLink size={20}/> فتح الرابط
                            </a>
                        </div>
                    </div>
                    
                    <div className={`p-4 rounded-2xl w-full text-center border ${settings.theme === 'zellige' && settings.darkMode ? 'bg-[#002a2d] border-[#cca43b]/20' : 'bg-gray-50 border-gray-100 dark:bg-gray-800 dark:border-gray-700'}`}>
                        <p className={`text-xs font-bold uppercase mb-1 ${settings.darkMode ? 'text-gray-400' : 'text-gray-400'}`}>العميل</p>
                        <p className="text-lg font-black">{showQRModal.name}</p>
                        <p className={`text-sm font-bold mt-1 uppercase font-mono ${settings.theme === 'zellige' && settings.darkMode ? 'text-[#cca43b]' : 'text-blue-600'}`}>#{showQRModal.id.slice(-6)}</p>
                    </div>

                    <button 
                        onClick={handlePrintQR}
                        className={`mt-6 text-xs font-bold flex items-center gap-2 ${settings.darkMode ? 'text-gray-400 hover:text-gray-300' : 'text-gray-400 hover:text-gray-600'}`}
                    >
                        <Printer size={14}/> طباعة نسخة ورقية
                    </button>
                </div>
            </div>
      )}

      {/* Detailed Invoice Print Layout */}
      {/* Removed: Handled by PrintButton modal */}
    </div>
  );
};
