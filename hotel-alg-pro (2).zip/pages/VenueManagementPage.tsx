import React, { useState, useMemo } from 'react';
import { useHotel } from '../context/HotelContext';
import { PageHeader } from '../components/PageHeader';
import { 
    MapPin, Plus, Calendar, Clock, Tent, Users, 
    Utensils, Store, Music, Palmtree, Sun, Umbrella, 
    MoreVertical, Edit, Trash2, CheckCircle2, AlertCircle,
    ArrowRight, LayoutGrid, List, Map as MapIcon, QrCode
} from 'lucide-react';
import { ServicePoint, Department } from '../types';

export const VenueManagementPage: React.FC = () => {
    const { servicePoints, addServicePoint, updateServicePoint, users, settings } = useHotel();
    const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
    const [filter, setFilter] = useState<'all' | 'permanent' | 'pop_up'>('all');
    const [showAddModal, setShowAddModal] = useState(false);

    // Form State
    const [newVenue, setNewVenue] = useState<Partial<ServicePoint>>({
        type: 'kiosk',
        category: 'pop_up',
        status: 'active',
        location: { lat: 0, lng: 0, address: '' }
    });

    const venues = useMemo(() => servicePoints.filter(sp => sp.type === 'garden' || sp.type === 'park' || sp.type === 'venue' || sp.type === 'hotel_facility'), [servicePoints]);
    
    const filteredPoints = useMemo(() => {
        let points = servicePoints;
        if (filter !== 'all') {
            points = points.filter(sp => sp.category === (filter === 'pop_up' ? 'pop_up' : 'permanent'));
        }
        return points;
    }, [servicePoints, filter]);

    const handleAddVenue = (e: React.FormEvent) => {
        e.preventDefault();
        if (!newVenue.name) return;

        addServicePoint({
            ...newVenue as ServicePoint,
            id: crypto.randomUUID(),
            location: { ...newVenue.location!, lat: 0, lng: 0, address: newVenue.location?.address || 'Hotel Grounds' }
        });
        setShowAddModal(false);
        setNewVenue({ type: 'kiosk', category: 'pop_up', status: 'active', location: { lat: 0, lng: 0, address: '' } });
    };

    const getIconForType = (type: string) => {
        switch (type) {
            case 'kiosk': return Store;
            case 'garden': return Palmtree;
            case 'park': return Sun;
            case 'roaming_cart': return Utensils;
            case 'activity_zone': return Music;
            case 'venue': return Tent;
            default: return MapPin;
        }
    };

    const isZellige = settings.theme === 'zellige' || settings.theme === 'zellige-v2';
    const isDark = settings.darkMode;

    return (
        <div className="space-y-8 pb-20 animate-fade-in">
            <div className="flex flex-col md:flex-row justify-between items-end gap-4">
                <div className="flex-1 w-full">
                    <PageHeader 
                        pageKey="venues" 
                        defaultTitle="إدارة المساحات والأكشاك المؤقتة" 
                        icon={Tent} 
                        description="تخطيط وإدارة الفعاليات والأكشاك الموسمية داخل مرافق الفندق"
                    />
                </div>
                <button 
                    onClick={() => setShowAddModal(true)} 
                    className={`px-6 py-3 rounded-2xl font-bold shadow-lg flex items-center gap-2 transition-transform active:scale-95 ${
                        isZellige 
                        ? 'bg-[#006269] text-[#cca43b] hover:bg-[#004d53]' 
                        : 'bg-blue-600 text-white hover:bg-blue-700'
                    }`}
                >
                    <Plus size={20}/> إنشاء نقطة جديدة
                </button>
            </div>

            {/* Filters & View Toggle */}
            <div className="flex justify-between items-center bg-white dark:bg-gray-800 p-2 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700">
                <div className="flex gap-2">
                    <button onClick={() => setFilter('all')} className={`px-4 py-2 rounded-xl text-sm font-bold transition-colors ${filter === 'all' ? 'bg-gray-100 dark:bg-gray-700 text-blue-600 dark:text-blue-400' : 'text-gray-500 hover:bg-gray-50'}`}>الكل</button>
                    <button onClick={() => setFilter('permanent')} className={`px-4 py-2 rounded-xl text-sm font-bold transition-colors ${filter === 'permanent' ? 'bg-gray-100 dark:bg-gray-700 text-blue-600 dark:text-blue-400' : 'text-gray-500 hover:bg-gray-50'}`}>مرافق دائمة</button>
                    <button onClick={() => setFilter('pop_up')} className={`px-4 py-2 rounded-xl text-sm font-bold transition-colors ${filter === 'pop_up' ? 'bg-orange-50 text-orange-600 border border-orange-100' : 'text-gray-500 hover:bg-gray-50'}`}>أكشاك مؤقتة (Pop-up)</button>
                </div>
                <div className="flex gap-1 bg-gray-100 dark:bg-gray-700 p-1 rounded-xl">
                    <button onClick={() => setViewMode('grid')} className={`p-2 rounded-lg ${viewMode === 'grid' ? 'bg-white dark:bg-gray-600 shadow-sm' : 'text-gray-400'}`}><LayoutGrid size={18}/></button>
                    <button onClick={() => setViewMode('list')} className={`p-2 rounded-lg ${viewMode === 'list' ? 'bg-white dark:bg-gray-600 shadow-sm' : 'text-gray-400'}`}><List size={18}/></button>
                </div>
            </div>

            {/* Content Grid */}
            <div className={`grid gap-6 ${viewMode === 'grid' ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' : 'grid-cols-1'}`}>
                {filteredPoints.map(point => {
                    const Icon = getIconForType(point.type);
                    const isPopup = point.category === 'pop_up';
                    const isActive = point.status === 'active';
                    
                    return (
                        <div key={point.id} className={`group relative overflow-hidden rounded-[2rem] border transition-all duration-300 hover:-translate-y-1 hover:shadow-xl ${
                            isZellige 
                            ? (isDark ? 'bg-[#001e21] border-[#cca43b]/30' : 'bg-[#FDFBF7] border-[#cca43b]/30') 
                            : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700'
                        }`}>
                            {/* Background Pattern for Zellige */}
                            {isZellige && (
                                <div className={`absolute inset-0 pointer-events-none opacity-[0.03] bg-zellige-pattern mix-blend-multiply dark:mix-blend-screen`}></div>
                            )}

                            {/* Status Badge */}
                            <div className={`absolute top-4 left-4 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider z-10 ${
                                isActive 
                                ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' 
                                : 'bg-gray-100 text-gray-500 dark:bg-gray-700 dark:text-gray-400'
                            }`}>
                                {point.status === 'active' ? 'نشط' : point.status === 'scheduled' ? 'مجدول' : 'مغلق'}
                            </div>

                            {/* Image / Icon Header */}
                            <div className={`h-40 w-full flex items-center justify-center relative overflow-hidden ${
                                isPopup ? 'bg-gradient-to-br from-orange-50 to-amber-100 dark:from-orange-900/20 dark:to-amber-900/20' : 'bg-gray-50 dark:bg-gray-900'
                            }`}>
                                {point.image ? (
                                    <img src={point.image} alt={point.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                                ) : (
                                    <Icon size={48} className={`opacity-20 ${isPopup ? 'text-orange-500' : 'text-gray-400'}`} />
                                )}
                                
                                {/* Type Icon Overlay */}
                                <div className={`absolute -bottom-6 right-6 w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg transform rotate-3 group-hover:rotate-0 transition-transform ${
                                    isZellige 
                                    ? 'bg-[#006269] text-[#cca43b]' 
                                    : 'bg-white dark:bg-gray-700 text-blue-600 dark:text-blue-400'
                                }`}>
                                    <Icon size={24} />
                                </div>
                            </div>

                            {/* Content Body */}
                            <div className="p-6 pt-8">
                                <h3 className={`text-lg font-black mb-1 ${isZellige ? 'font-serif tracking-wide' : ''} ${isDark ? 'text-white' : 'text-gray-900'}`}>{point.name}</h3>
                                <p className="text-xs text-gray-500 dark:text-gray-400 font-medium mb-4 line-clamp-2">{point.description || 'لا يوجد وصف متاح لهذا المرفق.'}</p>

                                {/* Meta Info */}
                                <div className="space-y-2 mb-6">
                                    <div className="flex items-center gap-2 text-xs text-gray-600 dark:text-gray-300">
                                        <MapPin size={14} className="text-gray-400"/>
                                        <span>{point.location.address}</span>
                                    </div>
                                    {isPopup && point.validUntil && (
                                        <div className="flex items-center gap-2 text-xs text-orange-600 dark:text-orange-400 font-bold bg-orange-50 dark:bg-orange-900/20 p-2 rounded-lg">
                                            <Clock size={14}/>
                                            <span>متاح حتى: {new Date(point.validUntil).toLocaleDateString()}</span>
                                        </div>
                                    )}
                                </div>

                                {/* Actions */}
                                <div className="flex items-center justify-between pt-4 border-t border-gray-100 dark:border-gray-700">
                                    <div className="flex -space-x-2 space-x-reverse">
                                        {/* Staff Avatars Placeholder */}
                                        {[1,2].map(i => (
                                            <div key={i} className="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-600 border-2 border-white dark:border-gray-800 flex items-center justify-center text-[10px] font-bold text-gray-500">
                                                <Users size={12}/>
                                            </div>
                                        ))}
                                    </div>
                                    <div className="flex gap-1">
                                        <button className={`p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-400 hover:text-blue-600 transition-colors`} title="رمز QR">
                                            <QrCode size={20}/>
                                        </button>
                                        <button className={`p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-400 hover:text-blue-600 transition-colors`}>
                                            <MoreVertical size={20}/>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    );
                })}
                
                {/* Empty State for Add New */}
                <button 
                    onClick={() => setShowAddModal(true)}
                    className={`group relative min-h-[300px] rounded-[2rem] border-2 border-dashed flex flex-col items-center justify-center gap-4 transition-all hover:border-blue-400 hover:bg-blue-50/50 dark:hover:bg-blue-900/10 ${
                        isDark ? 'border-gray-700' : 'border-gray-200'
                    }`}
                >
                    <div className="w-16 h-16 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center text-gray-400 group-hover:text-blue-500 group-hover:scale-110 transition-all">
                        <Plus size={32}/>
                    </div>
                    <span className="font-bold text-gray-400 group-hover:text-blue-600">إضافة مساحة جديدة</span>
                </button>
            </div>

            {/* Add Modal */}
            {showAddModal && (
                <div className="fixed inset-0 bg-black/60 z-[100] flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in">
                    <div className={`w-full max-w-lg rounded-[2.5rem] p-8 shadow-2xl relative overflow-hidden ${isDark ? 'bg-gray-900 text-white' : 'bg-white text-gray-900'}`}>
                        <div className="flex justify-between items-center mb-8">
                            <h3 className="font-black text-2xl">إنشاء نقطة خدمة</h3>
                            <button onClick={() => setShowAddModal(false)} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full"><Trash2 size={20}/></button>
                        </div>
                        
                        <form onSubmit={handleAddVenue} className="space-y-6">
                            <div>
                                <label className="block text-xs font-bold uppercase tracking-wider opacity-70 mb-2">اسم النقطة / الكشك</label>
                                <input 
                                    type="text" 
                                    required
                                    value={newVenue.name || ''}
                                    onChange={e => setNewVenue({...newVenue, name: e.target.value})}
                                    className="w-full p-4 rounded-2xl bg-gray-50 dark:bg-gray-800 border-2 border-transparent focus:border-blue-500 outline-none font-bold"
                                    placeholder="مثال: كشك المثلجات الصيفي"
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-xs font-bold uppercase tracking-wider opacity-70 mb-2">النوع</label>
                                    <select 
                                        value={newVenue.type}
                                        onChange={e => setNewVenue({...newVenue, type: e.target.value as any})}
                                        className="w-full p-4 rounded-2xl bg-gray-50 dark:bg-gray-800 border-2 border-transparent focus:border-blue-500 outline-none font-bold appearance-none"
                                    >
                                        <option value="kiosk">كشك بيع (Kiosk)</option>
                                        <option value="roaming_cart">عربة متجولة (Cart)</option>
                                        <option value="activity_zone">منطقة نشاط (Activity)</option>
                                        <option value="garden">حديقة (Garden)</option>
                                        <option value="venue">قاعة / خيمة (Tent)</option>
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-xs font-bold uppercase tracking-wider opacity-70 mb-2">التصنيف</label>
                                    <select 
                                        value={newVenue.category}
                                        onChange={e => setNewVenue({...newVenue, category: e.target.value as any})}
                                        className="w-full p-4 rounded-2xl bg-gray-50 dark:bg-gray-800 border-2 border-transparent focus:border-blue-500 outline-none font-bold appearance-none"
                                    >
                                        <option value="pop_up">مؤقت (Pop-up)</option>
                                        <option value="seasonal">موسمي (Seasonal)</option>
                                        <option value="permanent">دائم (Permanent)</option>
                                    </select>
                                </div>
                            </div>

                            {newVenue.category !== 'permanent' && (
                                <div className="p-4 rounded-2xl bg-orange-50 dark:bg-orange-900/20 border border-orange-100 dark:border-orange-900/30">
                                    <h4 className="font-bold text-orange-700 dark:text-orange-400 text-sm mb-3 flex items-center gap-2"><Clock size={16}/> فترة التشغيل</h4>
                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <label className="block text-[10px] font-bold uppercase opacity-70 mb-1">من</label>
                                            <input 
                                                type="date" 
                                                value={newVenue.validFrom || ''}
                                                onChange={e => setNewVenue({...newVenue, validFrom: e.target.value})}
                                                className="w-full p-2 rounded-xl bg-white dark:bg-gray-900 border border-orange-200 dark:border-orange-800 text-sm font-bold"
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-[10px] font-bold uppercase opacity-70 mb-1">إلى</label>
                                            <input 
                                                type="date" 
                                                value={newVenue.validUntil || ''}
                                                onChange={e => setNewVenue({...newVenue, validUntil: e.target.value})}
                                                className="w-full p-2 rounded-xl bg-white dark:bg-gray-900 border border-orange-200 dark:border-orange-800 text-sm font-bold"
                                            />
                                        </div>
                                    </div>
                                </div>
                            )}

                            <div>
                                <label className="block text-xs font-bold uppercase tracking-wider opacity-70 mb-2">الموقع (داخل الفندق)</label>
                                <select 
                                    value={newVenue.location?.parentVenueId || ''}
                                    onChange={e => setNewVenue({
                                        ...newVenue, 
                                        location: { ...newVenue.location!, parentVenueId: e.target.value, address: venues.find(v => v.id === e.target.value)?.name || '' }
                                    })}
                                    className="w-full p-4 rounded-2xl bg-gray-50 dark:bg-gray-800 border-2 border-transparent focus:border-blue-500 outline-none font-bold appearance-none"
                                >
                                    <option value="">-- اختر الموقع الرئيسي --</option>
                                    {venues.map(v => <option key={v.id} value={v.id}>{v.name}</option>)}
                                    <option value="lobby">البهو الرئيسي (Lobby)</option>
                                    <option value="pool_deck">منطقة المسبح (Pool Deck)</option>
                                </select>
                            </div>

                            <button 
                                type="submit" 
                                className={`w-full py-4 rounded-2xl font-black text-lg shadow-xl hover:shadow-2xl hover:-translate-y-1 transition-all ${
                                    isZellige 
                                    ? 'bg-[#006269] text-[#cca43b]' 
                                    : 'bg-blue-600 text-white'
                                }`}
                            >
                                بناء النقطة
                            </button>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default VenueManagementPage;
